# VADA Plugin Manager v1.3.1

## Sửa lỗi
- Sửa lỗi toolbar/icon không hiện sau khi cài v1.3.0.
- Giữ tham chiếu toolbar trong suốt phiên SketchUp.
- Tự gọi `show` sau khi SketchUp khởi tạo UI.
- Không tạo trùng menu/toolbar khi reload.
- Giữ nguyên toàn bộ chức năng cài mới, cập nhật, nhận diện phiên bản và hot reload của v1.3.0.
