# VADA Plugin Manager v1.3.0

## Thay đổi chính
- Plugin trên GitHub nhưng chưa cài trong SketchUp được đưa lên **đầu danh sách**.
- Nút **Cài mới** xuất hiện khi plugin chưa cài và GitHub có file RBZ.
- Tự phát hiện plugin mới từ các thư mục đánh số có dạng `vX.Y.Z`, kể cả khi manifest chưa kịp bổ sung.
- Giữ cơ chế ưu tiên đọc phiên bản từ SketchUp Extensions, fallback quét file `.rb`.
- Tách rõ 4 nhóm: Plugin mới chưa cài / Có bản cập nhật / Đã cài mới nhất / Chưa nhận diện.
- Hỗ trợ reload phần core bằng `reload_candidates` để một số plugin cập nhật xong dùng ngay không cần restart.
- `Tạo mặt cắt và góc nhìn` dùng reload core `vada_mat_cat_view/main.rb` thay vì reload loader extension.

## Cài đặt
Cài file `VADA_Plugin_Manager_v1.3.0.rbz` bằng SketchUp Extension Manager.

Với chính VADA Plugin Manager, sau khi nâng từ v1.2.0 lên v1.3.0 nên mở lại SketchUp một lần để giao diện Manager nạp đầy đủ bản mới.
