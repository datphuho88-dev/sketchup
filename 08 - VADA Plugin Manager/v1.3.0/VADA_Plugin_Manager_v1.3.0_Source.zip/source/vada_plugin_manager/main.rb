# frozen_string_literal: true
require 'sketchup.rb'
require 'json'
require 'net/http'
require 'uri'
require 'tmpdir'

module VADA
  module PluginManager
    VERSION = '1.3.0' unless const_defined?(:VERSION)
    OWNER = 'datphuho88-dev'
    REPO = 'sketchup'
    BRANCH = 'main'
    MANIFEST_URL = "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/vada_plugin_manifest.json"
    TREE_URL = "https://api.github.com/repos/#{OWNER}/#{REPO}/git/trees/#{BRANCH}?recursive=1"
    PLUGINS_DIR = Sketchup.find_support_file('Plugins')

    class << self
      def show
        @dialog ||= build_dialog
        refresh_ui
        @dialog.show
      end

      def build_dialog
        dlg = UI::HtmlDialog.new(
          dialog_title: "VADA Plugin Manager v#{VERSION}",
          preferences_key: 'vada_plugin_manager',
          scrollable: true,
          resizable: true,
          width: 820,
          height: 650,
          style: UI::HtmlDialog::STYLE_DIALOG
        )
        dlg.set_html(html)
        dlg.add_action_callback('refresh') { |_c| refresh_ui }
        dlg.add_action_callback('checkUpdates') { |_c| check_updates }
        dlg.add_action_callback('reloadPlugin') { |_c, id| reload_plugin(id.to_s) }
        dlg.add_action_callback('updatePlugin') { |_c, id| update_plugin(id.to_s) }
        dlg.add_action_callback('reloadAll') { |_c| reload_all }
        dlg.add_action_callback('updateAll') { |_c| update_all }
        dlg
      end

      def normalize_text(value)
        value.to_s.downcase.unicode_normalize(:nfkd).encode('ASCII', replace: '', undef: :replace, invalid: :replace)
             .gsub(/[^a-z0-9]+/, ' ').strip
      rescue StandardError
        value.to_s.downcase
      end

      def slug(value)
        normalize_text(value).tr(' ', '_').gsub(/_+/, '_').sub(/^_/, '').sub(/_$/, '')
      end

      def extension_snapshot
        result = []
        begin
          Sketchup.extensions.each do |ext|
            result << {
              object: ext,
              name: safe_call(ext, :name).to_s,
              version: safe_call(ext, :version).to_s,
              loaded: !!safe_call(ext, :loaded?),
              path: extension_path(ext)
            }
          end
        rescue StandardError
        end
        result
      end

      def safe_call(object, method)
        object.respond_to?(method) ? object.public_send(method) : nil
      rescue StandardError
        nil
      end

      def extension_path(ext)
        [:extension_path, :path].each do |method|
          next unless ext.respond_to?(method)
          value = safe_call(ext, method)
          return value if value && !value.to_s.empty?
        end
        nil
      end

      def plugin_catalog
        manifest = cached_manifest || fallback_manifest
        extensions = extension_snapshot
        items = manifest.fetch('plugins', []).map do |plugin|
          p = plugin.dup
          detect_local!(p, extensions)
          p['update_available'] = update_available?(p['local_version'], p['latest_version'], p['installed'])
          p['installable'] = !p['installed'] && !p['rbz_url'].to_s.empty?
          p['reload_target'] = resolve_reload_target(p)
          p['reloadable'] = p['installed'] && p.fetch('hot_reload', false) && !p['reload_target'].to_s.empty?
          p
        end
        sort_plugins(items)
      end

      def detect_local!(plugin, extensions)
        ext = match_extension(plugin, extensions)
        if ext
          plugin['installed'] = true
          plugin['local_version'] = ext[:version].empty? ? detect_version_from_file(ext[:path]) : ext[:version]
          plugin['local_version'] = 'đã cài' if plugin['local_version'].to_s.empty?
          plugin['extension_match'] = ext[:name]
          plugin['loader'] = resolve_loader(plugin) || existing_file(ext[:path])
          return plugin
        end

        loader = resolve_loader(plugin)
        if loader
          plugin['installed'] = true
          plugin['loader'] = loader
          plugin['local_version'] = detect_version_from_file(loader)
          plugin['local_version'] = plugin['installed_version'] || 'đã cài' if plugin['local_version'].to_s.empty?
          return plugin
        end

        scanned = scan_loader_by_tokens(plugin)
        if scanned
          plugin['installed'] = true
          plugin['loader'] = scanned
          plugin['local_version'] = detect_version_from_file(scanned)
          plugin['local_version'] = 'đã cài' if plugin['local_version'].to_s.empty?
          return plugin
        end

        plugin['installed'] = false
        plugin['local_version'] = '-'
        plugin['loader'] = nil
        plugin
      end

      def match_extension(plugin, extensions)
        exact = Array(plugin['extension_names']).map { |n| normalize_text(n) }.reject(&:empty?)
        tokens = Array(plugin['detect_tokens']).map { |n| normalize_text(n) }.reject(&:empty?)
        tokens << normalize_text(plugin['name']) unless plugin['name'].to_s.empty?
        extensions.find do |ext|
          ext_name = normalize_text(ext[:name])
          exact.include?(ext_name) || tokens.any? { |token| !token.empty? && ext_name.include?(token) }
        end
      end

      def existing_file(path)
        return nil if path.to_s.empty?
        File.file?(path.to_s) ? path.to_s : nil
      end

      def resolve_loader(plugin)
        Array(plugin['loader_candidates']).each do |rel|
          path = File.join(PLUGINS_DIR, rel.to_s)
          return path if File.file?(path)
        end
        nil
      end

      def scan_loader_by_tokens(plugin)
        tokens = Array(plugin['detect_tokens']).map { |t| normalize_text(t) }
        tokens << normalize_text(plugin['name'])
        tokens = tokens.reject(&:empty?).uniq
        return nil if tokens.empty?

        Dir.glob(File.join(PLUGINS_DIR, '*.rb')).each do |file|
          base = normalize_text(File.basename(file, '.rb'))
          return file if tokens.any? { |token| base.include?(token) || token.include?(base) }
          begin
            sample = File.read(file, 32_768, encoding: 'UTF-8', invalid: :replace, undef: :replace, replace: '')
            normalized = normalize_text(sample)
            return file if tokens.any? { |token| normalized.include?(token) }
          rescue StandardError
          end
        end
        nil
      end

      def detect_version_from_file(path)
        return '' unless path && File.file?(path)
        text = File.read(path, encoding: 'UTF-8', invalid: :replace, undef: :replace, replace: '')
        patterns = [
          /(?:PLUGIN_VERSION|EXTENSION_VERSION|VERSION)\s*=\s*['\"]v?([^'\"]+)['\"]/i,
          /\.version\s*=\s*['\"]v?([^'\"]+)['\"]/i,
          /version\s*[:=]\s*['\"]?v?(\d+\.\d+\.\d+)/i
        ]
        patterns.each do |pattern|
          match = text.match(pattern)
          return match[1] if match
        end
        ''
      rescue StandardError
        ''
      end

      def resolve_reload_target(plugin)
        Array(plugin['reload_candidates']).each do |rel|
          path = File.join(PLUGINS_DIR, rel.to_s)
          return path if File.file?(path)
        end
        loader = resolve_loader(plugin)
        return loader if plugin.fetch('reload_loader', true) && loader
        nil
      end

      def update_available?(local, remote, installed = true)
        return false unless installed
        return false if remote.to_s.empty?
        return true if local.to_s.empty? || local.to_s == 'đã cài'
        compare_versions(remote, local) > 0
      end

      def compare_versions(a, b)
        aa = a.to_s.scan(/\d+/).map(&:to_i)
        bb = b.to_s.scan(/\d+/).map(&:to_i)
        len = [aa.length, bb.length, 3].max
        aa += [0] * (len - aa.length)
        bb += [0] * (len - bb.length)
        aa <=> bb
      end

      def sort_plugins(items)
        items.sort_by do |p|
          priority = if !p['installed'] && !p['rbz_url'].to_s.empty?
                       0 # plugin mới chưa cài: luôn lên đầu
                     elsif p['installed'] && p['update_available']
                       1 # plugin đang cũ
                     elsif p['installed']
                       2 # đã mới nhất
                     else
                       3 # chưa cài nhưng chưa có RBZ
                     end
          [priority, p['name'].to_s.downcase]
        end
      end

      def http_get(url, timeout = 10)
        uri = URI(url)
        req = Net::HTTP::Get.new(uri)
        req['User-Agent'] = "VADA-Plugin-Manager/#{VERSION}"
        req['Accept'] = 'application/vnd.github+json' if uri.host == 'api.github.com'
        res = Net::HTTP.start(uri.host, uri.port, use_ssl: true, open_timeout: 5, read_timeout: timeout) { |h| h.request(req) }
        return http_get(res['location'], timeout) if res.is_a?(Net::HTTPRedirection)
        raise "HTTP #{res.code}" unless res.is_a?(Net::HTTPSuccess)
        res.body
      end

      def fetch_manifest
        @manifest = JSON.parse(http_get(MANIFEST_URL, 8))
      end

      def fetch_tree
        JSON.parse(http_get(TREE_URL, 15)).fetch('tree', [])
      end

      def cached_manifest
        @manifest
      end

      def fallback_manifest
        { 'plugins' => [
          { 'id' => 'tong_do_dai_canh', 'name' => 'Tính tổng độ dài cạnh', 'latest_version' => '1.0.1', 'repo_path' => '05 - Tính tổng độ dài cạnh', 'loader_candidates' => ['vada_tong_do_dai_canh.rb'], 'hot_reload' => true },
          { 'id' => 'thong_ke_sat_hop', 'name' => 'Thống kê sắt hộp', 'latest_version' => '1.1.1', 'repo_path' => '06 - Thống kê sắt hộp', 'loader_candidates' => ['vada_thong_ke_sat_hop.rb'], 'hot_reload' => true },
          { 'id' => 'tong_dien_tich', 'name' => 'Tính tổng diện tích', 'latest_version' => '1.0.1', 'repo_path' => '07 - Tính tổng diện tích', 'loader_candidates' => ['vada_tong_dien_tich.rb'], 'hot_reload' => true }
        ] }
      end

      def enrich_from_tree!(tree)
        files = tree.select { |e| e['type'] == 'blob' }.map { |e| e['path'].to_s }
        dirs = tree.select { |e| e['type'] == 'tree' }.map { |e| e['path'].to_s }

        @manifest.fetch('plugins', []).each do |p|
          enrich_plugin_from_tree!(p, files, dirs)
        end
        discover_unlisted_plugins!(files, dirs)
      end

      def enrich_plugin_from_tree!(plugin, files, dirs)
        base = plugin['repo_path'].to_s.sub(%r{/+$}, '')
        return if base.empty?

        versions = direct_versions(base, dirs)
        if versions.any?
          latest = versions.max { |x, y| compare_versions(x[0], y[0]) }
          plugin['latest_version'] = latest[0]
          rbz = files.find { |path| path.start_with?(latest[1] + '/') && path.downcase.end_with?('.rbz') }
          plugin['rbz_url'] = raw_url(rbz) if rbz
          return
        end

        release_candidates = files.filter_map do |path|
          next unless path.start_with?(base + '/releases/') && path.downcase.end_with?('.rbz')
          m = File.basename(path).match(/v?(\d+\.\d+\.\d+)/i)
          m && [m[1], path]
        end
        return if release_candidates.empty?
        latest = release_candidates.max { |x, y| compare_versions(x[0], y[0]) }
        plugin['latest_version'] = latest[0]
        plugin['rbz_url'] = raw_url(latest[1])
      end

      def direct_versions(base, dirs)
        dirs.filter_map do |path|
          next unless path.start_with?(base + '/')
          rest = path[(base.length + 1)..-1]
          next if rest.include?('/')
          m = rest.match(/^v?(\d+\.\d+\.\d+)$/i)
          m && [m[1], path]
        end
      end

      def discover_unlisted_plugins!(files, dirs)
        known_paths = @manifest.fetch('plugins', []).map { |p| p['repo_path'].to_s }
        top_dirs = dirs.select { |p| !p.include?('/') }
        top_dirs.each do |base|
          next if known_paths.include?(base)
          next unless base.match?(/^\d+\s*-\s*.+/)
          versions = direct_versions(base, dirs)
          next if versions.empty?
          latest = versions.max { |x, y| compare_versions(x[0], y[0]) }
          rbz = files.find { |path| path.start_with?(latest[1] + '/') && path.downcase.end_with?('.rbz') }
          next unless rbz
          name = base.sub(/^\d+\s*-\s*/, '')
          @manifest['plugins'] << {
            'id' => slug(base),
            'name' => name,
            'repo_path' => base,
            'latest_version' => latest[0],
            'rbz_url' => raw_url(rbz),
            'loader_candidates' => [],
            'extension_names' => [name, "VADA #{name}"],
            'detect_tokens' => [name],
            'hot_reload' => false,
            'auto_discovered' => true
          }
        end
      end

      def raw_url(path)
        return '' if path.to_s.empty?
        encoded = path.split('/').map { |seg| URI::DEFAULT_PARSER.escape(seg) }.join('/')
        "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/#{encoded}"
      end

      def check_updates
        begin
          fetch_manifest
          enrich_from_tree!(fetch_tree)
          @last_check = Time.now
          toast('Đã quét GitHub trực tiếp. Plugin mới chưa cài sẽ nằm trên cùng.', 'ok')
        rescue StandardError => e
          toast("Không kiểm tra được GitHub: #{escape_js(e.message)}", 'err')
        ensure
          refresh_ui
        end
      end

      def safe_reload(plugin)
        target = resolve_reload_target(plugin)
        return [:restart, 'Không xác định được file reload an toàn'] unless target
        begin
          load target
          [:ok, target]
        rescue Exception => e
          [:error, e.message]
        end
      end

      def reload_plugin(id)
        p = plugin_catalog.find { |x| x['id'] == id }
        return toast('Không tìm thấy plugin', 'err') unless p
        return toast('Plugin chưa được cài', 'warn') unless p['installed']
        return toast('Plugin này chưa có cấu hình reload an toàn', 'warn') unless p['reloadable']
        status, detail = safe_reload(p)
        case status
        when :ok
          toast("Đã reload: #{escape_js(p['name'])}", 'ok')
        when :restart
          toast("#{escape_js(p['name'])}: cần khởi động lại SketchUp", 'warn')
        else
          toast("Reload lỗi #{escape_js(p['name'])}: #{escape_js(detail)}", 'err')
        end
        refresh_ui
      end

      def reload_all
        ok = 0
        fail = 0
        plugin_catalog.each do |p|
          next unless p['reloadable']
          status, = safe_reload(p)
          status == :ok ? ok += 1 : fail += 1
        end
        toast("Reload xong: #{ok} thành công, #{fail} lỗi", fail.zero? ? 'ok' : 'warn')
        refresh_ui
      end

      def update_plugin(id)
        p = plugin_catalog.find { |x| x['id'] == id }
        return toast('Không tìm thấy plugin', 'err') unless p
        if p['installed'] && !p['update_available']
          return toast('Plugin này đang là bản mới nhất', 'ok')
        end
        url = p['rbz_url'].to_s
        return toast('Không tìm thấy gói RBZ', 'warn') if url.empty?

        path = nil
        begin
          path = download(url, "vada_#{p['id']}_#{p['latest_version']}.rbz")
          raise 'SketchUp này không hỗ trợ cài RBZ tự động.' unless Sketchup.respond_to?(:install_from_archive)
          raise 'SketchUp không cài được gói RBZ.' unless Sketchup.install_from_archive(path)

          # Sau khi cài/cập nhật, quét lại file rồi reload phần core nếu được cấu hình an toàn.
          if p.fetch('hot_reload', false)
            status, detail = safe_reload(p)
            case status
            when :ok
              toast("#{p['installed'] ? 'Đã cập nhật' : 'Đã cài mới'} và reload: #{escape_js(p['name'])}", 'ok')
            when :restart
              toast("Đã #{p['installed'] ? 'cập nhật' : 'cài mới'} #{escape_js(p['name'])}. Cần mở lại SketchUp để nạp giao diện.", 'warn')
            else
              toast("Đã cài file mới nhưng reload lỗi: #{escape_js(detail)}", 'warn')
            end
          else
            toast("Đã #{p['installed'] ? 'cập nhật' : 'cài mới'} #{escape_js(p['name'])}. Nếu chưa xuất hiện ngay, cần mở lại SketchUp.", 'warn')
          end
        rescue StandardError => e
          toast("Cài đặt lỗi: #{escape_js(e.message)}", 'err')
        ensure
          begin File.delete(path) if path && File.file?(path); rescue StandardError; end
          refresh_ui
        end
      end

      def update_all
        list = plugin_catalog.select do |p|
          (!p['installed'] || p['update_available']) && !p['rbz_url'].to_s.empty?
        end
        return toast('Không có plugin mới hoặc bản cập nhật cần cài', 'ok') if list.empty?
        success = 0
        failed = 0
        restart_needed = 0
        list.each do |p|
          path = nil
          begin
            path = download(p['rbz_url'], "vada_#{p['id']}_#{p['latest_version']}.rbz")
            raise 'Không hỗ trợ install_from_archive' unless Sketchup.respond_to?(:install_from_archive)
            raise 'Cài đặt thất bại' unless Sketchup.install_from_archive(path)
            if p.fetch('hot_reload', false)
              status, = safe_reload(p)
              restart_needed += 1 unless status == :ok
            else
              restart_needed += 1
            end
            success += 1
          rescue StandardError
            failed += 1
          ensure
            begin File.delete(path) if path && File.file?(path); rescue StandardError; end
          end
        end
        msg = "Cài/cập nhật xong: #{success} thành công, #{failed} lỗi"
        msg += ", #{restart_needed} plugin cần mở lại SketchUp" if restart_needed.positive?
        toast(msg, failed.zero? && restart_needed.zero? ? 'ok' : 'warn')
        refresh_ui
      end

      def download(url, filename)
        body = http_get(url, 30)
        path = File.join(Dir.tmpdir, filename)
        File.binwrite(path, body)
        path
      end

      def refresh_ui
        return unless @dialog
        list = plugin_catalog
        payload = {
          plugins: list,
          last_check: @last_check ? @last_check.strftime('%H:%M:%S') : nil,
          new_count: list.count { |p| !p['installed'] && !p['rbz_url'].to_s.empty? },
          update_count: list.count { |p| p['installed'] && p['update_available'] }
        }
        @dialog.execute_script("renderState(#{JSON.generate(payload)});")
      end

      def toast(message, type = 'ok')
        return unless @dialog
        @dialog.execute_script("toast('#{escape_js(message)}','#{type}')")
      end

      def escape_js(str)
        str.to_s.gsub('\\', '\\\\').gsub("'", "\\'").gsub("\r", '').gsub("\n", '\\n')
      end

      def html
        <<~HTML
          <!doctype html><html><head><meta charset="utf-8"><style>
          *{box-sizing:border-box}body{margin:0;background:#000;color:#eee;font-family:Segoe UI,Arial,sans-serif;font-size:13px}
          .top{position:sticky;top:0;background:#050505;border-bottom:1px solid #222;padding:14px 16px;z-index:2}
          h1{font-size:18px;margin:0 0 3px;color:#fff}.ver{color:#888}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
          button{background:#171717;color:#fff;border:1px solid #333;border-radius:8px;padding:8px 11px;cursor:pointer;font-weight:600}button:hover{background:#242424}.primary{border-color:#c00;color:#ff5a5a}
          .body{padding:12px 16px 70px}.summary{color:#888;margin:0 0 10px}.section-title{font-size:12px;color:#aaa;margin:16px 2px 8px;text-transform:uppercase;letter-spacing:.6px}
          .card{display:grid;grid-template-columns:1fr auto;gap:10px;background:#0b0b0b;border:1px solid #222;border-radius:10px;padding:12px;margin-bottom:9px}
          .card.new-plugin{border-color:#26653d}.card.has-update{border-color:#603030}.name{font-weight:700;font-size:14px}.meta{color:#999;margin-top:5px}.ok{color:#54d17a}.warn{color:#f0b84d}.new{color:#67e58d;font-weight:700}.outdated{color:#ff6565;font-weight:700}
          .card .btns{display:flex;gap:6px;align-items:center}.small{padding:7px 9px;font-size:12px}.disabled{opacity:.35;pointer-events:none}.install{border-color:#28673e;color:#72e597}.update{border-color:#8e3131;color:#ff6969}
          #toast{position:fixed;left:16px;right:16px;bottom:14px;background:#141414;border:1px solid #333;border-radius:9px;padding:10px 12px;display:none;z-index:5}#toast.ok{border-color:#265f36;color:#7ee39b}#toast.err{border-color:#6b2424;color:#ff7a7a}#toast.warn{border-color:#6d5522;color:#ffd16a}
          </style></head><body>
          <div class="top"><h1>VADA Plugin Manager</h1><div class="ver">Phiên bản #{VERSION} · Công ty TNHH VADA</div>
          <div class="actions"><button class="primary" onclick="sketchup.checkUpdates()">↻ Kiểm tra cập nhật</button><button onclick="sketchup.updateAll()">⇩ Cài/Cập nhật tất cả</button><button onclick="sketchup.reloadAll()">⟳ Reload tất cả</button><button onclick="sketchup.refresh()">Làm mới</button></div></div>
          <div class="body"><div class="summary" id="summary">Chưa quét GitHub trong phiên này</div><div id="list"></div></div><div id="toast"></div>
          <script>
          function esc(s){return String(s??'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]))}
          function card(p){const installed=p.installed?'<span class="ok">● Đã cài</span>':'<span class="warn">● Chưa cài</span>';let state='';let cls='';let btn='';if(!p.installed&&p.rbz_url){state='<span class="new">Plugin mới</span>';cls='new-plugin';btn=`<button class="small install" onclick="sketchup.updatePlugin('${esc(p.id)}')">Cài mới</button>`}else if(p.installed&&p.update_available){state='<span class="outdated">Có bản mới</span>';cls='has-update';btn=`<button class="small update" onclick="sketchup.updatePlugin('${esc(p.id)}')">Cập nhật</button>`}else{state='<span class="ok">Mới nhất</span>';btn='<button class="small disabled">Cập nhật</button>'}const reload=`<button class="small ${p.reloadable?'':'disabled'}" onclick="sketchup.reloadPlugin('${esc(p.id)}')">Reload</button>`;const rbz=p.rbz_url?'Có RBZ':'Chưa có RBZ';return `<div class="card ${cls}"><div><div class="name">${esc(p.name)}</div><div class="meta">Máy: <b>${esc(p.local_version)}</b> · GitHub: <b>${esc(p.latest_version||'-')}</b> · ${installed} · ${state} · ${esc(rbz)}</div></div><div class="btns">${btn}${reload}</div></div>`}
          function renderState(state){const list=state.plugins||[];document.getElementById('summary').textContent=state.last_check?`Quét GitHub lúc ${state.last_check} · ${state.new_count||0} plugin mới · ${state.update_count||0} plugin có bản mới`:'Chưa quét GitHub trong phiên này';const root=document.getElementById('list');root.innerHTML='';let groups=[['Plugin mới chưa cài',list.filter(p=>!p.installed&&p.rbz_url)],['Có bản cập nhật',list.filter(p=>p.installed&&p.update_available)],['Đã cài / mới nhất',list.filter(p=>p.installed&&!p.update_available)],['Chưa nhận diện / chưa có gói cài',list.filter(p=>!p.installed&&!p.rbz_url)]];groups.forEach(g=>{if(!g[1].length)return;root.innerHTML+=`<div class="section-title">${g[0]}</div>`+g[1].map(card).join('')})}
          function toast(msg,type='ok'){const t=document.getElementById('toast');t.className=type;t.textContent=msg;t.style.display='block';clearTimeout(window.__tt);window.__tt=setTimeout(()=>t.style.display='none',5000)}
          </script></body></html>
        HTML
      end

      def install_ui
        cmd = UI::Command.new('VADA Plugin Manager') { show }
        icon = File.join(__dir__, 'icon.png')
        if File.file?(icon)
          cmd.small_icon = icon
          cmd.large_icon = icon
        end
        cmd.tooltip = 'VADA Plugin Manager - Cài mới, cập nhật và reload plugin'
        cmd.status_bar_text = 'Quản lý plugin VADA'
        toolbar = UI::Toolbar.new('VADA Plugin Manager')
        toolbar.add_item(cmd)
        toolbar.restore
        UI.menu('Extensions').add_item(cmd)
      end
    end

    unless file_loaded?(__FILE__)
      install_ui
      file_loaded(__FILE__)
    end
  end
end
