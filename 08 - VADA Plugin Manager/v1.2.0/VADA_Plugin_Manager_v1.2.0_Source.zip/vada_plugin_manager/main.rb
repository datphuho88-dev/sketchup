# frozen_string_literal: true
require 'sketchup.rb'
require 'json'
require 'net/http'
require 'uri'
require 'tmpdir'

module VADA
  module PluginManager
    VERSION = '1.2.0' unless const_defined?(:VERSION)
    OWNER = 'datphuho88-dev'
    REPO = 'sketchup'
    BRANCH = 'main'
    MANIFEST_URL = "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/vada_plugin_manifest.json"
    TREE_URL = "https://api.github.com/repos/#{OWNER}/#{REPO}/git/trees/#{BRANCH}?recursive=1"
    PLUGINS_DIR = Sketchup.find_support_file('Plugins')

    class << self
      def show
        @dialog ||= build_dialog
        refresh_ui
        @dialog.show
      end

      def build_dialog
        dlg = UI::HtmlDialog.new(
          dialog_title: "VADA Plugin Manager v#{VERSION}",
          preferences_key: 'vada_plugin_manager',
          scrollable: true,
          resizable: true,
          width: 790,
          height: 620,
          style: UI::HtmlDialog::STYLE_DIALOG
        )
        dlg.set_html(html)
        dlg.add_action_callback('refresh') { |_c| refresh_ui }
        dlg.add_action_callback('checkUpdates') { |_c| check_updates }
        dlg.add_action_callback('reloadPlugin') { |_c, id| reload_plugin(id.to_s) }
        dlg.add_action_callback('updatePlugin') { |_c, id| update_plugin(id.to_s) }
        dlg.add_action_callback('reloadAll') { |_c| reload_all }
        dlg.add_action_callback('updateAll') { |_c| update_all }
        dlg
      end

      def local_plugins
        manifest = cached_manifest || fallback_manifest
        exts = extension_inventory
        manifest.fetch('plugins', []).map do |plugin|
          p = plugin.dup
          ext = resolve_extension(p, exts)
          loader = resolve_loader(p, ext)
          p['loader'] = loader
          p['installed'] = !ext.nil? || !loader.nil?
          p['local_version'] = detect_local_version(loader, p, ext)
          p['detect_source'] = ext ? 'Extension' : (loader ? 'File' : '-')
          p['reloadable'] = !loader.nil? && p.fetch('hot_reload', true)
          p['update_available'] = p['installed'] && update_available?(p['local_version'], p['latest_version'])
          p
        end
      end

      def extension_inventory
        list = []
        begin
          Sketchup.extensions.each { |ext| list << ext }
        rescue StandardError
        end
        list
      end

      def normalize_text(value)
        s = value.to_s.tr('đĐ', 'dD')
        begin
          s = s.unicode_normalize(:nfkd).gsub(/\p{Mn}/, '')
        rescue StandardError
        end
        s.downcase.gsub(/[^a-z0-9]+/, ' ').strip
      end

      def meaningful_tokens(value)
        stop = %w[vada plugin sketchup extension tool cong cu]
        normalize_text(value).split.reject { |t| t.length < 2 || stop.include?(t) }
      end

      def plugin_aliases(plugin)
        ([plugin['name']] + Array(plugin['extension_names']) + Array(plugin['detect_tokens'])).compact.map(&:to_s).reject(&:empty?).uniq
      end

      def resolve_extension(plugin, extensions = nil)
        extensions ||= extension_inventory
        aliases = plugin_aliases(plugin)
        normalized_aliases = aliases.map { |a| normalize_text(a) }.reject(&:empty?)

        exact = extensions.find do |ext|
          n = normalize_text(ext.respond_to?(:name) ? ext.name : '')
          normalized_aliases.include?(n)
        end
        return exact if exact

        extensions.each do |ext|
          ext_name = ext.respond_to?(:name) ? ext.name.to_s : ''
          en = normalize_text(ext_name)
          next if en.empty?

          return ext if normalized_aliases.any? { |a| a.length >= 6 && (en.include?(a) || a.include?(en)) }

          et = meaningful_tokens(ext_name)
          aliases.each do |a|
            at = meaningful_tokens(a)
            common = et & at
            return ext if common.length >= 2 && common.length >= [at.length, 2].min
          end
        end
        nil
      end

      def extension_version(ext)
        return nil unless ext
        return nil unless ext.respond_to?(:version)
        v = ext.version.to_s.strip
        v.empty? ? nil : v
      rescue StandardError
        nil
      end

      def extension_loader_path(ext)
        return nil unless ext
        [:extension_path, :loader_path, :path].each do |method_name|
          next unless ext.respond_to?(method_name)
          begin
            value = ext.public_send(method_name).to_s
            next if value.empty?
            candidates = [value]
            candidates << File.join(PLUGINS_DIR, value) unless absolute_path?(value)
            candidates.each { |p| return p if File.file?(p) }
          rescue StandardError
          end
        end
        nil
      end

      def absolute_path?(path)
        !!(path =~ /\A([A-Za-z]:[\\\/]|[\\\/]{2}|\/)/)
      end

      def resolve_loader(plugin, ext = nil)
        Array(plugin['loader_candidates']).each do |rel|
          path = File.join(PLUGINS_DIR, rel)
          return path if File.file?(path)
        end

        ext_path = extension_loader_path(ext)
        return ext_path if ext_path

        scan_loader(plugin)
      end

      def root_rb_files
        @root_rb_files = Dir.glob(File.join(PLUGINS_DIR, '*.rb')).select { |p| File.file?(p) }
      rescue StandardError
        []
      end

      def scan_loader(plugin)
        aliases = plugin_aliases(plugin)
        aliases += Array(plugin['loader_hints'])
        alias_norms = aliases.map { |a| normalize_text(a) }.reject { |x| x.length < 4 }
        id_norm = normalize_text(plugin['id'].to_s.tr('_', ' '))

        # 1) Ưu tiên tên file gần với id/tên plugin.
        root_rb_files.each do |path|
          base = normalize_text(File.basename(path, '.rb'))
          next if base.empty?
          return path if !id_norm.empty? && (base.include?(id_norm) || id_norm.include?(base))
          return path if alias_norms.any? { |a| base.length >= 5 && (base.include?(a) || a.include?(base)) }
        end

        # 2) Dò nội dung file loader. Chỉ đọc tối đa 256 KB/file để không gây lag.
        root_rb_files.each do |path|
          begin
            raw = File.open(path, 'rb') { |f| f.read(262_144) }.to_s.force_encoding('UTF-8').scrub
            norm = normalize_text(raw)
            return path if alias_norms.any? { |a| a.length >= 6 && norm.include?(a) }
          rescue StandardError
          end
        end
        nil
      end

      def parse_version_from_file(path)
        return nil unless path && File.file?(path)
        text = File.open(path, 'rb') { |f| f.read(262_144) }.to_s.force_encoding('UTF-8').scrub
        patterns = [
          /(?:VERSION|PLUGIN_VERSION|EXTENSION_VERSION)\s*=\s*['\"]v?([^'\"]+)['\"]/i,
          /\.version\s*=\s*['\"]v?([^'\"]+)['\"]/i,
          /\bv(\d+\.\d+\.\d+)\b/i
        ]
        patterns.each do |re|
          m = text.match(re)
          return m[1].strip if m
        end
        nil
      rescue StandardError
        nil
      end

      def detect_local_version(loader, plugin, ext = nil)
        versions = []
        fv = parse_version_from_file(loader)
        ev = extension_version(ext)
        versions << fv if semantic_version?(fv)
        versions << ev if semantic_version?(ev)
        return versions.max { |a, b| compare_versions(a, b) } unless versions.empty?
        return ev if ev && !ev.empty?
        return fv if fv && !fv.empty?
        plugin['installed_version'] || (ext || loader ? 'đã cài' : '-')
      end

      def semantic_version?(value)
        !!(value.to_s =~ /\d+\.\d+(?:\.\d+)?/)
      end

      def update_available?(local, remote)
        return false if remote.to_s.empty?
        return true if local.to_s == 'đã cài'
        return false if local.to_s == '-'
        compare_versions(remote, local) > 0
      end

      def compare_versions(a, b)
        aa = a.to_s.scan(/\d+/).map(&:to_i)
        bb = b.to_s.scan(/\d+/).map(&:to_i)
        len = [aa.length, bb.length, 3].max
        aa += [0] * (len - aa.length)
        bb += [0] * (len - bb.length)
        aa <=> bb
      end

      def http_get(url, timeout = 10)
        uri = URI(url)
        req = Net::HTTP::Get.new(uri)
        req['User-Agent'] = "VADA-Plugin-Manager/#{VERSION}"
        req['Accept'] = 'application/vnd.github+json' if uri.host == 'api.github.com'
        res = Net::HTTP.start(uri.host, uri.port, use_ssl: true, open_timeout: 5, read_timeout: timeout) { |h| h.request(req) }
        return http_get(res['location'], timeout) if res.is_a?(Net::HTTPRedirection)
        raise "HTTP #{res.code}" unless res.is_a?(Net::HTTPSuccess)
        res.body
      end

      def fetch_manifest
        @manifest = JSON.parse(http_get(MANIFEST_URL, 8))
        @root_rb_files = nil
      end

      def fetch_tree
        JSON.parse(http_get(TREE_URL, 15)).fetch('tree', [])
      end

      def cached_manifest
        @manifest
      end

      def fallback_manifest
        {'plugins'=>[
          {'id'=>'tong_dien_tich','name'=>'Tổng diện tích','latest_version'=>'1.0.0','repo_path'=>'VADA-Tong-Dien-Tich','extension_names'=>['VADA Tổng Diện Tích'],'loader_candidates'=>['vada_tong_dien_tich.rb'],'hot_reload'=>true},
          {'id'=>'tong_do_dai_canh','name'=>'Tổng độ dài cạnh','latest_version'=>'1.0.1','repo_path'=>'05 - Tính tổng độ dài cạnh','extension_names'=>['VADA Tổng Độ Dài Cạnh'],'loader_candidates'=>['vada_tong_do_dai_canh.rb'],'hot_reload'=>true},
          {'id'=>'thong_ke_sat_hop','name'=>'Thống kê sắt hộp','latest_version'=>'1.1.1','repo_path'=>'06 - Thống kê sắt hộp','extension_names'=>['VADA Thống Kê Sắt Hộp','Thống Kê Sắt Hộp'],'loader_candidates'=>['vada_thong_ke_sat_hop.rb','thong_ke_sat_hop.rb'],'hot_reload'=>true}
        ]}
      end

      def enrich_from_tree!(tree)
        files = tree.select { |e| e['type'] == 'blob' }.map { |e| e['path'].to_s }
        dirs  = tree.select { |e| e['type'] == 'tree' }.map { |e| e['path'].to_s }

        @manifest.fetch('plugins', []).each do |p|
          base = p['repo_path'].to_s.sub(%r{/+$}, '')
          next if base.empty?

          versions = dirs.filter_map do |path|
            next unless path.start_with?(base + '/')
            rest = path[(base.length + 1)..-1]
            next if rest.include?('/')
            m = rest.match(/^v?(\d+\.\d+\.\d+)$/i)
            m && [m[1], path]
          end

          if versions.any?
            latest = versions.max { |x, y| compare_versions(x[0], y[0]) }
            p['latest_version'] = latest[0]
            rbz = files.find { |path| path.start_with?(latest[1] + '/') && path.downcase.end_with?('.rbz') }
            p['rbz_url'] = rbz ? raw_url(rbz) : ''
            next
          end

          release_rbzs = files.select do |path|
            path.start_with?(base + '/releases/') && path.downcase.end_with?('.rbz')
          end
          candidates = release_rbzs.filter_map do |path|
            m = File.basename(path).match(/v?(\d+\.\d+\.\d+)/i)
            m && [m[1], path]
          end
          if candidates.any?
            latest = candidates.max { |x, y| compare_versions(x[0], y[0]) }
            p['latest_version'] = latest[0]
            p['rbz_url'] = raw_url(latest[1])
          end
        end
      end

      def raw_url(path)
        return '' if path.to_s.empty?
        encoded = path.split('/').map { |seg| URI::DEFAULT_PARSER.escape(seg) }.join('/')
        "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/#{encoded}"
      end

      def check_updates
        begin
          fetch_manifest
          tree = fetch_tree
          enrich_from_tree!(tree)
          @last_check = Time.now
          count = local_plugins.count { |p| p['update_available'] }
          toast("Đã quét GitHub · #{count} plugin có bản mới", 'ok')
        rescue => e
          toast("Không kiểm tra được GitHub: #{escape_js(e.message)}", 'err')
        ensure
          refresh_ui
        end
      end

      def reload_plugin(id)
        p = local_plugins.find { |x| x['id'] == id }
        return toast('Không tìm thấy plugin', 'err') unless p
        return toast('Plugin chưa được cài', 'err') unless p['installed']
        return toast('Chưa xác định được file để reload an toàn. Hãy khởi động lại SketchUp.', 'warn') unless p['reloadable']
        begin
          load p['loader']
          toast("Đã nạp lại: #{escape_js(p['name'])}", 'ok')
          refresh_ui
        rescue Exception => e
          toast("Lỗi reload #{escape_js(p['name'])}: #{escape_js(e.message)}", 'err')
        end
      end

      def reload_all
        ok = 0
        fail = 0
        skipped = 0
        local_plugins.each do |p|
          next unless p['installed']
          unless p['reloadable']
            skipped += 1
            next
          end
          begin
            load p['loader']
            ok += 1
          rescue Exception
            fail += 1
          end
        end
        toast("Reload: #{ok} thành công · #{fail} lỗi · #{skipped} bỏ qua", fail.zero? ? 'ok' : 'warn')
        refresh_ui
      end

      def update_plugin(id)
        p = local_plugins.find { |x| x['id'] == id }
        return toast('Không tìm thấy plugin', 'err') unless p
        return toast('Plugin này đang là bản mới nhất', 'ok') unless p['update_available']
        url = p['rbz_url'].to_s
        return toast('Không tìm thấy gói RBZ cho phiên bản mới nhất', 'warn') if url.empty?
        path = nil
        begin
          path = download(url, "vada_update_#{id}.rbz")
          raise 'Bản SketchUp này không hỗ trợ cài archive tự động.' unless Sketchup.respond_to?(:install_from_archive)
          result = Sketchup.install_from_archive(path)
          raise 'SketchUp không cài được gói RBZ.' unless result
          @root_rb_files = nil

          refreshed = local_plugins.find { |x| x['id'] == id } || p
          if p.fetch('hot_reload', true) && refreshed['loader']
            load refreshed['loader']
            toast("Đã cập nhật và reload: #{escape_js(p['name'])}", 'ok')
          else
            toast("Đã cập nhật #{escape_js(p['name'])}. Cần khởi động lại SketchUp để nạp mã mới.", 'warn')
          end
        rescue => e
          toast("Cập nhật lỗi: #{escape_js(e.message)}", 'err')
        ensure
          begin File.delete(path) if path && File.file?(path); rescue StandardError; end
          refresh_ui
        end
      end

      def update_all
        list = local_plugins.select { |p| p['update_available'] && !p['rbz_url'].to_s.empty? }
        return toast('Tất cả plugin có gói RBZ đều đang là bản mới nhất', 'ok') if list.empty?
        success = 0
        failed = 0
        restart_needed = 0

        list.each do |p|
          path = nil
          begin
            path = download(p['rbz_url'], "vada_update_#{p['id']}.rbz")
            raise 'Không hỗ trợ install_from_archive' unless Sketchup.respond_to?(:install_from_archive)
            raise 'Cài đặt thất bại' unless Sketchup.install_from_archive(path)
            @root_rb_files = nil
            refreshed = local_plugins.find { |x| x['id'] == p['id'] }
            if p.fetch('hot_reload', true) && refreshed && refreshed['loader']
              begin
                load refreshed['loader']
              rescue Exception
                restart_needed += 1
              end
            else
              restart_needed += 1
            end
            success += 1
          rescue StandardError
            failed += 1
          ensure
            begin File.delete(path) if path && File.file?(path); rescue StandardError; end
          end
        end
        msg = "Cập nhật: #{success} thành công · #{failed} lỗi"
        msg += " · #{restart_needed} cần restart" if restart_needed > 0
        toast(msg, failed.zero? && restart_needed.zero? ? 'ok' : 'warn')
        refresh_ui
      end

      def download(url, filename)
        body = http_get(url, 30)
        path = File.join(Dir.tmpdir, filename)
        File.binwrite(path, body)
        path
      end

      def refresh_ui
        return unless @dialog
        payload = {
          plugins: local_plugins,
          last_check: @last_check ? @last_check.strftime('%H:%M:%S') : nil
        }
        @dialog.execute_script("renderState(#{JSON.generate(payload)});")
      end

      def toast(message, type='ok')
        return unless @dialog
        @dialog.execute_script("toast('#{escape_js(message)}','#{type}')")
      end

      def escape_js(str)
        str.to_s.gsub('\\', '\\\\').gsub("'", "\\'").gsub("\r", '').gsub("\n", '\\n')
      end

      def html
        <<~HTML
        <!doctype html><html><head><meta charset="utf-8"><style>
        *{box-sizing:border-box}body{margin:0;background:#000;color:#eee;font-family:Segoe UI,Arial,sans-serif;font-size:13px}
        .top{position:sticky;top:0;background:#050505;border-bottom:1px solid #222;padding:14px 16px;z-index:2}
        h1{font-size:18px;margin:0 0 3px;color:#fff}.ver{color:#888}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
        button{background:#171717;color:#fff;border:1px solid #333;border-radius:8px;padding:8px 11px;cursor:pointer;font-weight:600}button:hover{background:#242424}.primary{border-color:#c00;color:#ff4d4d}
        .body{padding:12px 16px 70px}.summary{color:#888;margin:0 0 10px}.card{display:grid;grid-template-columns:1fr auto;gap:10px;background:#0b0b0b;border:1px solid #222;border-radius:10px;padding:12px;margin-bottom:9px}
        .card.has-update{border-color:#603030}.name{font-weight:700;font-size:14px}.meta{color:#999;margin-top:5px}.sub{color:#666;margin-top:3px;font-size:11px}.ok{color:#54d17a}.warn{color:#f0b84d}.new{color:#ff6565;font-weight:700}
        .card .btns{display:flex;gap:6px;align-items:center}.small{padding:7px 9px;font-size:12px}.disabled{opacity:.38;pointer-events:none}.update{border-color:#8e3131;color:#ff6969}
        #toast{position:fixed;left:16px;right:16px;bottom:14px;background:#141414;border:1px solid #333;border-radius:9px;padding:10px 12px;display:none;z-index:5}#toast.ok{border-color:#265f36;color:#7ee39b}#toast.err{border-color:#6b2424;color:#ff7a7a}#toast.warn{border-color:#6d5522;color:#ffd16a}
        </style></head><body>
        <div class="top"><h1>VADA Plugin Manager</h1><div class="ver">Phiên bản #{VERSION} · Công ty TNHH VADA</div>
        <div class="actions"><button class="primary" onclick="sketchup.checkUpdates()">↻ Kiểm tra cập nhật</button><button onclick="sketchup.updateAll()">⇩ Cập nhật tất cả</button><button onclick="sketchup.reloadAll()">⟳ Reload tất cả</button><button onclick="sketchup.refresh()">Làm mới</button></div></div>
        <div class="body"><div class="summary" id="summary">Chưa quét GitHub trong phiên này</div><div id="list"></div></div><div id="toast"></div>
        <script>
        function esc(s){return String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
        function renderState(state){const list=state.plugins||[];const root=document.getElementById('list');const n=list.filter(p=>p.update_available).length;document.getElementById('summary').textContent=state.last_check?`Quét GitHub lúc ${state.last_check} · ${n} plugin có bản mới`:'Chưa quét GitHub trong phiên này';root.innerHTML='';list.forEach(p=>{const installed=p.installed?'<span class="ok">● Đã cài</span>':'<span class="warn">● Chưa nhận diện</span>';const version=p.installed?(p.update_available?'<span class="new">Có bản mới</span>':'<span class="ok">Mới nhất</span>'):'<span class="warn">Không rõ</span>';const rbz=p.rbz_url?'Có RBZ':'Chưa có RBZ';const source=p.installed?`<div class="sub">Nhận diện: ${esc(p.detect_source||'-')}</div>`:'';root.innerHTML+=`<div class="card ${p.update_available?'has-update':''}"><div><div class="name">${esc(p.name)}</div><div class="meta">Máy: <b>${esc(p.local_version)}</b> · GitHub: <b>${esc(p.latest_version||'-')}</b> · ${installed} · ${version} · ${esc(rbz)}</div>${source}</div><div class="btns"><button class="small update ${p.update_available&&p.rbz_url?'':'disabled'}" onclick="sketchup.updatePlugin('${esc(p.id)}')">Cập nhật</button><button class="small ${p.reloadable?'':'disabled'}" onclick="sketchup.reloadPlugin('${esc(p.id)}')">Reload</button></div></div>`})}
        function toast(msg,type='ok'){const t=document.getElementById('toast');t.className=type;t.textContent=msg;t.style.display='block';clearTimeout(window.__tt);window.__tt=setTimeout(()=>t.style.display='none',4500)}
        </script></body></html>
        HTML
      end

      def install_ui
        cmd = UI::Command.new('VADA Plugin Manager') { show }
        icon = File.join(__dir__, 'icon.png')
        if File.file?(icon)
          cmd.small_icon = icon
          cmd.large_icon = icon
        end
        cmd.tooltip = 'VADA Plugin Manager - Cập nhật và reload plugin'
        cmd.status_bar_text = 'Quản lý và cập nhật plugin VADA'
        toolbar = UI::Toolbar.new('VADA Plugin Manager')
        toolbar.add_item(cmd)
        toolbar.restore
        UI.menu('Extensions').add_item(cmd)
      end
    end

    unless file_loaded?(__FILE__)
      install_ui
      file_loaded(__FILE__)
    end
  end
end
