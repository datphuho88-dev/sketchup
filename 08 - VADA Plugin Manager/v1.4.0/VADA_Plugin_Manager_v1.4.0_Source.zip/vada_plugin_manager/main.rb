# frozen_string_literal: true
require 'sketchup.rb'
require 'json'
require 'net/http'
require 'uri'
require 'tmpdir'
require 'fileutils'
require 'digest'
require 'base64'
require 'open3'
require 'time'

module VADA
  module PluginManager
    VERSION = '1.4.0' unless const_defined?(:VERSION)
    OWNER = 'datphuho88-dev'
    REPO = 'sketchup'
    BRANCH = 'main'
    MANIFEST_URL = "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/vada_plugin_manifest.json"
    EXTERNAL_MANIFEST_PATH = 'external_plugins_manifest.json'
    EXTERNAL_MANIFEST_URL = "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/#{EXTERNAL_MANIFEST_PATH}"
    TREE_URL = "https://api.github.com/repos/#{OWNER}/#{REPO}/git/trees/#{BRANCH}?recursive=1"
    EXTERNAL_REPO_DIR = '90 - Kho plugin ngoài'
    PLUGINS_DIR = Sketchup.find_support_file('Plugins')
    MAX_PUBLIC_BACKUP_BYTES = 25 * 1024 * 1024

    class << self
      def show
        @dialog = build_dialog if @dialog.nil?
        @dialog.show
      rescue StandardError => e
        UI.messagebox("VADA Plugin Manager không mở được:\n#{e.message}")
        @dialog = nil
      end

      def build_dialog
        dlg = UI::HtmlDialog.new(
          dialog_title: "VADA Plugin Manager v#{VERSION}",
          preferences_key: 'vada_plugin_manager',
          scrollable: true,
          resizable: true,
          width: 930,
          height: 720,
          style: UI::HtmlDialog::STYLE_DIALOG
        )
        dlg.set_html(html)
        dlg.add_action_callback('ready') { |_c| dialog_ready }
        dlg.add_action_callback('refresh') { |_c| refresh_ui }
        dlg.add_action_callback('checkUpdates') { |_c| check_updates }
        dlg.add_action_callback('reloadPlugin') { |_c, id| reload_plugin(id.to_s) }
        dlg.add_action_callback('updatePlugin') { |_c, id| update_plugin(id.to_s) }
        dlg.add_action_callback('reloadAll') { |_c| reload_all }
        dlg.add_action_callback('updateAll') { |_c| update_all }
        dlg.add_action_callback('setGithubToken') { |_c, token| set_github_token(token.to_s) }
        dlg.add_action_callback('clearGithubToken') { |_c| clear_github_token }
        dlg.add_action_callback('refreshExternal') { |_c| refresh_external_catalog }
        dlg.add_action_callback('backupExternal') { |_c, json| backup_external(json.to_s) }
        dlg.add_action_callback('saveExternalMetadata') { |_c, json| save_external_metadata(json.to_s) }
        dlg.add_action_callback('installExternal') { |_c, key| install_external(key.to_s) }
        dlg.set_on_closed do
          @dialog_ready = false
          @dialog = nil
          @github_token = nil
        end
        dlg
      end

      def dialog_ready
        @dialog_ready = true
        refresh_ui
        return if @auto_check_running
        @auto_check_running = true
        UI.start_timer(0.15, false) do
          begin
            check_updates(auto: true)
            refresh_external_catalog(auto: true)
          ensure
            @auto_check_running = false
          end
        end
      end

      def normalize_text(value)
        value.to_s.downcase.unicode_normalize(:nfkd)
             .encode('ASCII', replace: '', undef: :replace, invalid: :replace)
             .gsub(/[^a-z0-9]+/, ' ').strip
      rescue StandardError
        value.to_s.downcase
      end

      def slug(value)
        s = normalize_text(value).tr(' ', '-')
        s.empty? ? 'plugin' : s
      end

      def compare_versions(a, b)
        aa = a.to_s.scan(/\d+/).map(&:to_i)
        bb = b.to_s.scan(/\d+/).map(&:to_i)
        len = [aa.length, bb.length, 3].max
        (aa + [0] * (len - aa.length)) <=> (bb + [0] * (len - bb.length))
      end

      def safe_call(object, method)
        object.respond_to?(method) ? object.public_send(method) : nil
      rescue StandardError
        nil
      end

      def extension_snapshot
        Sketchup.extensions.map do |ext|
          path = nil
          [:extension_path, :path].each do |method|
            value = safe_call(ext, method)
            if value && !value.to_s.empty?
              path = value.to_s
              break
            end
          end
          {
            name: safe_call(ext, :name).to_s,
            version: safe_call(ext, :version).to_s,
            path: path,
            creator: safe_call(ext, :creator).to_s,
            description: safe_call(ext, :description).to_s,
            copyright: safe_call(ext, :copyright).to_s,
            extension_id: safe_call(ext, :id).to_s,
            version_id: safe_call(ext, :version_id).to_s,
            loaded: !!safe_call(ext, :loaded?)
          }
        end
      rescue StandardError
        []
      end

      def fallback_manifest
        {
          'plugins' => [
            { 'id'=>'ghi_kich_thuoc_tu_dong','name'=>'Ghi kích thước tự động','latest_version'=>'1.1.0','repo_path'=>'01 - Ghi kích thước tự động','loader_candidates'=>['vada_auto_dim.rb','vada_ghi_kich_thuoc_tu_dong.rb','vada_auto_dim_ban_tron.rb','auto_dim_ban_tron.rb'],'extension_names'=>['VADA Auto Dim','VADA Auto Dim Bàn Tròn','Auto Dim Bàn Tròn','Ghi kích thước tự động'],'detect_tokens'=>['Auto Dim','Bàn Tròn','Ghi kích thước'],'hot_reload'=>false },
            { 'id'=>'don_plugin_rac','name'=>'Dọn plugin rác','latest_version'=>'1.4.1','repo_path'=>'02 - Dọn plugin rác','loader_candidates'=>['vada_extension_cleaner.rb','vada_don_plugin_rac.rb'],'hot_reload'=>false },
            { 'id'=>'tim_cong_cu_nhanh','name'=>'Tìm công cụ nhanh','latest_version'=>'0.4.2','repo_path'=>'03 - Tìm công cụ nhanh','loader_candidates'=>['quick_tool_finder.rb','tim_cong_cu_nhanh.rb','vada_quick_tool_finder.rb','vada_tim_cong_cu_nhanh.rb'],'extension_names'=>['Tìm Công Cụ Nhanh','VADA Tìm Công Cụ Nhanh','Quick Tool Finder'],'detect_tokens'=>['Tìm Công Cụ Nhanh','Quick Tool Finder'],'hot_reload'=>false },
            { 'id'=>'mat_cat_goc_nhin','name'=>'Tạo mặt cắt và góc nhìn','latest_version'=>'1.6.0','repo_path'=>'04 - Tạo mặt cắt và góc nhìn','loader_candidates'=>['vada_mat_cat_view.rb'],'reload_candidates'=>['vada_mat_cat_view/main.rb'],'reload_loader'=>false,'extension_names'=>['VADA - Tạo mặt cắt View','VADA Tạo Mặt Cắt & View','VADA Tạo mặt cắt và góc nhìn','Tạo mặt cắt và góc nhìn'],'detect_tokens'=>['Tạo Mặt Cắt','Mặt Cắt','Mat Cat','Section View'],'hot_reload'=>true },
            { 'id'=>'tong_do_dai_canh','name'=>'Tính tổng độ dài cạnh','latest_version'=>'1.0.1','repo_path'=>'05 - Tính tổng độ dài cạnh','loader_candidates'=>['vada_tong_do_dai_canh.rb','VADA_Tong_Do_Dai_Canh.rb'],'hot_reload'=>true },
            { 'id'=>'thong_ke_sat_hop','name'=>'Thống kê sắt hộp','latest_version'=>'1.1.1','repo_path'=>'06 - Thống kê sắt hộp','loader_candidates'=>['vada_thong_ke_sat_hop.rb','VADA_Thong_Ke_Sat_Hop.rb','thong_ke_sat_hop.rb','vada_steel_stats.rb'],'extension_names'=>['VADA Thống Kê Sắt Hộp','Thống Kê Sắt Hộp','VADA Steel Box Statistics'],'detect_tokens'=>['Thống Kê Sắt Hộp','Steel Box'],'hot_reload'=>true },
            { 'id'=>'tong_dien_tich','name'=>'Tính tổng diện tích','latest_version'=>'1.0.1','repo_path'=>'07 - Tính tổng diện tích','loader_candidates'=>['vada_tong_dien_tich.rb'],'hot_reload'=>true },
            { 'id'=>'plugin_manager','name'=>'VADA Plugin Manager','latest_version'=>VERSION,'repo_path'=>'08 - VADA Plugin Manager','loader_candidates'=>['vada_plugin_manager.rb'],'extension_names'=>['VADA Plugin Manager'],'hot_reload'=>false },
            { 'id'=>'tao_phong_nhanh','name'=>'Tạo phòng nhanh','latest_version'=>'1.1.0','repo_path'=>'09 - Tạo phòng nhanh','loader_candidates'=>['vada_quick_room.rb'],'extension_names'=>['VADA Tạo Phòng Nhanh','Tạo phòng nhanh'],'detect_tokens'=>['Tạo Phòng Nhanh','QuickRoom'],'hot_reload'=>true },
            { 'id'=>'workspace_manager','name'=>'VADA Workspace Manager','latest_version'=>'1.0.3','repo_path'=>'10 - VADA Workspace Manager','loader_candidates'=>['vada_workspace_manager.rb'],'extension_names'=>['VADA Workspace Manager'],'detect_tokens'=>['Workspace Manager','VADA Workspace'],'hot_reload'=>false },
            { 'id'=>'style_dim_ghi_chu','name'=>'Quản lý Style Dim & Ghi chú','latest_version'=>'1.2.0','repo_path'=>'11 - Quản lý Style Dim & Ghi chú','loader_candidates'=>['vada_style_dim_notes.rb'],'extension_names'=>['VADA - Quản lý Style Dim & Ghi chú','Quản lý Style Dim & Ghi chú'],'detect_tokens'=>['Style Dim','Ghi chú','Dim Notes'],'hot_reload'=>false }
          ]
        }
      end

      def resolve_loader(plugin)
        Array(plugin['loader_candidates']).each do |rel|
          path = File.join(PLUGINS_DIR, rel.to_s)
          return path if File.file?(path)
        end
        nil
      end

      def detect_version_from_file(path)
        return '' unless path && File.file?(path)
        text = File.read(path, encoding: 'UTF-8', invalid: :replace, undef: :replace, replace: '')
        [
          /(?:PLUGIN_VERSION|EXTENSION_VERSION|VERSION)\s*=\s*['\"]v?([^'\"]+)['\"]/i,
          /\.version\s*=\s*['\"]v?([^'\"]+)['\"]/i,
          /version\s*[:=]\s*['\"]?v?(\d+\.\d+\.\d+)/i
        ].each do |pattern|
          match = text.match(pattern)
          return match[1] if match
        end
        ''
      rescue StandardError
        ''
      end

      def match_extension(plugin, extensions)
        exact = Array(plugin['extension_names']).map { |n| normalize_text(n) }.reject(&:empty?)
        exact_match = extensions.find { |ext| exact.include?(normalize_text(ext[:name])) }
        return exact_match if exact_match
        tokens = (Array(plugin['detect_tokens']) + [plugin['name']]).map { |n| normalize_text(n) }.reject(&:empty?).uniq
        matches = extensions.select do |ext|
          name = normalize_text(ext[:name])
          tokens.any? { |token| name.include?(token) || token.include?(name) }
        end
        matches.max { |a, b| compare_versions(a[:version].to_s, b[:version].to_s) }
      end

      def scan_loader_by_tokens(plugin)
        tokens = (Array(plugin['detect_tokens']) + [plugin['name']]).map { |t| normalize_text(t) }.reject(&:empty?).uniq
        return nil if tokens.empty?
        Dir.glob(File.join(PLUGINS_DIR, '*.rb')).find do |file|
          base = normalize_text(File.basename(file, '.rb'))
          next true if tokens.any? { |token| base.include?(token) || token.include?(base) }
          begin
            sample = File.read(file, 24_000, encoding: 'UTF-8', invalid: :replace, undef: :replace, replace: '')
            normalized = normalize_text(sample)
            tokens.any? { |token| normalized.include?(token) }
          rescue StandardError
            false
          end
        end
      end

      def local_version_candidates(plugin, ext, loader)
        candidates = []
        candidates << ext[:version].to_s if ext && !ext[:version].to_s.empty?
        [loader, (ext && ext[:path]), resolve_reload_target(plugin)].compact.uniq.each do |path|
          version = detect_version_from_file(path)
          candidates << version unless version.to_s.empty?
        end
        candidates.select { |v| v.to_s.match?(/\d+\.\d+(?:\.\d+)?/) }.uniq
      end

      def highest_version(versions)
        versions.max { |a, b| compare_versions(a, b) }
      end

      def detect_local!(plugin, extensions)
        ext = match_extension(plugin, extensions)
        loader = resolve_loader(plugin)
        loader ||= scan_loader_by_tokens(plugin) unless ext
        if ext || loader
          plugin['installed'] = true
          plugin['loader'] = loader
          versions = local_version_candidates(plugin, ext, loader)
          version = highest_version(versions)
          plugin['local_version'] = version.to_s.empty? ? 'đã cài' : version
        else
          plugin['installed'] = false
          plugin['loader'] = nil
          plugin['local_version'] = '-'
        end
      end

      def resolve_reload_target(plugin)
        Array(plugin['reload_candidates']).each do |rel|
          path = File.join(PLUGINS_DIR, rel.to_s)
          return path if File.file?(path)
        end
        loader = resolve_loader(plugin)
        plugin.fetch('reload_loader', true) ? loader : nil
      end

      def update_available?(plugin)
        return false unless plugin['installed']
        local = plugin['local_version'].to_s
        remote = plugin['latest_version'].to_s
        return false if remote.empty?
        return true if local.empty? || local == 'đã cài'
        compare_versions(remote, local) > 0
      end

      def plugin_catalog
        manifest = @manifest || fallback_manifest
        extensions = extension_snapshot
        items = manifest.fetch('plugins', []).map do |source|
          p = source.dup
          detect_local!(p, extensions)
          p['update_available'] = update_available?(p)
          p['reload_target'] = resolve_reload_target(p)
          p['reloadable'] = p['installed'] && p.fetch('hot_reload', false) && !p['reload_target'].to_s.empty?
          p
        end
        items.sort_by do |p|
          rank = if !p['installed'] && !p['rbz_url'].to_s.empty? then 0
                 elsif p['installed'] && p['update_available'] then 1
                 elsif p['installed'] then 2
                 else 3 end
          [rank, p['name'].to_s.downcase]
        end
      end

      # ---------- HTTP / GitHub ----------

      def http_request(uri, req, timeout = 15)
        Net::HTTP.start(uri.host, uri.port, use_ssl: true, open_timeout: 5, read_timeout: timeout) { |h| h.request(req) }
      end

      def http_get(url, timeout = 10)
        uri = URI(url)
        req = Net::HTTP::Get.new(uri)
        req['User-Agent'] = "VADA-Plugin-Manager/#{VERSION}"
        req['Accept'] = 'application/vnd.github+json' if uri.host == 'api.github.com'
        res = http_request(uri, req, timeout)
        return http_get(res['location'], timeout) if res.is_a?(Net::HTTPRedirection)
        raise "HTTP #{res.code}" unless res.is_a?(Net::HTTPSuccess)
        res.body
      end

      def github_api_path(path)
        path.to_s.split('/').map { |seg| URI.encode_www_form_component(seg).gsub('+', '%20') }.join('/')
      end

      def github_request(method, endpoint, body = nil, token = @github_token, timeout = 30)
        raise 'Chưa nhập GitHub token.' if token.to_s.strip.empty?
        uri = URI("https://api.github.com/repos/#{OWNER}/#{REPO}/#{endpoint}")
        klass = { get: Net::HTTP::Get, put: Net::HTTP::Put }[method.to_sym]
        raise 'HTTP method không hỗ trợ' unless klass
        req = klass.new(uri)
        req['User-Agent'] = "VADA-Plugin-Manager/#{VERSION}"
        req['Accept'] = 'application/vnd.github+json'
        req['Authorization'] = "Bearer #{token}"
        req['X-GitHub-Api-Version'] = '2022-11-28'
        if body
          req['Content-Type'] = 'application/json'
          req.body = JSON.generate(body)
        end
        res = http_request(uri, req, timeout)
        unless res.is_a?(Net::HTTPSuccess)
          detail = begin JSON.parse(res.body)['message'] rescue res.body.to_s[0, 240] end
          raise "GitHub HTTP #{res.code}: #{detail}"
        end
        res.body.to_s.empty? ? {} : JSON.parse(res.body)
      end

      def github_file_info(path)
        github_request(:get, "contents/#{github_api_path(path)}?ref=#{URI.encode_www_form_component(BRANCH)}")
      rescue StandardError => e
        return nil if e.message.include?('HTTP 404')
        raise
      end

      def github_put_file(path, bytes, message)
        body = {
          message: message,
          content: Base64.strict_encode64(bytes),
          branch: BRANCH
        }
        current = github_file_info(path)
        body[:sha] = current['sha'] if current && current['sha']
        github_request(:put, "contents/#{github_api_path(path)}", body)
      end

      def set_github_token(token)
        value = token.to_s.strip
        if value.empty?
          @github_token = nil
          toast('Đã xóa GitHub token khỏi phiên làm việc.', 'warn')
        else
          @github_token = value
          toast('Đã nhận GitHub token cho phiên này. Token không được lưu xuống file.', 'ok')
        end
        refresh_ui
      end

      def clear_github_token
        @github_token = nil
        toast('Đã xóa GitHub token khỏi bộ nhớ.', 'ok')
        refresh_ui
      end

      def raw_url(path)
        return '' if path.to_s.empty?
        encoded = path.split('/').map { |seg| URI::DEFAULT_PARSER.escape(seg) }.join('/')
        "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/#{encoded}"
      end

      # ---------- GitHub catalog ----------

      def direct_versions(base, dirs)
        dirs.filter_map do |path|
          next unless path.start_with?(base + '/')
          rest = path[(base.length + 1)..-1]
          next if rest.include?('/')
          m = rest.match(/^v?(\d+\.\d+\.\d+)$/i)
          m && [m[1], path]
        end
      end

      def enrich_plugin!(plugin, files, dirs)
        base = plugin['repo_path'].to_s
        return if base.empty?
        versions = direct_versions(base, dirs)
        if versions.any?
          latest = versions.max { |a, b| compare_versions(a[0], b[0]) }
          plugin['latest_version'] = latest[0]
          rbz = files.find { |path| path.start_with?(latest[1] + '/') && path.downcase.end_with?('.rbz') }
          plugin['rbz_url'] = raw_url(rbz) if rbz
          return
        end
        candidates = files.filter_map do |path|
          next unless path.start_with?(base + '/releases/') && path.downcase.end_with?('.rbz')
          m = File.basename(path).match(/v?(\d+\.\d+\.\d+)/i)
          m && [m[1], path]
        end
        return if candidates.empty?
        latest = candidates.max { |a, b| compare_versions(a[0], b[0]) }
        plugin['latest_version'] = latest[0]
        plugin['rbz_url'] = raw_url(latest[1])
      end

      def discover_unlisted!(manifest, files, dirs)
        known = manifest['plugins'].map { |p| p['repo_path'].to_s }
        dirs.select { |path| !path.include?('/') && path.match?(/^\d+\s*-\s*.+/) }.each do |base|
          next if known.include?(base)
          versions = direct_versions(base, dirs)
          next if versions.empty?
          latest = versions.max { |a, b| compare_versions(a[0], b[0]) }
          rbz = files.find { |path| path.start_with?(latest[1] + '/') && path.downcase.end_with?('.rbz') }
          next unless rbz
          name = base.sub(/^\d+\s*-\s*/, '')
          manifest['plugins'] << {
            'id'=>normalize_text(base).tr(' ','_'), 'name'=>name, 'repo_path'=>base,
            'latest_version'=>latest[0], 'rbz_url'=>raw_url(rbz), 'loader_candidates'=>[],
            'extension_names'=>[name, "VADA #{name}"], 'detect_tokens'=>[name], 'hot_reload'=>false
          }
        end
      end

      def check_updates(auto: false)
        manifest = JSON.parse(http_get(MANIFEST_URL, 8))
        tree = JSON.parse(http_get(TREE_URL, 15)).fetch('tree', [])
        files = tree.select { |e| e['type'] == 'blob' }.map { |e| e['path'].to_s }
        dirs = tree.select { |e| e['type'] == 'tree' }.map { |e| e['path'].to_s }
        manifest.fetch('plugins', []).each { |p| enrich_plugin!(p, files, dirs) }
        discover_unlisted!(manifest, files, dirs)
        @manifest = manifest
        @last_check = Time.now
        toast('Đã quét GitHub trực tiếp.', 'ok') unless auto
      rescue StandardError => e
        toast("Không kiểm tra được GitHub: #{e.message}", 'err') unless auto
      ensure
        refresh_ui
      end

      # ---------- External plugin library ----------

      def vada_extension_names
        (@manifest || fallback_manifest).fetch('plugins', []).flat_map do |p|
          Array(p['extension_names']) + [p['name']]
        end.map { |n| normalize_text(n) }.reject(&:empty?).uniq
      end

      def external_installed_catalog
        known = vada_extension_names
        extension_snapshot.filter_map do |ext|
          n = normalize_text(ext[:name])
          creator = normalize_text(ext[:creator])
          next if n.empty?
          next if known.include?(n)
          next if creator.include?('cong ty tnhh vada') || creator == 'vada'
          path = ext[:path].to_s
          support = standard_support_path(path)
          encrypted = external_encrypted?(path, support)
          packageable = File.file?(path)
          {
            'key' => external_key(ext),
            'name' => ext[:name],
            'version' => ext[:version].to_s.empty? ? 'không rõ' : ext[:version],
            'creator' => ext[:creator].to_s.empty? ? 'Không rõ' : ext[:creator],
            'description' => ext[:description],
            'path' => path,
            'support_path' => support,
            'packageable' => packageable,
            'encrypted' => encrypted,
            'standard' => packageable && (support.nil? || Dir.exist?(support)),
            'loaded' => ext[:loaded]
          }
        end.sort_by { |x| x['name'].to_s.downcase }
      rescue StandardError => e
        puts "[VADA Plugin Manager] external scan: #{e.class}: #{e.message}"
        []
      end

      def external_key(ext)
        Digest::SHA256.hexdigest([normalize_text(ext[:name]), normalize_text(ext[:creator])].join('|'))[0, 16]
      end

      def standard_support_path(loader_path)
        return nil unless loader_path && File.file?(loader_path)
        base = File.basename(loader_path, File.extname(loader_path))
        candidate = File.join(File.dirname(loader_path), base)
        Dir.exist?(candidate) ? candidate : nil
      end

      def external_encrypted?(loader_path, support_path)
        paths = []
        paths << loader_path if loader_path && File.file?(loader_path)
        paths.concat(Dir.glob(File.join(support_path, '**', '*'))) if support_path && Dir.exist?(support_path)
        paths.any? { |p| File.file?(p) && %w[.rbe .rbs].include?(File.extname(p).downcase) }
      rescue StandardError
        false
      end

      def default_external_manifest
        { 'schema' => 1, 'repo' => "#{OWNER}/#{REPO}", 'plugins' => [] }
      end

      def refresh_external_catalog(auto: false)
        @external_manifest = JSON.parse(http_get(EXTERNAL_MANIFEST_URL, 8))
        @external_last_check = Time.now
        toast('Đã tải Kho plugin ngoài từ GitHub.', 'ok') unless auto
      rescue StandardError => e
        @external_manifest ||= default_external_manifest
        toast("Chưa đọc được kho plugin ngoài: #{e.message}", 'warn') unless auto
      ensure
        refresh_ui
      end

      def external_remote_catalog
        manifest = @external_manifest || default_external_manifest
        Array(manifest['plugins']).map do |entry|
          versions = Array(entry['versions'])
          latest = versions.max do |a, b|
            cmp = compare_versions(a['version'].to_s, b['version'].to_s)
            if cmp.zero?
              cmp = (a['metadata_only'] ? 0 : 1) <=> (b['metadata_only'] ? 0 : 1)
            end
            cmp = a['saved_at'].to_s <=> b['saved_at'].to_s if cmp.zero?
            cmp
          end
          latest ||= versions.last
          {
            'key' => entry['key'].to_s,
            'name' => entry['name'].to_s,
            'creator' => entry['creator'].to_s,
            'source_url' => entry['source_url'].to_s,
            'latest_version' => latest && latest['version'].to_s,
            'rbz_url' => latest && latest['rbz_url'].to_s,
            'sha256' => latest && latest['sha256'].to_s,
            'saved_at' => latest && latest['saved_at'].to_s,
            'metadata_only' => latest ? !!latest['metadata_only'] : true
          }
        end.sort_by { |x| x['name'].downcase }
      end

      def find_external_installed(key)
        external_installed_catalog.find { |x| x['key'] == key.to_s }
      end

      def safe_version_folder(version)
        v = version.to_s.strip
        return "v#{v}" if v.match?(/\A\d+(?:\.\d+){1,3}[-+._a-zA-Z0-9]*\z/)
        "vunknown-#{Time.now.strftime('%Y%m%d-%H%M%S')}"
      end

      def powershell_quote(path)
        "'#{path.to_s.gsub("'", "''")}'"
      end

      def package_external_rbz(item)
        loader = item['path'].to_s
        raise 'Không tìm thấy loader .rb của plugin.' unless File.file?(loader)
        support = item['support_path']
        if item['encrypted']
          raise 'Plugin có file .rbe/.rbs đã mã hóa. Không đưa gói này lên repo công khai; chỉ lưu metadata hoặc dùng kho riêng có quyền truy cập.'
        end
        Dir.mktmpdir('vada_external_') do |tmp|
          stage = File.join(tmp, 'stage')
          FileUtils.mkdir_p(stage)
          FileUtils.cp(loader, File.join(stage, File.basename(loader)))
          FileUtils.cp_r(support, File.join(stage, File.basename(support))) if support && Dir.exist?(support)
          out = File.join(tmp, 'plugin.rbz')
          if Sketchup.platform == :platform_win
            command = "Compress-Archive -Path #{powershell_quote(File.join(stage, '*'))} -DestinationPath #{powershell_quote(out)} -Force"
            _stdout, stderr, status = Open3.capture3('powershell.exe', '-NoProfile', '-NonInteractive', '-Command', command)
            raise "Không đóng gói được RBZ: #{stderr.to_s.strip}" unless status.success? && File.file?(out)
          else
            raise 'Bản này hỗ trợ đóng gói tự động trên Windows. Với macOS hãy dùng chức năng lưu metadata.'
          end
          data = File.binread(out)
          raise "RBZ quá lớn (#{(data.bytesize / 1024.0 / 1024.0).round(1)} MB). Giới hạn kho công khai là #{MAX_PUBLIC_BACKUP_BYTES / 1024 / 1024} MB." if data.bytesize > MAX_PUBLIC_BACKUP_BYTES
          return data
        end
      end

      def load_external_manifest_for_write
        info = github_file_info(EXTERNAL_MANIFEST_PATH)
        return default_external_manifest unless info && info['content']
        JSON.parse(Base64.decode64(info['content'].to_s))
      rescue StandardError => e
        return default_external_manifest if e.message.include?('HTTP 404')
        raise
      end

      def update_external_manifest!(manifest, item, source_url:, version_record:)
        manifest['schema'] = 1
        manifest['repo'] = "#{OWNER}/#{REPO}"
        manifest['plugins'] = Array(manifest['plugins'])
        entry = manifest['plugins'].find { |p| p['key'].to_s == item['key'].to_s }
        unless entry
          entry = {
            'key' => item['key'],
            'name' => item['name'],
            'creator' => item['creator'],
            'source_url' => source_url.to_s,
            'versions' => []
          }
          manifest['plugins'] << entry
        end
        entry['name'] = item['name']
        entry['creator'] = item['creator']
        entry['source_url'] = source_url.to_s unless source_url.to_s.strip.empty?
        entry['versions'] = Array(entry['versions'])
        existing = entry['versions'].find { |v| v['version'].to_s == version_record['version'].to_s && !!v['metadata_only'] == !!version_record['metadata_only'] }
        if existing
          existing.merge!(version_record)
        else
          entry['versions'] << version_record
        end
        entry['versions'].sort_by! { |v| v['saved_at'].to_s }
        manifest
      end

      def backup_external(json)
        data = JSON.parse(json)
        item = find_external_installed(data['key'])
        return toast('Không tìm thấy plugin đã cài.', 'err') unless item
        return toast('Cần xác nhận bạn có quyền sao lưu/phân phối plugin này trước khi đưa file lên GitHub.', 'warn') unless data['confirm_rights'] == true
        return toast('Plugin này có file mã hóa .rbe/.rbs; repo công khai chỉ lưu metadata.', 'warn') if item['encrypted']
        rbz = package_external_rbz(item)
        version = item['version'].to_s
        version = 'không-rõ' if version.empty?
        folder = safe_version_folder(version)
        base = "#{EXTERNAL_REPO_DIR}/#{slug(item['name'])}/#{folder}"
        filename = "#{slug(item['name'])}_#{folder}.rbz"
        repo_path = "#{base}/#{filename}"
        sha = Digest::SHA256.hexdigest(rbz)
        github_put_file(repo_path, rbz, "Lưu plugin ngoài: #{item['name']} #{version}")
        record = {
          'version' => version,
          'rbz_url' => raw_url(repo_path),
          'repo_path' => repo_path,
          'sha256' => sha,
          'saved_at' => Time.now.iso8601,
          'metadata_only' => false
        }
        manifest = load_external_manifest_for_write
        update_external_manifest!(manifest, item, source_url: data['source_url'], version_record: record)
        github_put_file(EXTERNAL_MANIFEST_PATH, JSON.pretty_generate(manifest) + "\n", "Cập nhật kho plugin ngoài: #{item['name']}")
        @external_manifest = manifest
        toast("Đã lưu #{item['name']} lên GitHub. PC khác có thể cài từ tab Kho plugin ngoài.", 'ok')
      rescue JSON::ParserError
        toast('Dữ liệu thao tác không hợp lệ.', 'err')
      rescue StandardError => e
        toast("Không lưu được plugin: #{e.message}", 'err')
      ensure
        refresh_ui
      end

      def save_external_metadata(json)
        data = JSON.parse(json)
        item = find_external_installed(data['key'])
        return toast('Không tìm thấy plugin đã cài.', 'err') unless item
        version = item['version'].to_s
        version = 'không-rõ' if version.empty?
        record = {
          'version' => version,
          'rbz_url' => '',
          'repo_path' => '',
          'sha256' => '',
          'saved_at' => Time.now.iso8601,
          'metadata_only' => true
        }
        manifest = load_external_manifest_for_write
        update_external_manifest!(manifest, item, source_url: data['source_url'], version_record: record)
        github_put_file(EXTERNAL_MANIFEST_PATH, JSON.pretty_generate(manifest) + "\n", "Lưu metadata plugin ngoài: #{item['name']}")
        @external_manifest = manifest
        toast("Đã lưu thông tin #{item['name']} lên GitHub.", 'ok')
      rescue JSON::ParserError
        toast('Dữ liệu thao tác không hợp lệ.', 'err')
      rescue StandardError => e
        toast("Không lưu được metadata: #{e.message}", 'err')
      ensure
        refresh_ui
      end

      def install_external(key)
        item = external_remote_catalog.find { |x| x['key'] == key.to_s }
        return toast('Không tìm thấy plugin trong kho GitHub.', 'err') unless item
        return toast('Bản lưu này chỉ có metadata, chưa có RBZ để cài.', 'warn') if item['rbz_url'].to_s.empty?
        path = nil
        begin
          path = download(item['rbz_url'], "external_#{slug(item['name'])}_#{item['latest_version']}.rbz")
          if item['sha256'].to_s != ''
            actual = Digest::SHA256.file(path).hexdigest
            raise 'Checksum RBZ không khớp manifest.' unless actual == item['sha256']
          end
          raise 'SketchUp không hỗ trợ cài RBZ tự động.' unless Sketchup.respond_to?(:install_from_archive)
          raise 'Cài RBZ thất bại.' unless Sketchup.install_from_archive(path)
          toast("Đã cài #{item['name']}. Nên mở lại SketchUp nếu toolbar/menu chưa xuất hiện.", 'ok')
        rescue StandardError => e
          toast("Cài plugin ngoài lỗi: #{e.message}", 'err')
        ensure
          File.delete(path) if path && File.file?(path)
          refresh_ui
        end
      end

      # ---------- Install/update VADA ----------

      def safe_reload(plugin)
        target = resolve_reload_target(plugin)
        return [:restart, nil] unless target
        load target
        [:ok, target]
      rescue Exception => e
        [:error, e.message]
      end

      def reload_plugin(id)
        p = plugin_catalog.find { |x| x['id'] == id }
        return toast('Không tìm thấy plugin', 'err') unless p
        return toast('Plugin này chưa có cấu hình reload an toàn', 'warn') unless p['reloadable']
        status, detail = safe_reload(p)
        status == :ok ? toast("Đã reload: #{p['name']}", 'ok') : toast("Reload lỗi: #{detail}", 'err')
        refresh_ui
      end

      def reload_all
        ok = 0
        fail = 0
        plugin_catalog.each do |p|
          next unless p['reloadable']
          safe_reload(p).first == :ok ? ok += 1 : fail += 1
        end
        toast("Reload xong: #{ok} thành công, #{fail} lỗi", fail.zero? ? 'ok' : 'warn')
        refresh_ui
      end

      def download(url, filename)
        path = File.join(Dir.tmpdir, filename.gsub(/[^0-9A-Za-z._-]+/, '_'))
        File.binwrite(path, http_get(url, 45))
        path
      end

      def update_plugin(id)
        p = plugin_catalog.find { |x| x['id'] == id }
        return toast('Không tìm thấy plugin', 'err') unless p
        return toast('Plugin đang là bản mới nhất', 'ok') if p['installed'] && !p['update_available']
        return toast('Không tìm thấy RBZ', 'warn') if p['rbz_url'].to_s.empty?
        path = nil
        begin
          path = download(p['rbz_url'], "vada_#{p['id']}_#{p['latest_version']}.rbz")
          raise 'SketchUp không hỗ trợ cài RBZ tự động.' unless Sketchup.respond_to?(:install_from_archive)
          raise 'Cài RBZ thất bại.' unless Sketchup.install_from_archive(path)
          if p.fetch('hot_reload', false)
            status, = safe_reload(p)
            if status == :ok
              toast("Đã #{p['installed'] ? 'cập nhật' : 'cài mới'} và reload: #{p['name']}", 'ok')
            else
              toast("Đã #{p['installed'] ? 'cập nhật' : 'cài mới'} #{p['name']}. Cần mở lại SketchUp.", 'warn')
            end
          else
            toast("Đã #{p['installed'] ? 'cập nhật' : 'cài mới'} #{p['name']}. Cần mở lại SketchUp nếu chưa xuất hiện.", 'warn')
          end
        rescue StandardError => e
          toast("Cài đặt lỗi: #{e.message}", 'err')
        ensure
          File.delete(path) if path && File.file?(path)
          refresh_ui
        end
      end

      def update_all
        list = plugin_catalog.select { |p| (!p['installed'] || p['update_available']) && !p['rbz_url'].to_s.empty? }
        return toast('Không có plugin cần cài/cập nhật', 'ok') if list.empty?
        ok = 0
        fail = 0
        list.each do |p|
          path = nil
          begin
            path = download(p['rbz_url'], "vada_#{p['id']}_#{p['latest_version']}.rbz")
            raise 'Không hỗ trợ install_from_archive' unless Sketchup.respond_to?(:install_from_archive)
            raise 'Cài đặt thất bại' unless Sketchup.install_from_archive(path)
            safe_reload(p) if p.fetch('hot_reload', false)
            ok += 1
          rescue StandardError
            fail += 1
          ensure
            File.delete(path) if path && File.file?(path)
          end
        end
        toast("Cài/cập nhật xong: #{ok} thành công, #{fail} lỗi", fail.zero? ? 'ok' : 'warn')
        refresh_ui
      end

      # ---------- UI ----------

      def refresh_ui
        return unless @dialog && @dialog_ready
        list = plugin_catalog
        payload = {
          version: VERSION,
          plugins: list,
          last_check: @last_check ? @last_check.strftime('%H:%M:%S') : nil,
          new_count: list.count { |p| !p['installed'] && !p['rbz_url'].to_s.empty? },
          update_count: list.count { |p| p['installed'] && p['update_available'] },
          external_installed: external_installed_catalog,
          external_remote: external_remote_catalog,
          external_last_check: @external_last_check ? @external_last_check.strftime('%H:%M:%S') : nil,
          github_token_set: !@github_token.to_s.empty?,
          repo: "#{OWNER}/#{REPO}",
          external_repo_dir: EXTERNAL_REPO_DIR
        }
        @dialog.execute_script("renderState(#{JSON.generate(payload)});")
      rescue StandardError => e
        puts "[VADA Plugin Manager] refresh_ui: #{e.class}: #{e.message}"
        @dialog_ready = false
      end

      def toast(message, type='ok')
        return unless @dialog && @dialog_ready
        @dialog.execute_script("toast(#{JSON.generate(message.to_s)},#{JSON.generate(type.to_s)})")
      rescue StandardError
      end

      def html
        <<~HTML
          <!doctype html><html lang="vi"><head><meta charset="utf-8"><style>
          :root{--bg:#000;--panel:#0b0b0b;--panel2:#121212;--line:#292929;--text:#eee;--muted:#8f8f8f;--ok:#65d88a;--warn:#f0b84d;--bad:#ff6868;--blue:#70c8ff}
          *{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Segoe UI,Arial,sans-serif;font-size:13px}.top{position:sticky;top:0;background:#050505;border-bottom:1px solid #222;padding:14px 16px;z-index:3}h1{font-size:18px;margin:0 0 3px}.ver,.summary,.muted{color:var(--muted)}.actions,.tabs,.tokenrow,.finder{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.actions{margin-top:12px}button{background:#171717;color:#fff;border:1px solid #333;border-radius:8px;padding:8px 11px;cursor:pointer;font-weight:600}button:hover{background:#222}.primary{border-color:#a22;color:#ff7070}.install{border-color:#28673e;color:#72e597}.warnbtn{border-color:#735b20;color:#ffd06b}.bluebtn{border-color:#245674;color:#8bd5ff}.disabled{opacity:.35;pointer-events:none}.body{padding:12px 16px 70px}.tabs{margin-bottom:12px}.tab{padding:9px 14px}.tab.active{background:#f2f2f2;color:#000;border-color:#f2f2f2}.panel{display:none}.panel.active{display:block}.section-title{font-size:12px;color:#aaa;margin:16px 2px 8px;text-transform:uppercase}.card{display:grid;grid-template-columns:1fr auto;gap:10px;background:var(--panel);border:1px solid #222;border-radius:10px;padding:12px;margin-bottom:9px}.new-plugin{border-color:#26653d}.has-update{border-color:#603030}.external-card{border-color:#243342}.name{font-weight:700;font-size:14px}.meta{color:#999;margin-top:5px;line-height:1.5}.ok,.new{color:var(--ok)}.warn{color:var(--warn)}.outdated,.bad{color:var(--bad)}.btns{display:flex;gap:6px;align-items:center;flex-wrap:wrap;justify-content:flex-end}.small{padding:7px 9px;font-size:12px}.box{background:#080808;border:1px solid #262626;border-radius:10px;padding:12px;margin-bottom:10px}.notice{background:#120e05;border:1px solid #5a4820;border-radius:9px;padding:10px;color:#e8d08d;line-height:1.5}.tokenrow input,.finder input{background:#111;color:#fff;border:1px solid #333;border-radius:7px;padding:8px 10px}.tokenrow input{min-width:360px;flex:1}.finder input{min-width:250px;flex:1}.pill{display:inline-block;padding:2px 6px;border:1px solid #333;border-radius:999px;font-size:11px;margin-left:5px}.pill.ok{border-color:#28583b}.pill.warn{border-color:#6f5924}.source{max-width:560px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}#toast{position:fixed;left:16px;right:16px;bottom:14px;background:#141414;border:1px solid #333;border-radius:9px;padding:10px 12px;display:none;z-index:5}
          </style></head><body>
          <div class="top"><h1>VADA Plugin Manager</h1><div class="ver">Phiên bản #{VERSION} · Công ty TNHH VADA</div><div class="actions"><button class="primary" onclick="sketchup.checkUpdates()">↻ Kiểm tra cập nhật</button><button onclick="sketchup.updateAll()">⇩ Cài/Cập nhật tất cả VADA</button><button onclick="sketchup.reloadAll()">⟳ Reload tất cả</button><button onclick="sketchup.refresh()">Làm mới</button></div></div>
          <div class="body">
            <div class="tabs"><button class="tab active" data-tab="vada" onclick="showTab('vada')">PLUGIN VADA</button><button class="tab" data-tab="external" onclick="showTab('external')">KHO PLUGIN NGOÀI</button></div>
            <section id="tab-vada" class="panel active"><div class="summary" id="summary">Đang tải danh sách plugin...</div><div id="list"></div></section>
            <section id="tab-external" class="panel">
              <div class="box">
                <div class="notice"><b>Kho plugin ngoài</b> dùng để mang plugin giữa các PC. Repo mặc định <b>#{OWNER}/#{REPO}</b> là repo công khai: chỉ đưa file RBZ lên khi bạn có quyền sao lưu/phân phối. Plugin có file mã hóa <b>.rbe/.rbs</b> sẽ chỉ cho lưu metadata. Token GitHub chỉ giữ trong RAM của phiên SketchUp, không ghi xuống file.</div>
                <div class="tokenrow" style="margin-top:10px"><input id="token" type="password" autocomplete="off" placeholder="GitHub fine-grained token · quyền Contents: Read and write"><button class="bluebtn" onclick="setToken()">DÙNG TOKEN PHIÊN NÀY</button><button onclick="sketchup.clearGithubToken()">XÓA TOKEN</button><span id="tokenState" class="muted"></span></div>
              </div>
              <div class="box"><div class="finder"><input id="extSearch" type="search" placeholder="Tìm plugin ngoài..." oninput="renderExternal()"><button onclick="sketchup.refreshExternal()">↻ QUÉT KHO GITHUB</button></div></div>
              <div class="section-title">Plugin ngoài đang cài trên máy</div><div id="externalInstalled"></div>
              <div class="section-title">Plugin đã lưu trên GitHub · cài nhanh trên PC khác</div><div id="externalRemote"></div>
            </section>
          </div><div id="toast"></div>
          <script>
          let STATE={plugins:[],external_installed:[],external_remote:[]};
          function esc(s){return String(s??'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]))}
          function showTab(name){document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===name));document.querySelectorAll('.panel').forEach(x=>x.classList.toggle('active',x.id==='tab-'+name));}
          function card(p){const installed=p.installed?'<span class="ok">● Đã cài</span>':'<span class="warn">● Chưa cài</span>';let state='',cls='',btn='';if(!p.installed&&p.rbz_url){state='<span class="new">Plugin mới</span>';cls='new-plugin';btn=`<button class="small install" onclick="sketchup.updatePlugin('${esc(p.id)}')">Cài mới</button>`}else if(p.installed&&p.update_available){state='<span class="outdated">Có bản mới</span>';cls='has-update';btn=`<button class="small primary" onclick="sketchup.updatePlugin('${esc(p.id)}')">Cập nhật</button>`}else{state='<span class="ok">Mới nhất</span>';btn='<button class="small disabled">Cập nhật</button>'}const reload=`<button class="small ${p.reloadable?'':'disabled'}" onclick="sketchup.reloadPlugin('${esc(p.id)}')">Reload</button>`;const rbz=p.rbz_url?'Có RBZ':'Chưa có RBZ';return `<div class="card ${cls}"><div><div class="name">${esc(p.name)}</div><div class="meta">Máy: <b>${esc(p.local_version)}</b> · GitHub: <b>${esc(p.latest_version||'-')}</b> · ${installed} · ${state} · ${rbz}</div></div><div class="btns">${btn}${reload}</div></div>`}
          function renderVada(){const list=STATE.plugins||[];document.getElementById('summary').textContent=STATE.last_check?`Quét GitHub lúc ${STATE.last_check} · ${STATE.new_count||0} plugin mới · ${STATE.update_count||0} plugin có bản mới`:'Danh sách cục bộ · đang tự kiểm tra GitHub';const root=document.getElementById('list');root.innerHTML='';[['Plugin mới chưa cài',list.filter(p=>!p.installed&&p.rbz_url)],['Có bản cập nhật',list.filter(p=>p.installed&&p.update_available)],['Đã cài / mới nhất',list.filter(p=>p.installed&&!p.update_available)],['Chưa nhận diện / chưa có gói cài',list.filter(p=>!p.installed&&!p.rbz_url)]].forEach(g=>{if(g[1].length)root.innerHTML+=`<div class="section-title">${g[0]}</div>`+g[1].map(card).join('')})}
          function externalLocalCard(p){const enc=p.encrypted?'<span class="pill warn">MÃ HÓA</span>':'';const standard=p.packageable?'<span class="pill ok">CÓ LOADER</span>':'<span class="pill warn">KHÔNG ĐÓNG GÓI</span>';const backupClass=(!p.packageable||p.encrypted)?'disabled':'';return `<div class="card external-card"><div><div class="name">${esc(p.name)} ${enc} ${standard}</div><div class="meta">Phiên bản: <b>${esc(p.version)}</b> · Tác giả: ${esc(p.creator)}<br><span class="source">${esc(p.path||'')}</span></div></div><div class="btns"><button class="small" data-key="${esc(p.key)}" data-name="${esc(p.name)}" onclick="saveMeta(this.dataset.key,this.dataset.name)">LƯU THÔNG TIN</button><button class="small install ${backupClass}" data-key="${esc(p.key)}" data-name="${esc(p.name)}" onclick="backupExternal(this.dataset.key,this.dataset.name)">ĐÓNG GÓI + LƯU GITHUB</button></div></div>`}
          function externalRemoteCard(p){const meta=p.metadata_only||!p.rbz_url;return `<div class="card external-card"><div><div class="name">${esc(p.name)} ${meta?'<span class="pill warn">CHỈ METADATA</span>':'<span class="pill ok">CÓ RBZ</span>'}</div><div class="meta">Bản lưu: <b>${esc(p.latest_version||'-')}</b> · Tác giả: ${esc(p.creator||'Không rõ')} · ${esc(p.saved_at||'')}<br>${p.source_url?`Nguồn: <span class="source">${esc(p.source_url)}</span>`:''}</div></div><div class="btns"><button class="small install ${meta?'disabled':''}" onclick="sketchup.installExternal('${esc(p.key)}')">CÀI NHANH</button></div></div>`}
          function renderExternal(){const q=(document.getElementById('extSearch')?.value||'').toLocaleLowerCase('vi');const local=(STATE.external_installed||[]).filter(p=>!q||String(p.name).toLocaleLowerCase('vi').includes(q)||String(p.creator).toLocaleLowerCase('vi').includes(q));const remote=(STATE.external_remote||[]).filter(p=>!q||String(p.name).toLocaleLowerCase('vi').includes(q)||String(p.creator).toLocaleLowerCase('vi').includes(q));document.getElementById('externalInstalled').innerHTML=local.length?local.map(externalLocalCard).join(''):'<div class="muted">Không có plugin ngoài phù hợp.</div>';document.getElementById('externalRemote').innerHTML=remote.length?remote.map(externalRemoteCard).join(''):'<div class="muted">Kho GitHub chưa có plugin ngoài.</div>';document.getElementById('tokenState').innerHTML=STATE.github_token_set?'<span class="ok">● Token đang dùng trong RAM</span>':'<span class="warn">● Chưa có token để ghi GitHub</span>';}
          function setToken(){const el=document.getElementById('token');if(!el.value.trim()){toast('Nhập token trước.','warn');return;}sketchup.setGithubToken(el.value);el.value='';}
          function getSource(name){return prompt(`Link nguồn gốc của ${name} (tùy chọn):`,'')||'';}
          function saveMeta(key,name){const source=getSource(name);sketchup.saveExternalMetadata(JSON.stringify({key:key,source_url:source}));}
          function backupExternal(key,name){if(!confirm(`Chỉ tiếp tục nếu bạn có quyền sao lưu/phân phối file của ${name} lên repo GitHub công khai.\n\nNếu đây là plugin trả phí, độc quyền hoặc bạn không chắc về giấy phép, hãy bấm Cancel và chỉ dùng LƯU THÔNG TIN.`))return;const source=getSource(name);sketchup.backupExternal(JSON.stringify({key:key,source_url:source,confirm_rights:true}));}
          function renderState(state){STATE=state||{};renderVada();renderExternal();}
          function toast(msg,type='ok'){const t=document.getElementById('toast');t.className=type;t.textContent=msg;t.style.display='block';clearTimeout(window.__tt);window.__tt=setTimeout(()=>t.style.display='none',5000)}
          document.addEventListener('DOMContentLoaded',()=>{if(window.sketchup&&sketchup.ready)sketchup.ready()});
          </script></body></html>
        HTML
      end

      def install_ui
        @command ||= UI::Command.new('VADA Plugin Manager') { show }
        icon = File.join(__dir__, 'icon.png')
        if File.file?(icon)
          @command.small_icon = icon
          @command.large_icon = icon
        end
        @command.tooltip = 'VADA Plugin Manager - Cài, cập nhật và đồng bộ kho plugin'
        @toolbar ||= UI::Toolbar.new('VADA Plugin Manager')
        @toolbar.add_item(@command) if @toolbar.size == 0
        @toolbar.restore
        UI.start_timer(0.25, false) { @toolbar.show unless @toolbar.visible? rescue @toolbar.show }
        unless @menu_installed
          UI.menu('Extensions').add_item(@command)
          @menu_installed = true
        end
      end
    end

    unless file_loaded?(__FILE__)
      install_ui
      file_loaded(__FILE__)
    end
  end
end
