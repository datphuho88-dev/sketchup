# frozen_string_literal: true
require 'sketchup.rb'
require 'json'
require 'net/http'
require 'uri'
require 'tmpdir'
require 'fileutils'
require 'digest'
require 'base64'
require 'open3'

module VADA
  module PluginManager
    VERSION = '1.5.0' unless const_defined?(:VERSION)
    OWNER = 'datphuho88-dev'
    REPO = 'sketchup'
    BRANCH = 'main'
    MANIFEST_URL = "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/vada_plugin_manifest.json"
    TREE_URL = "https://api.github.com/repos/#{OWNER}/#{REPO}/git/trees/#{BRANCH}?recursive=1"
    EXTERNAL_MANIFEST_PATH = '90 - Kho plugin ngoài/external_plugins_manifest.json'
    EXTERNAL_MANIFEST_URL = "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/90%20-%20Kho%20plugin%20ngo%C3%A0i/external_plugins_manifest.json"
    PLUGINS_DIR = Sketchup.find_support_file('Plugins')
    CACHE_TTL = 30.0
    ICON_LIMIT = 900_000
    BACKUP_LIMIT = 25 * 1024 * 1024

    class << self
      def show
        @dialog = build_dialog if @dialog.nil?
        @dialog.show
      rescue StandardError => e
        UI.messagebox("VADA Plugin Manager không mở được:\n#{e.message}")
        @dialog = nil
      end

      def build_dialog
        dlg = UI::HtmlDialog.new(
          dialog_title: "VADA Plugin Manager v#{VERSION}",
          preferences_key: 'vada_plugin_manager_v15',
          scrollable: true,
          resizable: true,
          width: 930,
          height: 690,
          style: UI::HtmlDialog::STYLE_DIALOG
        )
        dlg.set_html(html)
        dlg.add_action_callback('ready') { |_c| dialog_ready }
        dlg.add_action_callback('refresh') { |_c| refresh_local(force: true) }
        dlg.add_action_callback('checkUpdates') { |_c| check_updates(false) }
        dlg.add_action_callback('reloadPlugin') { |_c, id| reload_plugin(id.to_s) }
        dlg.add_action_callback('updatePlugin') { |_c, id| update_plugin(id.to_s) }
        dlg.add_action_callback('reloadAll') { |_c| reload_all }
        dlg.add_action_callback('updateAll') { |_c| update_all }
        dlg.add_action_callback('removePlugin') { |_c, id| remove_vada_plugin(id.to_s) }
        dlg.add_action_callback('loadExternal') { |_c| load_external(false) }
        dlg.add_action_callback('refreshExternal') { |_c| load_external(true) }
        dlg.add_action_callback('setToken') { |_c, token| @github_token = token.to_s.strip }
        dlg.add_action_callback('backupExternal') { |_c, key, url| backup_external(key.to_s, url.to_s) }
        dlg.add_action_callback('installExternal') { |_c, key| install_external(key.to_s) }
        dlg.add_action_callback('removeExternal') { |_c, key| remove_external(key.to_s) }
        dlg.set_on_closed do
          @dialog_ready = false
          @dialog = nil
          @github_token = nil
        end
        dlg
      end

      def dialog_ready
        @dialog_ready = true
        refresh_local(force: false)
        UI.start_timer(0.1, false) { check_updates(true) }
      end

      def normalize_text(value)
        value.to_s.downcase.unicode_normalize(:nfkd)
             .encode('ASCII', replace: '', undef: :replace, invalid: :replace)
             .gsub(/[^a-z0-9]+/, ' ').strip
      rescue StandardError
        value.to_s.downcase
      end

      def compare_versions(a, b)
        aa = a.to_s.scan(/\d+/).map(&:to_i)
        bb = b.to_s.scan(/\d+/).map(&:to_i)
        len = [aa.length, bb.length, 3].max
        (aa + [0] * (len - aa.length)) <=> (bb + [0] * (len - bb.length))
      end

      def highest_version(values)
        values.compact.reject(&:empty?).max { |a, b| compare_versions(a, b) }
      end

      def safe_call(object, method)
        object.respond_to?(method) ? object.public_send(method) : nil
      rescue StandardError
        nil
      end

      def extension_snapshot
        Sketchup.extensions.map do |ext|
          path = [:extension_path, :path].filter_map { |m| safe_call(ext, m) }.map(&:to_s).find { |v| !v.empty? }
          {
            object: ext,
            name: safe_call(ext, :name).to_s,
            version: safe_call(ext, :version).to_s,
            creator: safe_call(ext, :creator).to_s,
            description: safe_call(ext, :description).to_s,
            path: path.to_s
          }
        end
      rescue StandardError
        []
      end

      def fallback_manifest
        {
          'plugins' => [
            {'id'=>'ghi_kich_thuoc_tu_dong','name'=>'Ghi kích thước tự động','repo_path'=>'01 - Ghi kích thước tự động','loader_candidates'=>['vada_auto_dim.rb','vada_ghi_kich_thuoc_tu_dong.rb'],'extension_names'=>['VADA Auto Dim','Ghi kích thước tự động'],'hot_reload'=>false},
            {'id'=>'don_plugin_rac','name'=>'Dọn plugin rác','repo_path'=>'02 - Dọn plugin rác','loader_candidates'=>['vada_extension_cleaner.rb','vada_don_plugin_rac.rb'],'hot_reload'=>false},
            {'id'=>'tim_cong_cu_nhanh','name'=>'Tìm công cụ nhanh','repo_path'=>'03 - Tìm công cụ nhanh','loader_candidates'=>['quick_tool_finder.rb','vada_quick_tool_finder.rb'],'hot_reload'=>false},
            {'id'=>'mat_cat_goc_nhin','name'=>'Tạo mặt cắt và góc nhìn','repo_path'=>'04 - Tạo mặt cắt và góc nhìn','loader_candidates'=>['vada_mat_cat_view.rb'],'reload_candidates'=>['vada_mat_cat_view/main.rb'],'reload_loader'=>false,'extension_names'=>['VADA - Tạo mặt cắt View','Tạo mặt cắt và góc nhìn'],'hot_reload'=>true},
            {'id'=>'tong_do_dai_canh','name'=>'Tính tổng độ dài cạnh','repo_path'=>'05 - Tính tổng độ dài cạnh','loader_candidates'=>['vada_tong_do_dai_canh.rb'],'hot_reload'=>true},
            {'id'=>'thong_ke_sat_hop','name'=>'Thống kê sắt hộp','repo_path'=>'06 - Thống kê sắt hộp','loader_candidates'=>['vada_thong_ke_sat_hop.rb'],'hot_reload'=>true},
            {'id'=>'tong_dien_tich','name'=>'Tính tổng diện tích','repo_path'=>'07 - Tính tổng diện tích','loader_candidates'=>['vada_tong_dien_tich.rb'],'hot_reload'=>true},
            {'id'=>'plugin_manager','name'=>'VADA Plugin Manager','repo_path'=>'08 - VADA Plugin Manager','loader_candidates'=>['vada_plugin_manager.rb'],'extension_names'=>['VADA Plugin Manager'],'hot_reload'=>false},
            {'id'=>'tao_phong_nhanh','name'=>'Tạo phòng nhanh','repo_path'=>'09 - Tạo phòng nhanh','loader_candidates'=>['vada_quick_room.rb'],'reload_candidates'=>['vada_quick_room/main.rb'],'reload_loader'=>false,'hot_reload'=>true},
            {'id'=>'workspace_manager','name'=>'VADA Workspace Manager','repo_path'=>'10 - VADA Workspace Manager','loader_candidates'=>['vada_workspace_manager.rb'],'hot_reload'=>false},
            {'id'=>'style_dim_ghi_chu','name'=>'Quản lý Style Dim & Ghi chú','repo_path'=>'11 - Quản lý Style Dim & Ghi chú','loader_candidates'=>['vada_style_dim_notes.rb'],'hot_reload'=>false},
            {'id'=>'chon_toan_bo_dim','name'=>'Chọn toàn bộ DIM','repo_path'=>'12 - Chọn toàn bộ DIM','loader_candidates'=>['vada_select_all_dim.rb'],'hot_reload'=>false}
          ]
        }
      end

      def resolve_loader(plugin)
        Array(plugin['loader_candidates']).each do |rel|
          path = File.join(PLUGINS_DIR, rel.to_s)
          return path if File.file?(path)
        end
        nil
      end

      def resolve_reload_target(plugin)
        Array(plugin['reload_candidates']).each do |rel|
          path = File.join(PLUGINS_DIR, rel.to_s)
          return path if File.file?(path)
        end
        loader = resolve_loader(plugin)
        plugin.fetch('reload_loader', true) ? loader : nil
      end

      def detect_version_from_file(path)
        return '' unless path && File.file?(path)
        text = File.read(path, 48_000, encoding: 'UTF-8', invalid: :replace, undef: :replace, replace: '')
        [
          /(?:PLUGIN_VERSION|EXTENSION_VERSION|VERSION)\s*=\s*['"]v?([^'"]+)['"]/i,
          /\.version\s*=\s*['"]v?([^'"]+)['"]/i,
          /version\s*[:=]\s*['"]?v?(\d+\.\d+(?:\.\d+)?)/i
        ].each do |pattern|
          m = text.match(pattern)
          return m[1] if m
        end
        ''
      rescue StandardError
        ''
      end

      def match_extension(plugin, extensions)
        exact = Array(plugin['extension_names']).map { |n| normalize_text(n) }.reject(&:empty?)
        hit = extensions.find { |ext| exact.include?(normalize_text(ext[:name])) }
        return hit if hit
        tokens = (Array(plugin['detect_tokens']) + [plugin['name']]).map { |n| normalize_text(n) }.reject(&:empty?).uniq
        hits = extensions.select do |ext|
          name = normalize_text(ext[:name])
          tokens.any? { |t| name == t || name.include?(t) || t.include?(name) }
        end
        hits.max { |a, b| compare_versions(a[:version], b[:version]) }
      end

      def local_version_candidates(plugin, ext, loader)
        vals = []
        vals << ext[:version].to_s if ext
        [loader, (ext && ext[:path]), resolve_reload_target(plugin)].compact.uniq.each do |path|
          v = detect_version_from_file(path)
          vals << v unless v.empty?
        end
        vals.select { |v| v.match?(/\d+\.\d+(?:\.\d+)?/) }.uniq
      end

      def detect_local!(plugin, extensions)
        ext = match_extension(plugin, extensions)
        loader = resolve_loader(plugin)
        if ext || loader
          plugin['installed'] = true
          plugin['loader'] = loader || ext[:path]
          plugin['extension_name'] = ext && ext[:name]
          plugin['local_version'] = highest_version(local_version_candidates(plugin, ext, loader)) || 'đã cài'
        else
          plugin['installed'] = false
          plugin['loader'] = nil
          plugin['local_version'] = '-'
        end
      end

      def update_available?(plugin)
        return false unless plugin['installed']
        remote = plugin['latest_version'].to_s
        local = plugin['local_version'].to_s
        return false if remote.empty?
        return true if local.empty? || local == 'đã cài'
        compare_versions(remote, local) > 0
      end

      def build_local_catalog
        manifest = deep_copy(@manifest || fallback_manifest)
        exts = extension_snapshot
        list = manifest.fetch('plugins', []).map do |src|
          p = src.dup
          detect_local!(p, exts)
          p['update_available'] = update_available?(p)
          p['reload_target'] = resolve_reload_target(p)
          p['reloadable'] = p['installed'] && p.fetch('hot_reload', false) && !p['reload_target'].to_s.empty?
          p
        end
        list.sort_by do |p|
          rank = if !p['installed'] && !p['rbz_url'].to_s.empty? then 0
                 elsif p['installed'] && p['update_available'] then 1
                 elsif p['installed'] then 2
                 else 3 end
          [rank, p['name'].to_s.downcase]
        end
      end

      def plugin_catalog(force: false)
        now = Process.clock_gettime(Process::CLOCK_MONOTONIC)
        if force || @local_catalog.nil? || @local_catalog_at.nil? || (now - @local_catalog_at) > CACHE_TTL
          @local_catalog = build_local_catalog
          @local_catalog_at = now
        end
        @local_catalog
      end

      def refresh_local(force: false)
        list = plugin_catalog(force: force)
        render_main(list)
      rescue StandardError => e
        toast("Làm mới lỗi: #{e.message}", 'err')
      end

      def render_main(list = plugin_catalog)
        return unless @dialog && @dialog_ready
        payload = {
          plugins: list,
          checking: !!@checking_updates,
          last_check: @last_check ? @last_check.strftime('%H:%M:%S') : nil,
          new_count: list.count { |p| !p['installed'] && !p['rbz_url'].to_s.empty? },
          update_count: list.count { |p| p['installed'] && p['update_available'] }
        }
        @dialog.execute_script("renderState(#{JSON.generate(payload)})")
      rescue StandardError
        @dialog_ready = false
      end

      def http_get(url, timeout = 10, headers = {})
        uri = URI(url)
        req = Net::HTTP::Get.new(uri)
        req['User-Agent'] = "VADA-Plugin-Manager/#{VERSION}"
        req['Accept'] = 'application/vnd.github+json' if uri.host == 'api.github.com'
        headers.each { |k, v| req[k] = v }
        res = Net::HTTP.start(uri.host, uri.port, use_ssl: uri.scheme == 'https', open_timeout: 4, read_timeout: timeout) { |h| h.request(req) }
        return http_get(res['location'], timeout, headers) if res.is_a?(Net::HTTPRedirection)
        raise "HTTP #{res.code}" unless res.is_a?(Net::HTTPSuccess)
        res.body
      end

      def http_json(url, timeout = 10)
        JSON.parse(http_get(url, timeout))
      end

      def raw_url(path)
        return '' if path.to_s.empty?
        encoded = path.split('/').map { |seg| URI::DEFAULT_PARSER.escape(seg) }.join('/')
        "https://raw.githubusercontent.com/#{OWNER}/#{REPO}/#{BRANCH}/#{encoded}"
      end

      def direct_versions(base, dirs)
        dirs.filter_map do |path|
          next unless path.start_with?(base + '/')
          rest = path[(base.length + 1)..]
          next if rest.include?('/')
          m = rest.match(/^v?(\d+\.\d+\.\d+)$/i)
          m && [m[1], path]
        end
      end

      def enrich_plugin!(plugin, files, dirs)
        base = plugin['repo_path'].to_s
        return if base.empty?
        versions = direct_versions(base, dirs)
        if versions.any?
          latest = versions.max { |a, b| compare_versions(a[0], b[0]) }
          plugin['latest_version'] = latest[0]
          rbz = files.find { |path| path.start_with?(latest[1] + '/') && path.downcase.end_with?('.rbz') }
          plugin['rbz_url'] = raw_url(rbz) if rbz
          return
        end
        candidates = files.filter_map do |path|
          next unless path.start_with?(base + '/releases/') && path.downcase.end_with?('.rbz')
          m = File.basename(path).match(/v?(\d+\.\d+\.\d+)/i)
          m && [m[1], path]
        end
        return if candidates.empty?
        latest = candidates.max { |a, b| compare_versions(a[0], b[0]) }
        plugin['latest_version'] = latest[0]
        plugin['rbz_url'] = raw_url(latest[1])
      end

      def discover_unlisted!(manifest, files, dirs)
        known = manifest.fetch('plugins', []).map { |p| p['repo_path'].to_s }
        dirs.select { |p| !p.include?('/') && p.match?(/^\d+\s*-\s*.+/) && !p.start_with?('90 - ') }.each do |base|
          next if known.include?(base)
          versions = direct_versions(base, dirs)
          next if versions.empty?
          latest = versions.max { |a, b| compare_versions(a[0], b[0]) }
          rbz = files.find { |p| p.start_with?(latest[1] + '/') && p.downcase.end_with?('.rbz') }
          next unless rbz
          name = base.sub(/^\d+\s*-\s*/, '')
          manifest['plugins'] << {
            'id'=>normalize_text(base).tr(' ','_'), 'name'=>name, 'repo_path'=>base,
            'latest_version'=>latest[0], 'rbz_url'=>raw_url(rbz), 'loader_candidates'=>[],
            'extension_names'=>[name, "VADA #{name}"], 'detect_tokens'=>[name], 'hot_reload'=>false
          }
        end
      end

      def check_updates(auto = false)
        return if @checking_updates
        @checking_updates = true
        @update_async = nil
        render_main

        Thread.new do
          result = nil
          error = nil
          begin
            manifest = http_json(MANIFEST_URL, 8)
            begin
              tree = http_json(TREE_URL, 14).fetch('tree', [])
              files = tree.select { |e| e['type'] == 'blob' }.map { |e| e['path'].to_s }
              dirs = tree.select { |e| e['type'] == 'tree' }.map { |e| e['path'].to_s }
              manifest.fetch('plugins', []).each { |p| enrich_plugin!(p, files, dirs) }
              discover_unlisted!(manifest, files, dirs)
            rescue StandardError
              # Manifest vẫn là nguồn dự phòng nếu GitHub Tree API bị rate-limit/chậm.
            end
            result = manifest
          rescue StandardError => e
            error = e.message
          ensure
            @update_async = [result, error]
          end
        end

        timer_id = nil
        timer_id = UI.start_timer(0.12, true) do
          next if @update_async.nil?
          UI.stop_timer(timer_id) if timer_id
          result, error = @update_async
          @update_async = nil
          @checking_updates = false
          if result
            @manifest = result
            @last_check = Time.now
            @local_catalog = nil
            refresh_local(force: true)
            toast('Đã kiểm tra GitHub.', 'ok') unless auto
          else
            render_main
            toast("Không kiểm tra được GitHub: #{error}", 'err') unless auto
          end
        end
      rescue StandardError => e
        @checking_updates = false
        toast("Lỗi kiểm tra cập nhật: #{e.message}", 'err')
      end

      def safe_reload(plugin)
        target = resolve_reload_target(plugin)
        return [:restart, nil] unless target
        load target
        [:ok, target]
      rescue Exception => e
        [:error, e.message]
      end

      def reload_plugin(id)
        p = plugin_catalog.find { |x| x['id'] == id }
        return toast('Không tìm thấy plugin', 'err') unless p
        return toast('Plugin này cần khởi động lại SketchUp.', 'warn') unless p['reloadable']
        status, detail = safe_reload(p)
        status == :ok ? toast("Đã reload: #{p['name']}", 'ok') : toast("Reload lỗi: #{detail}", 'err')
        refresh_local(force: true)
      end

      def reload_all
        ok = 0
        fail = 0
        plugin_catalog.each do |p|
          next unless p['reloadable']
          safe_reload(p).first == :ok ? ok += 1 : fail += 1
        end
        toast("Reload xong: #{ok} thành công, #{fail} lỗi", fail.zero? ? 'ok' : 'warn')
        refresh_local(force: true)
      end

      def download(url, filename)
        path = File.join(Dir.tmpdir, filename)
        File.binwrite(path, http_get(url, 40))
        path
      end

      def update_plugin(id)
        p = plugin_catalog.find { |x| x['id'] == id }
        return toast('Không tìm thấy plugin', 'err') unless p
        return toast('Plugin đang là bản mới nhất', 'ok') if p['installed'] && !p['update_available']
        return toast('Không tìm thấy RBZ trên GitHub', 'warn') if p['rbz_url'].to_s.empty?
        install_rbz_for(p)
      end

      def install_rbz_for(p)
        path = nil
        begin
          path = download(p['rbz_url'], "vada_#{p['id']}_#{p['latest_version']}.rbz")
          raise 'SketchUp không hỗ trợ cài RBZ tự động.' unless Sketchup.respond_to?(:install_from_archive)
          raise 'Cài RBZ thất bại.' unless Sketchup.install_from_archive(path)
          @local_catalog = nil
          if p.fetch('hot_reload', false) && safe_reload(p).first == :ok
            toast("Đã #{p['installed'] ? 'cập nhật' : 'cài mới'} và reload: #{p['name']}", 'ok')
          else
            toast("Đã #{p['installed'] ? 'cập nhật' : 'cài mới'} #{p['name']}. Nên mở lại SketchUp.", 'warn')
          end
        rescue StandardError => e
          toast("Cài đặt lỗi: #{e.message}", 'err')
        ensure
          File.delete(path) if path && File.file?(path)
          refresh_local(force: true)
        end
      end

      def update_all
        list = plugin_catalog.select { |p| (!p['installed'] || p['update_available']) && !p['rbz_url'].to_s.empty? }
        return toast('Không có plugin cần cài/cập nhật', 'ok') if list.empty?
        ok = 0
        fail = 0
        list.each do |p|
          path = nil
          begin
            path = download(p['rbz_url'], "vada_#{p['id']}_#{p['latest_version']}.rbz")
            raise 'Không hỗ trợ install_from_archive' unless Sketchup.respond_to?(:install_from_archive)
            raise 'Cài đặt thất bại' unless Sketchup.install_from_archive(path)
            safe_reload(p) if p.fetch('hot_reload', false)
            ok += 1
          rescue StandardError
            fail += 1
          ensure
            File.delete(path) if path && File.file?(path)
          end
        end
        @local_catalog = nil
        toast("Cài/cập nhật xong: #{ok} thành công, #{fail} lỗi", fail.zero? ? 'ok' : 'warn')
        refresh_local(force: true)
      end

      def remove_vada_plugin(id)
        p = plugin_catalog.find { |x| x['id'] == id }
        return toast('Không tìm thấy plugin.', 'err') unless p
        return toast('Không thể tự gỡ VADA Plugin Manager khi đang chạy.', 'warn') if id == 'plugin_manager'
        loader = p['loader'].to_s
        return toast('Không xác định được file plugin để gỡ.', 'warn') if loader.empty? || !inside_plugins_dir?(loader)
        begin
          disable_extension_by_name(p['extension_name'])
          support = File.join(File.dirname(loader), File.basename(loader, '.rb'))
          FileUtils.rm_f(loader)
          FileUtils.rm_rf(support) if Dir.exist?(support)
          @local_catalog = nil
          toast("Đã gỡ #{p['name']}. Khởi động lại SketchUp để dọn hoàn toàn.", 'warn')
          refresh_local(force: true)
        rescue StandardError => e
          toast("Gỡ plugin lỗi: #{e.message}", 'err')
        end
      end

      # ---------- KHO PLUGIN NGOÀI ----------

      def vada_extension_names
        plugin_catalog.map { |p| normalize_text(p['extension_name'] || p['name']) }.reject(&:empty?)
      end

      def external_key(name, path = '')
        base = normalize_text(name).tr(' ', '_')
        suffix = Digest::SHA1.hexdigest(path.to_s)[0, 7]
        "#{base}_#{suffix}"
      end

      def external_extensions
        vada_names = vada_extension_names
        extension_snapshot.filter_map do |ext|
          n = normalize_text(ext[:name])
          next if n.empty? || vada_names.any? { |v| n == v || (n.include?(v) && v.length > 5) }
          loader = ext[:path].to_s
          loader = nil unless !loader.empty? && File.file?(loader) && inside_plugins_dir?(loader)
          support = loader && File.join(File.dirname(loader), File.basename(loader, '.rb'))
          {
            'key'=>external_key(ext[:name], loader),
            'name'=>ext[:name].empty? ? File.basename(loader.to_s, '.rb') : ext[:name],
            'version'=>ext[:version].empty? ? (detect_version_from_file(loader) rescue '') : ext[:version],
            'creator'=>ext[:creator],
            'description'=>ext[:description],
            'loader'=>loader,
            'support_dir'=>(support && Dir.exist?(support) ? support : nil),
            'packageable'=>!!loader,
            'icon'=>find_icon_data(loader, support)
          }
        end
      end

      def find_icon_data(loader, support)
        candidates = []
        if support && Dir.exist?(support)
          patterns = ['icon*.png','*icon*.png','toolbar*.png','*.svg','*.jpg','*.jpeg']
          patterns.each do |pat|
            candidates.concat(Dir.glob(File.join(support, pat), File::FNM_CASEFOLD))
            candidates.concat(Dir.glob(File.join(support, '*', pat), File::FNM_CASEFOLD))
          end
        end
        candidates << loader.sub(/\.rb$/i, '.png') if loader
        file = candidates.uniq.find { |f| File.file?(f) && File.size(f) <= ICON_LIMIT }
        return '' unless file
        ext = File.extname(file).downcase
        mime = {'.png'=>'image/png','.svg'=>'image/svg+xml','.jpg'=>'image/jpeg','.jpeg'=>'image/jpeg'}[ext]
        return '' unless mime
        "data:#{mime};base64,#{Base64.strict_encode64(File.binread(file))}"
      rescue StandardError
        ''
      end

      def load_external(force = false)
        @external_local = nil if force
        local = @external_local ||= external_extensions
        render_external(local, @external_remote || {})
        return if @external_checking
        @external_checking = true
        @external_async = nil

        Thread.new do
          remote = {}
          begin
            data = http_json(EXTERNAL_MANIFEST_URL, 8)
            Array(data['plugins']).each { |p| remote[p['key'].to_s] = p }
          rescue StandardError
            remote = {}
          ensure
            @external_async = remote
          end
        end

        timer_id = nil
        timer_id = UI.start_timer(0.12, true) do
          next if @external_async.nil?
          UI.stop_timer(timer_id) if timer_id
          remote = @external_async
          @external_async = nil
          @external_checking = false
          @external_remote = remote
          render_external(@external_local || [], remote)
        end
      rescue StandardError => e
        @external_checking = false
        toast("Quét plugin ngoài lỗi: #{e.message}", 'err')
      end

      def render_external(local, remote)
        return unless @dialog && @dialog_ready
        local = local.map do |p|
          r = remote[p['key'].to_s]
          p.merge(
            'saved'=>!!r,
            'saved_version'=>(r && r['version']).to_s,
            'rbz_url'=>(r && r['rbz_url']).to_s,
            'source_url'=>(r && r['source_url']).to_s,
            'sha256'=>(r && r['sha256']).to_s
          )
        end
        local_keys = local.map { |p| p['key'] }
        remote_only = remote.values.reject { |r| local_keys.include?(r['key']) }.map do |r|
          {
            'key'=>r['key'], 'name'=>r['name'], 'version'=>'-', 'creator'=>r['creator'].to_s,
            'description'=>r['description'].to_s, 'loader'=>nil, 'support_dir'=>nil,
            'packageable'=>false, 'icon'=>r['icon'].to_s, 'saved'=>true,
            'saved_version'=>r['version'].to_s, 'rbz_url'=>r['rbz_url'].to_s,
            'source_url'=>r['source_url'].to_s, 'sha256'=>r['sha256'].to_s
          }
        end
        payload = { plugins: local + remote_only, remote_ready: !@external_checking }
        @dialog.execute_script("renderExternal(#{JSON.generate(payload)})")
      rescue StandardError => e
        toast("Hiển thị kho ngoài lỗi: #{e.message}", 'err')
      end

      def backup_external(key, source_url = '')
        p = (@external_local || external_extensions).find { |x| x['key'] == key }
        return toast('Không tìm thấy plugin ngoài.', 'err') unless p
        return toast('Plugin này không xác định được loader nên chỉ có thể lưu link nguồn.', 'warn') unless p['packageable']
        return toast('Nhập GitHub token trước khi sao lưu.', 'warn') if @github_token.to_s.empty?
        if encrypted_plugin?(p)
          return save_external_metadata(p, source_url, nil, nil, 'Plugin chứa .rbe/.rbs; chỉ lưu metadata/link nguồn.')
        end
        rbz = nil
        begin
          rbz = package_external(p)
          size = File.size(rbz)
          raise "RBZ #{(size / 1024.0 / 1024.0).round(1)} MB vượt giới hạn 25 MB." if size > BACKUP_LIMIT
          sha = Digest::SHA256.file(rbz).hexdigest
          slug = safe_slug(p['name'])
          ver = safe_version(p['version'])
          repo_path = "90 - Kho plugin ngoài/#{slug}/v#{ver}/#{slug}_v#{ver}.rbz"
          github_put_binary(repo_path, File.binread(rbz), "Backup #{p['name']} v#{ver}")
          url = raw_url(repo_path)
          save_external_metadata(p, source_url, url, sha, "Đã sao lưu #{p['name']} v#{ver}.")
        rescue StandardError => e
          toast("Sao lưu lỗi: #{e.message}", 'err')
        ensure
          File.delete(rbz) if rbz && File.file?(rbz)
        end
      end

      def save_external_metadata(p, source_url, rbz_url, sha, message)
        remote = (@external_remote || {}).dup
        ver = safe_version(p['version'])
        item = {
          'key'=>p['key'], 'name'=>p['name'], 'version'=>ver, 'creator'=>p['creator'].to_s,
          'description'=>p['description'].to_s, 'source_url'=>source_url.to_s,
          'rbz_url'=>rbz_url.to_s, 'sha256'=>sha.to_s, 'updated_at'=>Time.now.utc.strftime('%Y-%m-%dT%H:%M:%SZ')
        }
        remote[p['key']] = item
        doc = {'schema'=>1, 'plugins'=>remote.values.sort_by { |x| x['name'].to_s.downcase }}
        github_put_text(EXTERNAL_MANIFEST_PATH, JSON.pretty_generate(doc), "Update external plugin manifest")
        @external_remote = remote
        render_external(@external_local || [], remote)
        toast(message, rbz_url ? 'ok' : 'warn')
      rescue StandardError => e
        toast("Lưu thông tin lỗi: #{e.message}", 'err')
      end

      def install_external(key)
        remote = @external_remote || {}
        p = remote[key]
        return toast('Plugin này chưa có bản sao RBZ trên GitHub.', 'warn') unless p && !p['rbz_url'].to_s.empty?
        path = nil
        begin
          path = download(p['rbz_url'], "vada_external_#{safe_slug(p['name'])}.rbz")
          expected = p['sha256'].to_s
          actual = Digest::SHA256.file(path).hexdigest
          raise 'SHA-256 không khớp. Dừng cài để tránh file hỏng.' if !expected.empty? && expected != actual
          raise 'SketchUp không hỗ trợ cài archive.' unless Sketchup.respond_to?(:install_from_archive)
          raise 'Cài plugin thất bại.' unless Sketchup.install_from_archive(path)
          @external_local = nil
          toast("Đã cài #{p['name']}. Nên mở lại SketchUp.", 'ok')
          load_external(true)
        rescue StandardError => e
          toast("Cài plugin ngoài lỗi: #{e.message}", 'err')
        ensure
          File.delete(path) if path && File.file?(path)
        end
      end

      def remove_external(key)
        p = (@external_local || external_extensions).find { |x| x['key'] == key }
        return toast('Plugin chưa cài trên máy này.', 'warn') unless p
        loader = p['loader'].to_s
        return toast('Không xác định được loader để gỡ an toàn.', 'warn') if loader.empty? || !inside_plugins_dir?(loader)
        begin
          disable_extension_by_name(p['name'])
          FileUtils.rm_f(loader)
          FileUtils.rm_rf(p['support_dir']) if p['support_dir'] && Dir.exist?(p['support_dir'])
          @external_local = nil
          toast("Đã gỡ #{p['name']}. Khởi động lại SketchUp.", 'warn')
          load_external(true)
        rescue StandardError => e
          toast("Gỡ plugin ngoài lỗi: #{e.message}", 'err')
        end
      end

      def disable_extension_by_name(name)
        n = normalize_text(name)
        ext = Sketchup.extensions.find { |e| normalize_text(safe_call(e, :name)) == n }
        ext.uncheck if ext && ext.respond_to?(:uncheck)
      rescue StandardError
        nil
      end

      def encrypted_plugin?(p)
        paths = []
        paths << p['loader'] if p['loader']
        if p['support_dir'] && Dir.exist?(p['support_dir'])
          paths.concat(Dir.glob(File.join(p['support_dir'], '**', '*.{rbe,rbs}'), File::FNM_CASEFOLD))
        end
        paths.any? { |f| f.to_s.downcase.end_with?('.rbe', '.rbs') }
      end

      def package_external(p)
        raise 'Chỉ hỗ trợ đóng gói trên Windows/SketchUp 2023.' unless Sketchup.platform == :platform_win
        stage = Dir.mktmpdir('vada_external_')
        FileUtils.cp(p['loader'], stage)
        if p['support_dir'] && Dir.exist?(p['support_dir'])
          FileUtils.cp_r(p['support_dir'], stage)
        end
        out = File.join(Dir.tmpdir, "#{safe_slug(p['name'])}_v#{safe_version(p['version'])}_#{Process.pid}.rbz")
        zip_out = out.sub(/\.rbz\z/i, '.zip')
        File.delete(out) if File.exist?(out)
        File.delete(zip_out) if File.exist?(zip_out)
        ps_stage = stage.gsub("'", "''")
        ps_zip = zip_out.gsub("'", "''")
        cmd = "Compress-Archive -Path '#{ps_stage}\\*' -DestinationPath '#{ps_zip}' -CompressionLevel Optimal -Force"
        stdout, stderr, status = Open3.capture3('powershell.exe', '-NoProfile', '-NonInteractive', '-Command', cmd)
        raise "Không đóng gói được RBZ: #{stderr.empty? ? stdout : stderr}" unless status.success? && File.file?(zip_out)
        FileUtils.mv(zip_out, out)
        out
      ensure
        FileUtils.rm_rf(stage) if stage && Dir.exist?(stage)
      end

      def github_put_text(path, text, message)
        github_put_binary(path, text.encode('UTF-8'), message)
      end

      def github_put_binary(path, bytes, message)
        raise 'Thiếu GitHub token.' if @github_token.to_s.empty?
        uri_path = path.split('/').map { |s| URI::DEFAULT_PARSER.escape(s) }.join('/')
        api = "https://api.github.com/repos/#{OWNER}/#{REPO}/contents/#{uri_path}"
        sha = nil
        begin
          current = github_request(:get, api)
          sha = JSON.parse(current)['sha']
        rescue StandardError
          sha = nil
        end
        body = { message: message, content: Base64.strict_encode64(bytes), branch: BRANCH }
        body[:sha] = sha if sha
        github_request(:put, api, JSON.generate(body))
      end

      def github_request(method, url, body = nil)
        uri = URI(url)
        req = method == :put ? Net::HTTP::Put.new(uri) : Net::HTTP::Get.new(uri)
        req['User-Agent'] = "VADA-Plugin-Manager/#{VERSION}"
        req['Accept'] = 'application/vnd.github+json'
        req['Authorization'] = "Bearer #{@github_token}" unless @github_token.to_s.empty?
        req['X-GitHub-Api-Version'] = '2022-11-28'
        req['Content-Type'] = 'application/json' if body
        req.body = body if body
        res = Net::HTTP.start(uri.host, uri.port, use_ssl: true, open_timeout: 5, read_timeout: 40) { |h| h.request(req) }
        raise "GitHub HTTP #{res.code}: #{res.body.to_s[0, 240]}" unless res.is_a?(Net::HTTPSuccess)
        res.body
      end

      def inside_plugins_dir?(path)
        root = File.expand_path(PLUGINS_DIR).downcase
        target = File.expand_path(path.to_s).downcase
        target == root || target.start_with?(root + File::SEPARATOR)
      rescue StandardError
        false
      end

      def safe_slug(name)
        s = normalize_text(name).tr(' ', '_').gsub(/[^a-z0-9_]+/, '')
        s.empty? ? 'plugin' : s
      end

      def safe_version(version)
        m = version.to_s.match(/\d+(?:\.\d+){1,3}/)
        m ? m[0] : '0.0.0'
      end

      def deep_copy(obj)
        Marshal.load(Marshal.dump(obj))
      rescue StandardError
        JSON.parse(JSON.generate(obj))
      end

      def toast(message, type = 'ok')
        return unless @dialog && @dialog_ready
        @dialog.execute_script("toast(#{JSON.generate(message.to_s)},#{JSON.generate(type.to_s)})")
      rescue StandardError
        nil
      end

      def html
        <<~HTML
        <!doctype html>
        <html><head><meta charset="utf-8"><style>
        *{box-sizing:border-box}body{margin:0;background:#000;color:#eee;font-family:Segoe UI,Arial,sans-serif;font-size:13px}
        .top{position:sticky;top:0;background:#050505;border-bottom:1px solid #222;padding:12px 15px;z-index:5}
        .row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}h1{font-size:18px;margin:0}.ver{color:#888;margin-left:6px}
        .tabs{display:flex;gap:7px;margin-top:11px}.tab{background:#111;border:1px solid #292929}.tab.active{border-color:#a33;color:#ff6d6d}
        button{background:#171717;color:#fff;border:1px solid #333;border-radius:8px;padding:8px 10px;cursor:pointer;font-weight:600}
        button:hover{background:#222}.primary{border-color:#8d2c2c;color:#ff6868}.green{border-color:#28673e;color:#72e597}.danger{border-color:#662222;color:#ff7777}
        .body{padding:12px 15px 72px}.toolbar{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:12px}.summary{color:#999;margin-bottom:10px}
        .section-title{font-size:11px;color:#888;margin:15px 2px 7px;text-transform:uppercase;letter-spacing:.4px}
        .card{display:grid;grid-template-columns:1fr auto;gap:10px;background:#0b0b0b;border:1px solid #222;border-radius:10px;padding:11px;margin-bottom:8px}
        .has-update{border-color:#603030}.new-plugin{border-color:#26543a}.name{font-weight:700;font-size:14px}.meta{color:#999;margin-top:5px;line-height:1.45}
        .ok,.new{color:#54d17a}.warn{color:#f0b84d}.outdated{color:#ff6565}.btns{display:flex;gap:6px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
        .small{padding:6px 8px;font-size:11px}.disabled{opacity:.35;pointer-events:none}
        .controls{display:flex;gap:7px;flex-wrap:wrap;align-items:center;margin-bottom:10px}.controls input,.controls select{background:#0c0c0c;color:#eee;border:1px solid #333;border-radius:8px;padding:8px}
        .controls input{min-width:230px;flex:1}.ext-card{grid-template-columns:54px 1fr auto}.ico{width:46px;height:46px;border:1px solid #292929;border-radius:9px;background:#111;object-fit:contain;padding:4px}
        .ico-fallback{display:flex;align-items:center;justify-content:center;color:#777;font-size:20px}.hidden{display:none!important}
        #toast{position:fixed;left:15px;right:15px;bottom:13px;background:#141414;border:1px solid #333;border-radius:9px;padding:10px 12px;display:none;z-index:20}
        .note{background:#0b0b0b;border:1px solid #222;padding:10px;border-radius:9px;color:#aaa;margin-bottom:10px}.spin{display:inline-block;animation:r 1s linear infinite}@keyframes r{to{transform:rotate(360deg)}}
        </style></head><body>
        <div class="top">
          <div class="row"><h1>VADA Plugin Manager</h1><span class="ver">v#{VERSION}</span></div>
          <div class="tabs">
            <button id="tabVada" class="tab active" onclick="showTab('vada')">PLUGIN VADA</button>
            <button id="tabExt" class="tab" onclick="showTab('ext')">KHO PLUGIN NGOÀI</button>
          </div>
        </div>
        <div class="body">
          <section id="vadaPane">
            <div class="toolbar">
              <button class="primary" onclick="sketchup.checkUpdates()">↻ Kiểm tra cập nhật</button>
              <button onclick="sketchup.updateAll()">⇩ Cài/Cập nhật tất cả</button>
              <button onclick="sketchup.reloadAll()">⟳ Reload tất cả</button>
              <button onclick="sketchup.refresh()">Làm mới máy</button>
            </div>
            <div id="summary" class="summary">Đang đọc plugin trong máy...</div><div id="list"></div>
          </section>
          <section id="extPane" class="hidden">
            <div class="note">Kho này dùng để xem plugin ngoài đang cài, lọc plugin có thể đóng gói, sao lưu RBZ lên GitHub và cài lại trên PC khác. GitHub token chỉ giữ trong RAM của phiên SketchUp.</div>
            <div class="controls">
              <input id="extSearch" placeholder="Tìm plugin ngoài..." oninput="renderExternalFiltered()">
              <select id="extFilter" onchange="renderExternalFiltered()">
                <option value="all">Tất cả</option>
                <option value="packageable">Đóng gói & lưu được</option>
                <option value="saved">Đã sao lưu GitHub</option>
                <option value="unsaved">Chưa sao lưu</option>
                <option value="remote">Chỉ có trên kho / PC khác</option>
              </select>
              <input id="ghToken" type="password" placeholder="GitHub token (không lưu)" oninput="sketchup.setToken(this.value)">
              <button onclick="sketchup.refreshExternal()">Quét lại</button>
            </div>
            <div id="extSummary" class="summary">Chưa quét kho plugin ngoài.</div><div id="extList"></div>
          </section>
        </div><div id="toast"></div>
        <script>
        let extState=[];
        function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
        function showTab(which){
          const ext=which==='ext';document.getElementById('vadaPane').classList.toggle('hidden',ext);document.getElementById('extPane').classList.toggle('hidden',!ext);
          document.getElementById('tabVada').classList.toggle('active',!ext);document.getElementById('tabExt').classList.toggle('active',ext);
          if(ext && !window.__extLoaded){window.__extLoaded=true;sketchup.loadExternal()}
        }
        function card(p){
          const installed=p.installed?'<span class="ok">● Đã cài</span>':'<span class="warn">● Chưa cài</span>';let state='',cls='',btn='';
          if(!p.installed&&p.rbz_url){state='<span class="new">Plugin mới</span>';cls='new-plugin';btn=`<button class="small green" onclick="sketchup.updatePlugin('${esc(p.id)}')">Cài mới</button>`}
          else if(p.installed&&p.update_available){state='<span class="outdated">Có bản mới</span>';cls='has-update';btn=`<button class="small primary" onclick="sketchup.updatePlugin('${esc(p.id)}')">Cập nhật</button>`}
          else{state='<span class="ok">Mới nhất</span>';btn='<button class="small disabled">Cập nhật</button>'}
          const reload=`<button class="small ${p.reloadable?'':'disabled'}" onclick="sketchup.reloadPlugin('${esc(p.id)}')">Reload</button>`;
          const remove=p.installed&&p.id!=='plugin_manager'?`<button class="small danger" onclick="if(confirm('Gỡ ${esc(p.name)} khỏi máy?'))sketchup.removePlugin('${esc(p.id)}')">Gỡ</button>`:'';
          return `<div class="card ${cls}"><div><div class="name">${esc(p.name)}</div><div class="meta">Máy: <b>${esc(p.local_version)}</b> · GitHub: <b>${esc(p.latest_version||'-')}</b> · ${installed} · ${state} · ${p.rbz_url?'Có RBZ':'Chưa có RBZ'}</div></div><div class="btns">${btn}${reload}${remove}</div></div>`
        }
        function renderState(s){
          const list=s.plugins||[];document.getElementById('summary').innerHTML=s.checking?'<span class="spin">↻</span> Đang kiểm tra GitHub ở nền...':(s.last_check?`GitHub ${s.last_check} · ${s.new_count||0} plugin mới · ${s.update_count||0} bản cập nhật`:'Đã mở danh sách cục bộ · GitHub sẽ tự kiểm tra ở nền');
          const groups=[['Plugin mới chưa cài',list.filter(p=>!p.installed&&p.rbz_url)],['Có bản cập nhật',list.filter(p=>p.installed&&p.update_available)],['Đã cài / mới nhất',list.filter(p=>p.installed&&!p.update_available)],['Chưa nhận diện / chưa có RBZ',list.filter(p=>!p.installed&&!p.rbz_url)]];
          document.getElementById('list').innerHTML=groups.filter(g=>g[1].length).map(g=>`<div class="section-title">${g[0]}</div>${g[1].map(card).join('')}`).join('')
        }
        function renderExternal(s){extState=s.plugins||[];renderExternalFiltered()}
        function renderExternalFiltered(){
          const q=(document.getElementById('extSearch')?.value||'').toLowerCase();const f=document.getElementById('extFilter')?.value||'all';
          const a=extState.filter(p=>{
            const hit=(p.name+' '+p.creator+' '+p.version+' '+p.saved_version).toLowerCase().includes(q);
            const type=f==='all'||(f==='packageable'&&p.packageable)||(f==='saved'&&p.saved)||(f==='unsaved'&&!p.saved&&p.loader)||(f==='remote'&&!p.loader&&p.saved);return hit&&type
          });
          document.getElementById('extSummary').textContent=`${a.length}/${extState.length} plugin · ${extState.filter(x=>x.packageable).length} đóng gói được · ${extState.filter(x=>x.saved).length} đã sao lưu`;
          document.getElementById('extList').innerHTML=a.map(extCard).join('')||'<div class="note">Không có plugin phù hợp bộ lọc.</div>'
        }
        function extCard(p){
          const icon=p.icon?`<img class="ico" src="${p.icon}">`:'<div class="ico ico-fallback">◇</div>';
          const local=p.loader?`Máy: <b>${esc(p.version||'không rõ')}</b>`:'<span class="warn">Chưa cài trên máy</span>';
          const saved=p.saved?`<span class="ok">Đã lưu v${esc(p.saved_version||'-')}</span>`:'<span class="warn">Chưa lưu</span>';
          const packageable=p.packageable?'<span class="ok">Đóng gói được</span>':'<span class="warn">Không đóng gói tự động</span>';
          const backup=p.packageable?`<button class="small green" onclick="backup('${esc(p.key)}')">Sao lưu GitHub</button>`:'';
          const install=p.saved&&p.rbz_url?`<button class="small" onclick="sketchup.installExternal('${esc(p.key)}')">Cài nhanh</button>`:'';
          const remove=p.loader?`<button class="small danger" onclick="if(confirm('Gỡ ${esc(p.name)} khỏi máy?'))sketchup.removeExternal('${esc(p.key)}')">Gỡ</button>`:'';
          return `<div class="card ext-card"><div>${icon}</div><div><div class="name">${esc(p.name)}</div><div class="meta">${local} · ${saved} · ${packageable}${p.creator?' · '+esc(p.creator):''}</div></div><div class="btns">${backup}${install}${remove}</div></div>`
        }
        function backup(key){const url=prompt('Link nguồn/mua plugin (có thể để trống):','')||'';sketchup.backupExternal(key,url)}
        function toast(msg,type='ok'){const t=document.getElementById('toast');t.className=type;t.textContent=msg;t.style.display='block';clearTimeout(window.__tt);window.__tt=setTimeout(()=>t.style.display='none',4800)}
        document.addEventListener('DOMContentLoaded',()=>{if(window.sketchup&&sketchup.ready)sketchup.ready()});
        </script></body></html>
        HTML
      end

      def install_ui
        @command ||= UI::Command.new('VADA Plugin Manager') { show }
        icon = File.join(__dir__, 'icon.png')
        if File.file?(icon)
          @command.small_icon = icon
          @command.large_icon = icon
        end
        @command.tooltip = "VADA Plugin Manager v#{VERSION}"
        @command.status_bar_text = 'Quản lý, cập nhật, sao lưu và gỡ plugin SketchUp'
        @toolbar ||= UI::Toolbar.new('VADA Plugin Manager')
        @toolbar.add_item(@command) if @toolbar.size == 0
        @toolbar.restore
        UI.start_timer(0.25, false) { @toolbar.show unless @toolbar.visible? rescue @toolbar.show }
        unless @menu_installed
          UI.menu('Extensions').add_item(@command)
          @menu_installed = true
        end
      end
    end

    unless file_loaded?(__FILE__)
      install_ui
      file_loaded(__FILE__)
    end
  end
end
