# Lịch sử phiên bản

## v1.0.0 - 2026-09-19

- Bản đầu tiên.
- Chọn DIM native toàn model.
- Quét Group/Component lồng nhiều cấp.
- Nhận diện AutoDim mở rộng.
- Toolbar, icon và UI nền đen tiếng Việt.
