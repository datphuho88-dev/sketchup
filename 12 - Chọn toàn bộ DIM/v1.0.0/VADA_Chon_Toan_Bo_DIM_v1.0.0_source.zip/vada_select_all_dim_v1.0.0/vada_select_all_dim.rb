# frozen_string_literal: true

require 'sketchup.rb'
require 'extensions.rb'

module VADA
  module SelectAllDim
    EXTENSION_NAME = 'VADA - Chọn Toàn Bộ DIM'.freeze
    VERSION = '1.0.0'.freeze

    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new(EXTENSION_NAME, 'vada_select_all_dim/main')
      extension.description = 'Chọn toàn bộ DIM trong model, kể cả DIM nằm trong Group/Component lồng nhiều cấp và DIM do AutoDim tạo.'
      extension.version = VERSION
      extension.creator = 'VADA'
      extension.copyright = '2026 VADA'

      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
