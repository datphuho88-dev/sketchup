# frozen_string_literal: true

require 'sketchup.rb'
require 'json'

module VADA
  module SelectAllDim
    EXTENSION_NAME = 'VADA - Chọn Toàn Bộ DIM'.freeze unless const_defined?(:EXTENSION_NAME)
    VERSION = '1.0.0'.freeze unless const_defined?(:VERSION)

    PLUGIN_DIR = File.dirname(__FILE__).freeze
    HTML_PATH = File.join(PLUGIN_DIR, 'ui.html').freeze

    AUTODIM_STRONG_PATTERNS = [
      'autodim',
      'auto dim',
      'auto_dim',
      'auto-dim',
      'audim',
      'au dim',
      'au_dim',
      'au-dim',
      'vada autodim',
      'vada_auto_dim'
    ].freeze

    DIM_TAG_NAMES = [
      'dim',
      'dims',
      'dimension',
      'dimensions',
      'kich thuoc',
      'kích thước'
    ].freeze

    class << self
      def show_dialog
        if @dialog && @dialog.visible?
          @dialog.bring_to_front
          return
        end

        @dialog = UI::HtmlDialog.new(
          dialog_title: "#{EXTENSION_NAME} v#{VERSION}",
          preferences_key: 'VADA_SelectAllDim',
          scrollable: false,
          resizable: true,
          width: 430,
          height: 430,
          min_width: 390,
          min_height: 390,
          style: UI::HtmlDialog::STYLE_DIALOG
        )

        @dialog.set_file(HTML_PATH)

        @dialog.add_action_callback('select_all_dims') do |_context, include_autodim|
          stats = select_all_dimensions(include_autodim != false)
          push_result_to_dialog(stats)
        end

        @dialog.add_action_callback('select_native_dims') do |_context|
          stats = select_all_dimensions(false)
          push_result_to_dialog(stats)
        end

        @dialog.add_action_callback('close_dialog') do |_context|
          @dialog.close if @dialog
        end

        @dialog.show
      rescue StandardError => error
        UI.messagebox("#{EXTENSION_NAME} v#{VERSION}\n\nKhông mở được giao diện:\n#{error.message}")
        warn("[#{EXTENSION_NAME}] #{error.class}: #{error.message}\n#{error.backtrace.join("\n")}")
      end

      def select_all_dimensions(include_autodim = true)
        model = Sketchup.active_model
        selection = model.selection

        result = {
          entities: [],
          native: 0,
          autodim: 0,
          nested: 0,
          visited_contexts: 0
        }

        visited_definitions = {}
        collect_entities(
          model.entities,
          result,
          visited_definitions,
          include_autodim,
          0
        )

        # Bảo đảm mỗi entity chỉ xuất hiện một lần.
        entities = result[:entities].uniq.select do |entity|
          entity.respond_to?(:valid?) && entity.valid? && entity.is_a?(Sketchup::Drawingelement)
        end

        selection.clear

        # Chia theo lô để file lớn không làm UI bị nghẽn quá lâu.
        entities.each_slice(1000) do |slice|
          selection.add(slice)
        end

        Sketchup.status_text = "#{EXTENSION_NAME} v#{VERSION}: đã chọn #{entities.length} đối tượng DIM."
        model.active_view.invalidate

        {
          version: VERSION,
          total: entities.length,
          native: result[:native],
          autodim: result[:autodim],
          nested: result[:nested],
          contexts: result[:visited_contexts]
        }
      rescue StandardError => error
        UI.messagebox("#{EXTENSION_NAME} v#{VERSION}\n\nLỗi khi quét DIM:\n#{error.message}")
        warn("[#{EXTENSION_NAME}] #{error.class}: #{error.message}\n#{error.backtrace.join("\n")}")
        {
          version: VERSION,
          total: 0,
          native: 0,
          autodim: 0,
          nested: 0,
          contexts: 0,
          error: error.message
        }
      end

      private

      def collect_entities(entities, result, visited_definitions, include_autodim, depth)
        result[:visited_contexts] += 1

        entities.each do |entity|
          next unless entity.respond_to?(:valid?) && entity.valid?

          if native_dimension?(entity)
            result[:entities] << entity
            result[:native] += 1
            result[:nested] += 1 if depth.positive?
          elsif include_autodim && autodim_entity?(entity)
            result[:entities] << entity if entity.is_a?(Sketchup::Drawingelement)
            result[:autodim] += 1
            result[:nested] += 1 if depth.positive?
          end

          if entity.is_a?(Sketchup::Group)
            definition = entity.definition
            traverse_definition(definition, result, visited_definitions, include_autodim, depth + 1)
          elsif entity.is_a?(Sketchup::ComponentInstance)
            definition = entity.definition
            traverse_definition(definition, result, visited_definitions, include_autodim, depth + 1)
          end
        end
      end

      def traverse_definition(definition, result, visited_definitions, include_autodim, depth)
        return unless definition && definition.respond_to?(:entities)

        key = definition.object_id
        return if visited_definitions[key]

        visited_definitions[key] = true
        collect_entities(definition.entities, result, visited_definitions, include_autodim, depth)
      end

      def native_dimension?(entity)
        if defined?(Sketchup::Dimension) && entity.is_a?(Sketchup::Dimension)
          return true
        end

        if defined?(Sketchup::DimensionLinear) && entity.is_a?(Sketchup::DimensionLinear)
          return true
        end

        if defined?(Sketchup::DimensionRadial) && entity.is_a?(Sketchup::DimensionRadial)
          return true
        end

        false
      end

      def autodim_entity?(entity)
        signatures = []

        if entity.respond_to?(:name)
          signatures << entity.name
        end

        if entity.respond_to?(:layer) && entity.layer
          signatures << entity.layer.name
        end

        if entity.respond_to?(:definition) && entity.definition
          signatures << entity.definition.name if entity.definition.respond_to?(:name)
        end

        dictionaries = entity.attribute_dictionaries if entity.respond_to?(:attribute_dictionaries)
        if dictionaries
          dictionaries.each do |dict|
            signatures << dict.name if dict.respond_to?(:name)
            dict.each_pair do |key, value|
              signatures << key.to_s
              signatures << value if value.is_a?(String) && value.length <= 120
            end
          end
        end

        normalized = signatures.compact.map { |value| normalize_signature(value) }.reject(&:empty?)
        return false if normalized.empty?

        normalized.any? { |value| AUTODIM_STRONG_PATTERNS.any? { |pattern| value.include?(pattern) } } ||
          normalized.any? { |value| DIM_TAG_NAMES.include?(value) }
      rescue StandardError
        false
      end

      def normalize_signature(value)
        value.to_s.strip.downcase.gsub(/\s+/, ' ')
      end

      def push_result_to_dialog(stats)
        return unless @dialog

        payload = JSON.generate(stats)
        @dialog.execute_script("window.VADA_DIM && window.VADA_DIM.showResult(#{payload});")
      rescue StandardError => error
        warn("[#{EXTENSION_NAME}] Không cập nhật được giao diện: #{error.message}")
      end
    end

    unless file_loaded?(__FILE__)
      command = UI::Command.new("Chọn toàn bộ DIM v#{VERSION}") do
        select_all_dimensions(true)
      end
      command.tooltip = "Chọn toàn bộ DIM - v#{VERSION}"
      command.status_bar_text = 'Một lần bấm: quét và chọn DIM ngoài model, trong Group/Component và AutoDim/AuDim.'
      command.small_icon = File.join(PLUGIN_DIR, 'icon_16.png')
      command.large_icon = File.join(PLUGIN_DIR, 'icon_24.png')

      toolbar = UI::Toolbar.new('VADA - Chọn DIM')
      toolbar.add_item(command)
      toolbar.restore

      submenu = UI.menu('Extensions').add_submenu('VADA - Chọn Toàn Bộ DIM')
      submenu.add_item('Chọn ngay toàn bộ DIM') do
        select_all_dimensions(true)
      end
      submenu.add_item('Mở bảng điều khiển...') do
        show_dialog
      end

      file_loaded(__FILE__)
    end
  end
end
