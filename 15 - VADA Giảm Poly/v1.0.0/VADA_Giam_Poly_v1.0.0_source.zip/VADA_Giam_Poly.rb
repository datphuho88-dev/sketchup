# frozen_string_literal: true

require 'sketchup.rb'
require 'extensions.rb'

module VADA
  module GiamPoly
    EXTENSION_NAME = 'VADA Giảm Poly'.freeze
    VERSION = '1.0.0'.freeze
    LOADER_PATH = File.join(__dir__, 'vada_giam_poly', 'main').freeze

    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new(EXTENSION_NAME, LOADER_PATH)
      extension.description = 'Giảm số mặt của Group/Component trong SketchUp, giữ cấu trúc lồng nhau và vật liệu.'
      extension.version = VERSION
      extension.creator = 'Công ty TNHH VADA'
      extension.copyright = '© 2026 Công ty TNHH VADA'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
