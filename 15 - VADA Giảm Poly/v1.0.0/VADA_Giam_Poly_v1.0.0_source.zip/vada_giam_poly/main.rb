# frozen_string_literal: true

require 'sketchup.rb'
require 'json'

module VADA
  module GiamPoly
    VERSION = '1.0.0' unless const_defined?(:VERSION)
    EXTENSION_NAME = 'VADA Giảm Poly' unless const_defined?(:EXTENSION_NAME)
    PREF_KEY = 'VADA_Giam_Poly'.freeze
    FEATURE_ANGLE_DEG = 32.0
    EPSILON = 1.0e-8

    class UnionFind
      def initialize(keys)
        @parent = {}
        @rank = {}
        keys.each do |k|
          @parent[k] = k
          @rank[k] = 0
        end
      end

      def find(x)
        p = @parent[x]
        return x if p == x

        @parent[x] = find(p)
      end

      def union(a, b)
        ra = find(a)
        rb = find(b)
        return if ra == rb

        if @rank[ra] < @rank[rb]
          @parent[ra] = rb
        elsif @rank[ra] > @rank[rb]
          @parent[rb] = ra
        else
          @parent[rb] = ra
          @rank[ra] += 1
        end
      end
    end

    module_function

    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        refresh_stats
        return
      end

      html_path = File.join(__dir__, 'ui.html')
      @dialog = UI::HtmlDialog.new(
        dialog_title: "#{EXTENSION_NAME} v#{VERSION}",
        preferences_key: PREF_KEY,
        scrollable: false,
        resizable: true,
        width: 430,
        height: 620,
        min_width: 390,
        min_height: 560,
        style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dialog.set_file(html_path)
      wire_dialog(@dialog)
      @dialog.show
      UI.start_timer(0.15, false) { refresh_stats }
    end

    def wire_dialog(dialog)
      dialog.add_action_callback('ready') do |_ctx|
        settings = load_settings
        dialog.execute_script("window.vadaLoadSettings(#{JSON.generate(settings)});")
        refresh_stats
      end

      dialog.add_action_callback('refresh') { |_ctx| refresh_stats }

      dialog.add_action_callback('simplify') do |_ctx, payload|
        begin
          settings = normalize_settings(payload)
          save_settings(settings)
          simplify_selection(settings)
        rescue StandardError => e
          model = Sketchup.active_model
          model.abort_operation if model
          report_error(e)
        end
      end

      dialog.add_action_callback('undo') do |_ctx|
        Sketchup.send_action('editUndo:')
        refresh_stats
      end

      dialog.set_on_closed { @dialog = nil }
    end

    def normalize_settings(payload)
      data = payload.is_a?(String) ? JSON.parse(payload) : payload
      ratio = data['ratio'].to_f
      ratio = 5.0 if ratio < 5.0
      ratio = 100.0 if ratio > 100.0
      tolerance_mm = data['tolerance_mm'].to_f
      tolerance_mm = 0.0 if tolerance_mm.negative?

      {
        'ratio' => ratio,
        'tolerance_mm' => tolerance_mm,
        'preserve_features' => data['preserve_features'] != false,
        'recursive' => data['recursive'] != false,
        'smooth' => data['smooth'] != false
      }
    end

    def load_settings
      raw = Sketchup.read_default(PREF_KEY, 'settings', '')
      defaults = {
        'ratio' => 50,
        'tolerance_mm' => 0,
        'preserve_features' => true,
        'recursive' => true,
        'smooth' => true
      }
      return defaults if raw.to_s.empty?

      defaults.merge(JSON.parse(raw))
    rescue StandardError
      defaults
    end

    def save_settings(settings)
      Sketchup.write_default(PREF_KEY, 'settings', JSON.generate(settings))
    end

    def refresh_stats
      return unless @dialog

      model = Sketchup.active_model
      selection = selected_instances(model)
      stats = selection_stats(selection)
      @dialog.execute_script("window.vadaSetStats(#{JSON.generate(stats)});")
    rescue StandardError => e
      report_error(e)
    end

    def selected_instances(model)
      model.selection.select do |entity|
        entity.is_a?(Sketchup::Group) || entity.is_a?(Sketchup::ComponentInstance)
      end
    end

    def selection_stats(selection)
      result = {
        'selected' => selection.length,
        'triangles' => 0,
        'faces' => 0,
        'groups' => 0,
        'components' => 0,
        'textured_faces' => 0
      }

      selection.each do |instance|
        collect_stats(instance_entities(instance), result, true)
      end
      result
    end

    def collect_stats(entities, result, recursive)
      entities.grep(Sketchup::Face).each do |face|
        result['faces'] += 1
        # Ước tính nhanh để tránh quét triangulation nặng chỉ khi mở UI.
        result['triangles'] += [face.vertices.length - 2, 1].max
        result['textured_faces'] += 1 if face.material&.texture || face.back_material&.texture
      end
      return unless recursive

      entities.each do |entity|
        if entity.is_a?(Sketchup::Group)
          result['groups'] += 1
          collect_stats(entity.entities, result, true)
        elsif entity.is_a?(Sketchup::ComponentInstance)
          result['components'] += 1
          collect_stats(entity.definition.entities, result, true)
        end
      end
    end

    def simplify_selection(settings)
      model = Sketchup.active_model
      selection = selected_instances(model)
      if selection.empty?
        UI.messagebox('Hãy chọn ít nhất 1 Group hoặc Component trước khi giảm poly.')
        return
      end

      if settings['ratio'] >= 99.9
        UI.messagebox('Mức giữ lại đang là 100%, không có gì để giảm.')
        return
      end

      before = selection_stats(selection)
      send_status('Đang chuẩn bị hình học...', 3)

      model.start_operation("#{EXTENSION_NAME} v#{VERSION}", true)
      total_scopes = count_scopes(selection, settings['recursive'])
      progress = { done: 0, total: [total_scopes, 1].max }
      totals = { source: 0, output: 0, scopes: 0, skipped: 0 }

      selection.each do |instance|
        make_unique_safe(instance)
        simplify_instance(instance, settings, progress, totals)
      end

      model.commit_operation
      model.active_view.invalidate

      after = selection_stats(selection)
      reduction = if before['triangles'].positive?
                    (100.0 * (1.0 - after['triangles'].to_f / before['triangles'])).round(1)
                  else
                    0.0
                  end

      send_result({
        'ok' => true,
        'before' => before,
        'after' => after,
        'reduction' => reduction,
        'scopes' => totals[:scopes],
        'skipped' => totals[:skipped]
      })
      refresh_stats
    rescue StandardError
      model.abort_operation
      raise
    end

    def count_scopes(selection, recursive)
      selection.sum { |instance| count_entity_scopes(instance_entities(instance), recursive) }
    end

    def count_entity_scopes(entities, recursive)
      count = entities.grep(Sketchup::Face).empty? ? 0 : 1
      return count unless recursive

      entities.each do |entity|
        if entity.is_a?(Sketchup::Group)
          count += count_entity_scopes(entity.entities, true)
        elsif entity.is_a?(Sketchup::ComponentInstance)
          count += count_entity_scopes(entity.definition.entities, true)
        end
      end
      count
    end

    def simplify_instance(instance, settings, progress, totals)
      entities = instance_entities(instance)
      simplify_entities(entities, settings, progress, totals)
      return unless settings['recursive']

      children = entities.select do |e|
        e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
      end
      children.each do |child|
        make_unique_safe(child)
        simplify_instance(child, settings, progress, totals)
      end
    end

    def instance_entities(instance)
      if instance.is_a?(Sketchup::Group)
        instance.entities
      else
        instance.definition.entities
      end
    end

    def make_unique_safe(instance)
      instance.make_unique if instance.respond_to?(:make_unique)
    rescue StandardError
      nil
    end

    def simplify_entities(entities, settings, progress, totals)
      faces = entities.grep(Sketchup::Face)
      return if faces.empty?

      mesh_data = extract_mesh(faces)
      source_count = mesh_data[:triangles].length
      if source_count < 12
        totals[:skipped] += 1
        advance_progress(progress, 'Bỏ qua cụm quá nhỏ')
        return
      end

      target = [(source_count * settings['ratio'] / 100.0).round, 4].max
      simplified = cluster_simplify(mesh_data, target, settings)
      output_count = simplified[:triangles].length

      if output_count >= source_count
        totals[:skipped] += 1
        advance_progress(progress, 'Không thể giảm thêm với giới hạn hiện tại')
        return
      end

      rebuild_entities(entities, faces, simplified, settings)
      totals[:source] += source_count
      totals[:output] += output_count
      totals[:scopes] += 1
      advance_progress(progress, "#{source_count} → #{output_count} tam giác")
    end

    def extract_mesh(faces)
      triangles = []
      unique_points = {}
      edge_normals = Hash.new { |h, k| h[k] = [] }
      edge_materials = Hash.new { |h, k| h[k] = [] }

      faces.each do |face|
        mesh = face.mesh(7)
        pts = mesh.points
        polys = mesh.polygons
        normal = face.normal

        polys.each do |poly|
          ids = poly.map(&:abs)
          next if ids.length < 3

          tri_sets = if ids.length == 3
                       [ids]
                     else
                       (1...(ids.length - 1)).map { |i| [ids[0], ids[i], ids[i + 1]] }
                     end

          tri_sets.each do |tri_ids|
            tri_points = tri_ids.map { |idx| pts[idx - 1] }
            next if degenerate_points?(tri_points)

            keys = tri_points.map { |pt| point_key(pt) }
            tri_points.each_with_index { |pt, i| unique_points[keys[i]] ||= pt }

            uv_front = tri_ids.map { |idx| normalized_uv(mesh.uv_at(idx, true)) }
            uv_back = tri_ids.map { |idx| normalized_uv(mesh.uv_at(idx, false)) }

            tri = {
              keys: keys,
              points: tri_points,
              normal: normal,
              material: face.material,
              back_material: face.back_material,
              uv_front: uv_front,
              uv_back: uv_back,
              layer: face.layer
            }
            triangles << tri

            [[0, 1], [1, 2], [2, 0]].each do |a, b|
              edge_key = [keys[a], keys[b]].sort.join('~')
              edge_normals[edge_key] << normal
              edge_materials[edge_key] << [face.material&.entityID, face.back_material&.entityID]
            end
          end
        end
      end

      {
        triangles: triangles,
        points: unique_points,
        edge_normals: edge_normals,
        edge_materials: edge_materials
      }
    end

    def normalized_uv(uvq)
      return nil unless uvq
      return nil if uvq.z.abs < EPSILON

      Geom::Point3d.new(uvq.x / uvq.z, uvq.y / uvq.z, 0)
    rescue StandardError
      nil
    end

    def degenerate_points?(pts)
      a = pts[0].vector_to(pts[1])
      b = pts[0].vector_to(pts[2])
      a.cross(b).length < EPSILON
    end

    def point_key(pt)
      format('%.8f,%.8f,%.8f', pt.x.to_f, pt.y.to_f, pt.z.to_f)
    end

    def cluster_simplify(mesh_data, target, settings)
      points = mesh_data[:points]
      triangles = mesh_data[:triangles]
      locked = feature_vertices(mesh_data, settings['preserve_features'])
      components = connected_components(points.keys, triangles)
      bbox = bounds_for_points(points.values)
      max_extent = [bbox[:dx], bbox[:dy], bbox[:dz]].max
      return { triangles: triangles } if max_extent <= EPSILON

      target = [target, 4].max
      high = max_extent * 2.0
      low = 0.0
      best = high

      15.times do
        mid = (low + high) * 0.5
        count = clustered_triangle_count(triangles, points, locked, components, bbox, mid)
        if count <= target
          best = mid
          high = mid
        else
          low = mid
        end
      end

      tolerance_mm = settings['tolerance_mm'].to_f
      if tolerance_mm.positive?
        max_cell = tolerance_mm.mm.to_f / Math.sqrt(3.0)
        best = [best, max_cell].min
      end

      build_clustered_mesh(triangles, points, locked, components, bbox, best)
    end

    def feature_vertices(mesh_data, preserve)
      return {} unless preserve

      locked = {}
      limit = FEATURE_ANGLE_DEG.degrees
      mesh_data[:edge_normals].each do |edge_key, normals|
        feature = normals.length == 1
        if !feature && normals.length >= 2
          base = normals.first
          feature = normals[1..].any? { |n| base.angle_between(n) > limit }
        end
        materials = mesh_data[:edge_materials][edge_key]
        feature ||= materials.uniq.length > 1
        next unless feature

        a, b = edge_key.split('~', 2)
        locked[a] = true
        locked[b] = true
      end
      locked
    end

    def connected_components(keys, triangles)
      uf = UnionFind.new(keys)
      triangles.each do |tri|
        a, b, c = tri[:keys]
        uf.union(a, b)
        uf.union(b, c)
      end
      result = {}
      keys.each { |k| result[k] = uf.find(k) }
      result
    end

    def bounds_for_points(points)
      xs = points.map(&:x)
      ys = points.map(&:y)
      zs = points.map(&:z)
      min_x, max_x = xs.minmax
      min_y, max_y = ys.minmax
      min_z, max_z = zs.minmax
      {
        min_x: min_x, min_y: min_y, min_z: min_z,
        dx: max_x - min_x, dy: max_y - min_y, dz: max_z - min_z
      }
    end

    def cluster_id(key, pt, locked, components, bbox, cell)
      return "L|#{key}" if locked[key] || cell <= EPSILON

      ix = ((pt.x - bbox[:min_x]) / cell).floor
      iy = ((pt.y - bbox[:min_y]) / cell).floor
      iz = ((pt.z - bbox[:min_z]) / cell).floor
      "C|#{components[key]}|#{ix}|#{iy}|#{iz}"
    end

    def clustered_triangle_count(triangles, points, locked, components, bbox, cell)
      seen = {}
      count = 0
      triangles.each do |tri|
        ids = tri[:keys].map do |k|
          cluster_id(k, points[k], locked, components, bbox, cell)
        end
        next if ids.uniq.length < 3

        key = ids.sort.join('>')
        next if seen[key]

        seen[key] = true
        count += 1
      end
      count
    end

    def build_clustered_mesh(triangles, points, locked, components, bbox, cell)
      sums = Hash.new { |h, k| h[k] = [0.0, 0.0, 0.0, 0] }
      point_to_cluster = {}

      points.each do |key, pt|
        cid = cluster_id(key, pt, locked, components, bbox, cell)
        point_to_cluster[key] = cid
        s = sums[cid]
        s[0] += pt.x
        s[1] += pt.y
        s[2] += pt.z
        s[3] += 1
      end

      centers = {}
      sums.each do |cid, s|
        centers[cid] = Geom::Point3d.new(s[0] / s[3], s[1] / s[3], s[2] / s[3])
      end

      out = []
      seen = {}
      triangles.each do |tri|
        cids = tri[:keys].map { |k| point_to_cluster[k] }
        next if cids.uniq.length < 3

        dedupe_key = cids.sort.join('>')
        next if seen[dedupe_key]

        new_points = cids.map { |cid| centers[cid] }
        next if degenerate_points?(new_points)

        seen[dedupe_key] = true
        out << tri.merge(points: new_points)
      end

      { triangles: out }
    end

    def rebuild_entities(entities, old_faces, simplified, settings)
      old_edges = old_faces.flat_map(&:edges).uniq
      entities.erase_entities(old_edges)

      new_faces = []
      entities.build do |builder|
        simplified[:triangles].each do |tri|
          pts = tri[:points]
          face = builder.add_face(pts)
          next unless face

          if face.normal.dot(tri[:normal]) < 0
            face.reverse!
          end
          apply_face_attributes(face, tri)
          new_faces << face
        rescue ArgumentError, RuntimeError
          next
        end
      end

      smooth_edges(entities) if settings['smooth']
      new_faces.length
    end

    def apply_face_attributes(face, tri)
      face.layer = tri[:layer] if tri[:layer]

      front = tri[:material]
      if front
        face.material = front
        if front.texture && tri[:uv_front].all?
          mapping = []
          tri[:points].each_with_index do |pt, i|
            mapping << pt
            mapping << tri[:uv_front][i]
          end
          face.position_material(front, mapping, true)
        end
      end

      back = tri[:back_material]
      if back
        face.back_material = back
        if back.texture && tri[:uv_back].all?
          mapping = []
          tri[:points].each_with_index do |pt, i|
            mapping << pt
            mapping << tri[:uv_back][i]
          end
          face.position_material(back, mapping, false)
        end
      end
    rescue StandardError
      # Vẫn giữ được hình học và vật liệu cơ bản nếu UV của một mặt đặc biệt không thể đặt lại.
      face.material = front if front
      face.back_material = back if back
    end

    def smooth_edges(entities)
      threshold = 25.degrees
      entities.grep(Sketchup::Edge).each do |edge|
        next unless edge.faces.length == 2

        angle = edge.faces[0].normal.angle_between(edge.faces[1].normal)
        if angle < threshold
          edge.soft = true
          edge.smooth = true
        end
      end
    end

    def advance_progress(progress, message)
      progress[:done] += 1
      pct = 5 + ((progress[:done].to_f / progress[:total]) * 90).round
      send_status(message, [pct, 95].min)
    end

    def send_status(text, percent)
      return unless @dialog

      payload = { 'text' => text, 'percent' => percent }
      @dialog.execute_script("window.vadaSetStatus(#{JSON.generate(payload)});")
    end

    def send_result(payload)
      return unless @dialog

      @dialog.execute_script("window.vadaShowResult(#{JSON.generate(payload)});")
    end

    def report_error(error)
      warn("[#{EXTENSION_NAME}] #{error.class}: #{error.message}\n#{error.backtrace&.join("\n")}")
      @dialog&.execute_script("window.vadaShowError(#{JSON.generate(error.message)});")
      UI.messagebox("#{EXTENSION_NAME} gặp lỗi:\n#{error.message}") unless @dialog
    end

    unless file_loaded?(__FILE__)
      command = UI::Command.new(EXTENSION_NAME) { show_dialog }
      command.tooltip = "#{EXTENSION_NAME} v#{VERSION}"
      command.status_bar_text = 'Giảm số mặt của Group/Component đã chọn.'
      command.small_icon = File.join(__dir__, 'icon_24.png')
      command.large_icon = File.join(__dir__, 'icon_32.png')

      toolbar = UI::Toolbar.new('VADA Giảm Poly')
      toolbar.add_item(command)
      toolbar.restore

      menu = UI.menu('Extensions')
      vada_menu = menu.add_submenu('VADA')
      vada_menu.add_item(command)

      file_loaded(__FILE__)
    end
  end
end
