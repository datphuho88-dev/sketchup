# frozen_string_literal: true

require 'sketchup.rb'
require 'json'

module VADA
  module GiamPoly
    VERSION = '1.1.0' unless const_defined?(:VERSION)
    EXTENSION_NAME = 'VADA Giảm Poly' unless const_defined?(:EXTENSION_NAME)
    PREF_KEY = 'VADA_Giam_Poly'.freeze

    FEATURE_ANGLE_DEG = 32.0
    EPSILON = 1.0e-8
    POINT_KEY_SCALE = 1_000_000.0
    FAST_TRIANGLE_THRESHOLD = 50_000
    VERY_LARGE_TRIANGLE_THRESHOLD = 250_000
    SEARCH_STEPS_NORMAL = 9
    SEARCH_STEPS_FAST = 6
    STATS_TIME_SLICE = 0.012
    STATS_MAX_ENTITIES_PER_TICK = 1_500

    class UnionFind
      def initialize(size)
        @parent = Array.new(size) { |i| i }
        @rank = Array.new(size, 0)
      end

      def find(x)
        root = x
        root = @parent[root] while @parent[root] != root
        while @parent[x] != x
          parent = @parent[x]
          @parent[x] = root
          x = parent
        end
        root
      end

      def union(a, b)
        ra = find(a)
        rb = find(b)
        return if ra == rb

        if @rank[ra] < @rank[rb]
          @parent[ra] = rb
        elsif @rank[ra] > @rank[rb]
          @parent[rb] = ra
        else
          @parent[rb] = ra
          @rank[ra] += 1
        end
      end

      def roots
        Array.new(@parent.length) { |i| find(i) }
      end
    end

    module_function

    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        refresh_stats
        return
      end

      html_path = File.join(__dir__, 'ui.html')
      @dialog = UI::HtmlDialog.new(
        dialog_title: "#{EXTENSION_NAME} v#{VERSION}",
        preferences_key: PREF_KEY,
        scrollable: false,
        resizable: true,
        width: 450,
        height: 690,
        min_width: 400,
        min_height: 620,
        style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dialog.set_file(html_path)
      wire_dialog(@dialog)
      @dialog.show
      UI.start_timer(0.15, false) { refresh_stats }
    end

    def wire_dialog(dialog)
      dialog.add_action_callback('ready') do |_ctx|
        settings = load_settings
        dialog.execute_script("window.vadaLoadSettings(#{JSON.generate(settings)});")
        refresh_stats
      end

      dialog.add_action_callback('refresh') { |_ctx| refresh_stats }

      dialog.add_action_callback('simplify') do |_ctx, payload|
        begin
          settings = normalize_settings(payload)
          save_settings(settings)
          simplify_selection(settings)
        rescue StandardError => e
          model = Sketchup.active_model
          model.abort_operation if model
          report_error(e)
        end
      end

      dialog.add_action_callback('undo') do |_ctx|
        Sketchup.send_action('editUndo:')
        refresh_stats
      end

      dialog.set_on_closed do
        @dialog = nil
        @stats_generation = (@stats_generation || 0) + 1
      end
    end

    def normalize_settings(payload)
      data = payload.is_a?(String) ? JSON.parse(payload) : payload
      ratio = data['ratio'].to_f
      ratio = 5.0 if ratio < 5.0
      ratio = 100.0 if ratio > 100.0
      tolerance_mm = data['tolerance_mm'].to_f
      tolerance_mm = 0.0 if tolerance_mm.negative?

      {
        'ratio' => ratio,
        'tolerance_mm' => tolerance_mm,
        'preserve_features' => data['preserve_features'] != false,
        'recursive' => data['recursive'] != false,
        'smooth' => data['smooth'] != false,
        'performance_mode' => data['performance_mode'] != false
      }
    end

    def load_settings
      raw = Sketchup.read_default(PREF_KEY, 'settings', '')
      defaults = {
        'ratio' => 50,
        'tolerance_mm' => 0,
        'preserve_features' => true,
        'recursive' => true,
        'smooth' => true,
        'performance_mode' => true
      }
      return defaults if raw.to_s.empty?

      defaults.merge(JSON.parse(raw))
    rescue StandardError
      defaults
    end

    def save_settings(settings)
      Sketchup.write_default(PREF_KEY, 'settings', JSON.generate(settings))
    end

    # Đọc thống kê theo time-slice để cửa sổ không bị treo khi vùng chọn có rất nhiều entity.
    def refresh_stats
      return unless @dialog

      model = Sketchup.active_model
      selection = selected_instances(model)
      generation = (@stats_generation || 0) + 1
      @stats_generation = generation

      result = {
        'selected' => selection.length,
        'triangles' => 0,
        'faces' => 0,
        'groups' => 0,
        'components' => 0,
        'textured_faces' => 0,
        'scanning' => true
      }
      send_stats(result)

      stack = selection.reverse.map do |instance|
        entities = instance_entities(instance)
        { entities: entities, index: 0, length: safe_entities_length(entities) }
      end
      process_stats_slice(generation, stack, result)
    rescue StandardError => e
      report_error(e)
    end

    def safe_entities_length(entities)
      entities.length
    rescue StandardError
      entities.to_a.length
    end

    def process_stats_slice(generation, stack, result)
      return unless @dialog
      return unless generation == @stats_generation

      started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      processed = 0

      while stack.any?
        scope = stack.last
        if scope[:index] >= scope[:length]
          stack.pop
          next
        end

        entity = begin
          scope[:entities][scope[:index]]
        rescue StandardError
          nil
        end
        scope[:index] += 1
        processed += 1

        case entity
        when Sketchup::Face
          result['faces'] += 1
          result['triangles'] += [entity.vertices.length - 2, 1].max
          result['textured_faces'] += 1 if entity.material&.texture || entity.back_material&.texture
        when Sketchup::Group
          result['groups'] += 1
          child_entities = entity.entities
          stack << { entities: child_entities, index: 0, length: safe_entities_length(child_entities) }
        when Sketchup::ComponentInstance
          result['components'] += 1
          child_entities = entity.definition.entities
          stack << { entities: child_entities, index: 0, length: safe_entities_length(child_entities) }
        end

        break if processed >= STATS_MAX_ENTITIES_PER_TICK
        elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - started
        break if elapsed >= STATS_TIME_SLICE
      end

      if stack.empty?
        result['scanning'] = false
        send_stats(result)
      else
        send_stats(result)
        UI.start_timer(0.01, false) { process_stats_slice(generation, stack, result) }
      end
    rescue StandardError => e
      report_error(e)
    end

    def send_stats(result)
      return unless @dialog

      @dialog.execute_script("window.vadaSetStats(#{JSON.generate(result)});")
    end

    def selected_instances(model)
      model.selection.select do |entity|
        entity.is_a?(Sketchup::Group) || entity.is_a?(Sketchup::ComponentInstance)
      end
    end

    def simplify_selection(settings)
      model = Sketchup.active_model
      selection = selected_instances(model)
      if selection.empty?
        UI.messagebox('Hãy chọn ít nhất 1 Group hoặc Component trước khi giảm poly.')
        return
      end

      if settings['ratio'] >= 99.9
        UI.messagebox('Mức giữ lại đang là 100%, không có gì để giảm.')
        return
      end

      # Hủy job thống kê đang chạy để không tranh CPU trong lúc simplify.
      @stats_generation = (@stats_generation || 0) + 1
      send_status('Đang chuẩn bị hình học...', 3)

      model.start_operation("#{EXTENSION_NAME} v#{VERSION}", true)
      progress = { done: 0 }
      totals = {
        source: 0,
        output: 0,
        scopes: 0,
        skipped: 0,
        fast_scopes: 0,
        uv_preserved_scopes: 0
      }

      selection.each do |instance|
        make_unique_safe(instance)
        simplify_instance(instance, settings, progress, totals)
      end

      model.commit_operation
      model.active_view.invalidate

      reduction = if totals[:source].positive?
                    (100.0 * (1.0 - totals[:output].to_f / totals[:source])).round(1)
                  else
                    0.0
                  end

      send_result({
        'ok' => true,
        'before' => { 'triangles' => totals[:source] },
        'after' => { 'triangles' => totals[:output] },
        'reduction' => reduction,
        'scopes' => totals[:scopes],
        'skipped' => totals[:skipped],
        'fast_scopes' => totals[:fast_scopes],
        'uv_preserved_scopes' => totals[:uv_preserved_scopes]
      })
      refresh_stats
    rescue StandardError
      model.abort_operation
      raise
    end

    def simplify_instance(instance, settings, progress, totals)
      entities = instance_entities(instance)
      simplify_entities(entities, settings, progress, totals)
      return unless settings['recursive']

      children = []
      entities.each do |entity|
        children << entity if entity.is_a?(Sketchup::Group) || entity.is_a?(Sketchup::ComponentInstance)
      end

      children.each do |child|
        make_unique_safe(child)
        simplify_instance(child, settings, progress, totals)
      end
    end

    def instance_entities(instance)
      if instance.is_a?(Sketchup::Group)
        instance.entities
      else
        instance.definition.entities
      end
    end

    def make_unique_safe(instance)
      return unless instance.is_a?(Sketchup::ComponentInstance)
      return unless instance.respond_to?(:make_unique)
      return if instance.definition.instances.length <= 1

      instance.make_unique
    rescue StandardError
      nil
    end

    def simplify_entities(entities, settings, progress, totals)
      faces = entities.grep(Sketchup::Face)
      return if faces.empty?

      rough_count = estimated_triangle_count(faces)
      fast_active = settings['performance_mode'] && rough_count >= FAST_TRIANGLE_THRESHOLD
      preserve_uv = !fast_active

      if rough_count >= VERY_LARGE_TRIANGLE_THRESHOLD
        mode_text = fast_active ? 'Turbo' : 'chất lượng cao'
        send_status("Mesh lớn ~#{format_number(rough_count)} tam giác · chế độ #{mode_text}...", progress_percent(progress))
      end

      mesh_data = extract_mesh(faces, settings, preserve_uv)
      source_count = mesh_data[:triangles].length
      totals[:source] += source_count

      if source_count < 12
        totals[:output] += source_count
        totals[:skipped] += 1
        advance_progress(progress, 'Bỏ qua cụm quá nhỏ')
        return
      end

      target = [(source_count * settings['ratio'] / 100.0).round, 4].max
      simplified = cluster_simplify(mesh_data, target, settings, fast_active)
      output_count = simplified[:triangles].length

      if output_count >= source_count
        totals[:output] += source_count
        totals[:skipped] += 1
        advance_progress(progress, 'Không thể giảm thêm với giới hạn hiện tại')
        return
      end

      rebuild_entities(entities, mesh_data[:source_edges], simplified, settings)
      totals[:output] += output_count
      totals[:scopes] += 1
      totals[:fast_scopes] += 1 if fast_active
      totals[:uv_preserved_scopes] += 1 if preserve_uv
      advance_progress(progress, "#{format_number(source_count)} → #{format_number(output_count)} tam giác#{fast_active ? ' · Turbo' : ''}")
    ensure
      # Giải phóng tham chiếu tới dữ liệu mesh lớn càng sớm càng tốt giữa các scope.
      mesh_data = nil
      simplified = nil
    end

    def estimated_triangle_count(faces)
      total = 0
      faces.each { |face| total += [face.vertices.length - 2, 1].max }
      total
    end

    def extract_mesh(faces, settings, preserve_uv)
      triangles = []
      points = []
      point_index = {}

      faces.each do |face|
        front = face.material
        back = face.back_material
        front_texture = preserve_uv && front&.texture
        back_texture = preserve_uv && back&.texture
        flags = 0
        flags |= 1 if front_texture
        flags |= 2 if back_texture

        mesh = face.mesh(flags)
        mesh_points = mesh.points
        normal = face.normal

        mesh.polygons.each do |poly|
          ids = poly.map(&:abs)
          next if ids.length < 3

          tri_sets = if ids.length == 3
                       [ids]
                     else
                       first = ids[0]
                       Array.new(ids.length - 2) { |i| [first, ids[i + 1], ids[i + 2]] }
                     end

          tri_sets.each do |tri_ids|
            tri_points = [mesh_points[tri_ids[0] - 1], mesh_points[tri_ids[1] - 1], mesh_points[tri_ids[2] - 1]]
            next if degenerate_points?(tri_points)

            indices = Array.new(3)
            3.times do |i|
              pt = tri_points[i]
              key = point_key(pt)
              idx = point_index[key]
              unless idx
                idx = points.length
                point_index[key] = idx
                points << pt
              end
              indices[i] = idx
            end

            uv_front = if front_texture
                         tri_ids.map { |idx| normalized_uv(mesh.uv_at(idx, true)) }
                       end
            uv_back = if back_texture
                        tri_ids.map { |idx| normalized_uv(mesh.uv_at(idx, false)) }
                      end

            triangles << {
              indices: indices,
              normal: normal,
              material: front,
              back_material: back,
              uv_front: uv_front,
              uv_back: uv_back,
              layer: face.layer
            }
          end
        end
      end

      locked, source_edges = feature_vertices_and_edges(faces, point_index, points.length, settings['preserve_features'])

      {
        triangles: triangles,
        points: points,
        locked: locked,
        source_edges: source_edges
      }
    end

    def normalized_uv(uvq)
      return nil unless uvq
      return nil if uvq.z.abs < EPSILON

      Geom::Point3d.new(uvq.x / uvq.z, uvq.y / uvq.z, 0)
    rescue StandardError
      nil
    end

    def degenerate_points?(pts)
      a = pts[0].vector_to(pts[1])
      b = pts[0].vector_to(pts[2])
      a.cross(b).length < EPSILON
    end

    def point_key(pt)
      [
        (pt.x.to_f * POINT_KEY_SCALE).round,
        (pt.y.to_f * POINT_KEY_SCALE).round,
        (pt.z.to_f * POINT_KEY_SCALE).round
      ]
    end

    def feature_vertices_and_edges(faces, point_index, point_count, preserve)
      locked = Array.new(point_count, false)
      source_edges = []
      seen_edges = {}
      limit = FEATURE_ANGLE_DEG.degrees

      faces.each do |face|
        face.edges.each do |edge|
          eid = edge.entityID
          next if seen_edges[eid]

          seen_edges[eid] = true
          source_edges << edge
          next unless preserve

          adjacent = edge.faces
          feature = adjacent.length != 2

          unless feature
            n0 = adjacent[0].normal
            n1 = adjacent[1].normal
            feature = n0.angle_between(n1) > limit
          end

          unless feature
            feature = material_signature(adjacent[0]) != material_signature(adjacent[1])
          end

          next unless feature

          edge.vertices.each do |vertex|
            idx = point_index[point_key(vertex.position)]
            locked[idx] = true if idx
          end
        end
      end

      [locked, source_edges]
    end

    def material_signature(face)
      [face.material&.entityID, face.back_material&.entityID]
    end

    def cluster_simplify(mesh_data, target, settings, fast_active)
      points = mesh_data[:points]
      triangles = mesh_data[:triangles]
      locked = mesh_data[:locked]
      components = connected_components(points.length, triangles)
      bbox = bounds_for_points(points)
      max_extent = [bbox[:dx], bbox[:dy], bbox[:dz]].max
      return { triangles: triangles.map { |tri| tri.merge(points: tri[:indices].map { |i| points[i] }) } } if max_extent <= EPSILON

      target = [target, 4].max
      high = max_extent * 2.0
      low = [max_extent / 65_536.0, EPSILON].max
      best = high
      steps = fast_active ? SEARCH_STEPS_FAST : SEARCH_STEPS_NORMAL

      steps.times do
        mid = (low + high) * 0.5
        count = clustered_triangle_count(triangles, points, locked, components, bbox, mid, target)
        if count <= target
          best = mid
          high = mid
        else
          low = mid
        end
      end

      tolerance_mm = settings['tolerance_mm'].to_f
      if tolerance_mm.positive?
        max_cell = tolerance_mm.mm.to_f / Math.sqrt(3.0)
        best = [best, max_cell].min
      end

      build_clustered_mesh(triangles, points, locked, components, bbox, best)
    end

    def connected_components(point_count, triangles)
      uf = UnionFind.new(point_count)
      triangles.each do |tri|
        a, b, c = tri[:indices]
        uf.union(a, b)
        uf.union(b, c)
      end
      uf.roots
    end

    def bounds_for_points(points)
      first = points.first
      min_x = max_x = first.x
      min_y = max_y = first.y
      min_z = max_z = first.z

      points.each do |pt|
        x = pt.x
        y = pt.y
        z = pt.z
        min_x = x if x < min_x
        max_x = x if x > max_x
        min_y = y if y < min_y
        max_y = y if y > max_y
        min_z = z if z < min_z
        max_z = z if z > max_z
      end

      {
        min_x: min_x, min_y: min_y, min_z: min_z,
        dx: max_x - min_x, dy: max_y - min_y, dz: max_z - min_z
      }
    end

    def cluster_assignments(points, locked, components, bbox, cell, with_centers)
      ids = Array.new(points.length)
      cells = {}
      sums = with_centers ? [] : nil
      counts = with_centers ? [] : nil
      next_id = 0

      points.each_with_index do |pt, index|
        if locked[index] || cell <= EPSILON
          cid = next_id
          next_id += 1
        else
          ix = ((pt.x - bbox[:min_x]) / cell).floor
          iy = ((pt.y - bbox[:min_y]) / cell).floor
          iz = ((pt.z - bbox[:min_z]) / cell).floor
          key = [components[index], ix, iy, iz]
          cid = cells[key]
          unless cid
            cid = next_id
            next_id += 1
            cells[key] = cid
          end
        end

        ids[index] = cid
        next unless with_centers

        if sums[cid]
          sums[cid][0] += pt.x
          sums[cid][1] += pt.y
          sums[cid][2] += pt.z
          counts[cid] += 1
        else
          sums[cid] = [pt.x, pt.y, pt.z]
          counts[cid] = 1
        end
      end

      return ids unless with_centers

      centers = Array.new(next_id)
      next_id.times do |cid|
        s = sums[cid]
        count = counts[cid]
        centers[cid] = Geom::Point3d.new(s[0] / count, s[1] / count, s[2] / count)
      end
      [ids, centers]
    end

    def clustered_triangle_count(triangles, points, locked, components, bbox, cell, target)
      ids = cluster_assignments(points, locked, components, bbox, cell, false)
      count = 0

      triangles.each do |tri|
        a = ids[tri[:indices][0]]
        b = ids[tri[:indices][1]]
        c = ids[tri[:indices][2]]
        next if a == b || b == c || c == a

        count += 1
        return count if count > target
      end
      count
    end

    def build_clustered_mesh(triangles, points, locked, components, bbox, cell)
      ids, centers = cluster_assignments(points, locked, components, bbox, cell, true)
      base = centers.length + 1
      seen = {}
      out = []

      triangles.each do |tri|
        a = ids[tri[:indices][0]]
        b = ids[tri[:indices][1]]
        c = ids[tri[:indices][2]]
        next if a == b || b == c || c == a

        sa, sb, sc = sort3(a, b, c)
        dedupe_key = ((sa * base) + sb) * base + sc
        next if seen[dedupe_key]

        new_points = [centers[a], centers[b], centers[c]]
        next if degenerate_points?(new_points)

        seen[dedupe_key] = true
        out << tri.merge(points: new_points)
      end

      { triangles: out }
    end

    def sort3(a, b, c)
      a, b = b, a if a > b
      b, c = c, b if b > c
      a, b = b, a if a > b
      [a, b, c]
    end

    def rebuild_entities(entities, old_edges, simplified, settings)
      entities.erase_entities(old_edges) unless old_edges.empty?

      new_faces = []
      entities.build do |builder|
        simplified[:triangles].each do |tri|
          pts = tri[:points]
          face = builder.add_face(pts)
          next unless face

          face.reverse! if face.normal.dot(tri[:normal]) < 0
          apply_face_attributes(face, tri)
          new_faces << face
        rescue ArgumentError, RuntimeError
          next
        end
      end

      smooth_new_faces(new_faces) if settings['smooth']
      new_faces.length
    end

    def apply_face_attributes(face, tri)
      face.layer = tri[:layer] if tri[:layer]

      front = tri[:material]
      if front
        face.material = front
        if front.texture && tri[:uv_front]&.all?
          mapping = []
          tri[:points].each_with_index do |pt, i|
            mapping << pt
            mapping << tri[:uv_front][i]
          end
          face.position_material(front, mapping, true)
        end
      end

      back = tri[:back_material]
      if back
        face.back_material = back
        if back.texture && tri[:uv_back]&.all?
          mapping = []
          tri[:points].each_with_index do |pt, i|
            mapping << pt
            mapping << tri[:uv_back][i]
          end
          face.position_material(back, mapping, false)
        end
      end
    rescue StandardError
      face.material = front if front
      face.back_material = back if back
    end

    def smooth_new_faces(faces)
      threshold = 25.degrees
      edges = {}

      faces.each do |face|
        face.edges.each { |edge| edges[edge.entityID] ||= edge }
      end

      edges.each_value do |edge|
        next unless edge.faces.length == 2

        angle = edge.faces[0].normal.angle_between(edge.faces[1].normal)
        next unless angle < threshold

        edge.soft = true
        edge.smooth = true
      end
    end

    def advance_progress(progress, message)
      progress[:done] += 1
      send_status(message, progress_percent(progress))
    end

    def progress_percent(progress)
      [8 + (progress[:done] * 7), 94].min
    end

    def format_number(number)
      number.to_i.to_s.reverse.scan(/.{1,3}/).join('.').reverse
    end

    def send_status(text, percent)
      return unless @dialog

      payload = { 'text' => text, 'percent' => percent }
      @dialog.execute_script("window.vadaSetStatus(#{JSON.generate(payload)});")
    end

    def send_result(payload)
      return unless @dialog

      @dialog.execute_script("window.vadaShowResult(#{JSON.generate(payload)});")
    end

    def report_error(error)
      warn("[#{EXTENSION_NAME}] #{error.class}: #{error.message}\n#{error.backtrace&.join("\n")}")
      @dialog&.execute_script("window.vadaShowError(#{JSON.generate(error.message)});")
      UI.messagebox("#{EXTENSION_NAME} gặp lỗi:\n#{error.message}") unless @dialog
    end

    unless file_loaded?(__FILE__)
      command = UI::Command.new(EXTENSION_NAME) { show_dialog }
      command.tooltip = "#{EXTENSION_NAME} v#{VERSION}"
      command.status_bar_text = 'Giảm số mặt của Group/Component đã chọn.'
      command.small_icon = File.join(__dir__, 'icon_24.png')
      command.large_icon = File.join(__dir__, 'icon_32.png')

      toolbar = UI::Toolbar.new('VADA Giảm Poly')
      toolbar.add_item(command)
      toolbar.restore

      menu = UI.menu('Extensions')
      vada_menu = menu.add_submenu('VADA')
      vada_menu.add_item(command)

      file_loaded(__FILE__)
    end
  end
end
