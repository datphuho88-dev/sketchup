# VADA - Quản lý Style Dim & Ghi chú

**Phiên bản:** v1.2.0

Plugin quản lý thư viện Style cho Dimension và Ghi chú trong SketchUp, dùng lại được khi mở file mới hoặc file do người khác gửi.

## Chức năng chính

- Lưu nhiều bộ Style độc lập với file `.skp`.
- Tạo Style mới, nhân bản, đổi tên, xóa và cập nhật Style.
- Danh sách Style có tìm kiếm và hiển thị Style đang hoạt động.
- Dimension: đơn vị, số lẻ, hậu tố đơn vị, màu, mũi tên, hướng chữ và vị trí chữ.
- Ghi chú: màu, Leader, kiểu mũi tên và độ dày Leader.
- Áp toàn model hoặc chỉ vùng đang chọn.
- Tự áp Style cho Dimension/Ghi chú native mới.
- Có công cụ chẩn đoán Dimension do plugin khác tạo.
- UI tiếng Việt, nền `#000000`, tối ưu thao tác nhanh trên SketchUp 2023.

## Sửa lỗi Dim do plugin khác tạo — v1.2.0

v1.2.0 không chỉ dựa vào `EntitiesObserver#onElementAdded` nữa. Sau mỗi transaction có thay đổi, plugin tạo snapshot các annotation native theo `persistent_id` và phát hiện Dimension mới trên toàn bộ model/definitions. Cơ chế này giúp bắt các Dimension native do plugin khác tạo trong trường hợp callback thêm entity bị bỏ lỡ hoặc plugin tạo chúng theo batch.

- Không polling liên tục.
- Có một lần kiểm tra ngay sau transaction và một pass ngắn sau đó để bắt plugin hoàn tất bằng callback/timer.
- `onElementModified` chỉ áp lại cho Dimension vừa mới phát hiện trong khoảng ngắn, tránh ghi đè các chỉnh sửa thủ công trên Dimension cũ.

## Chữ đậm / Font trên SketchUp 2023

SketchUp Ruby API 2023 **không có API để đổi Font, cỡ chữ hoặc Bold của Dimension**, đồng thời không có `DimensionsOptions` để ghi các thiết lập mặc định trong Model Info.

Vì vậy v1.2.0 xử lý rõ ràng hơn:

- Style vẫn lưu lựa chọn `Font / Size / Bold` để nhớ cấu hình của từng bộ Style.
- Giao diện không còn giả rằng checkbox Bold có thể tự áp trên SketchUp 2023.
- Có nút mở trực tiếp `Model Info → Dimensions` để đặt Bold native cho file.
- Các thuộc tính Ruby API hỗ trợ thật như màu, mũi tên, hướng/vị trí chữ và đơn vị vẫn tự động áp.
- Font của `Sketchup::Text` chỉ được Ruby API hỗ trợ từ SketchUp 2026.2; plugin tự kiểm tra capability trước khi áp.

## Chẩn đoán plugin Dim

Trong tab **TỰ ÁP / TƯƠNG THÍCH**:

1. Chọn Dim vừa tạo bằng plugin khác hoặc Group chứa nó.
2. Bấm **KIỂM TRA ĐỐI TƯỢNG ĐANG CHỌN**.
3. Nếu tìm thấy `DimensionLinear/DimensionRadial`, VADA có thể áp Style native.
4. Nếu không tìm thấy Dimension native, plugin kia có thể đang vẽ bằng Overlay/Line/Text riêng; Style Dimension native của SketchUp không thể điều khiển trực tiếp loại đó nếu không có tích hợp riêng với plugin nguồn.

## Cài đặt

1. Tải `VADA_Quan_Ly_Style_Dim_Ghi_Chu_v1.2.0.rbz`.
2. SketchUp → **Extension Manager** → **Install Extension**.
3. Chọn file RBZ.
4. Sau khi cập nhật từ bản cũ, thoát hoàn toàn SketchUp rồi mở lại vì v1.2.0 thay đổi observer và cơ chế snapshot.

## Thay đổi v1.2.0

- Thêm thư viện Style dạng danh sách bên trái.
- Thêm **Tạo Style mới / Nhân bản / Đổi tên / Xóa / Lưu thay đổi**.
- Lưu tên các bộ Style bằng `Sketchup.write_default`, không phụ thuộc file SKP.
- Thêm tìm kiếm Style.
- Thiết kế lại UI gọn hơn, action chính luôn nằm ở thanh dưới.
- Thêm màu nhanh cho Dim và Ghi chú.
- Thêm snapshot theo transaction để bắt Dimension native do plugin khác tạo.
- Thêm chẩn đoán loại Dimension đang chọn.
- Làm rõ giới hạn Bold/Font của SketchUp 2023, không giả lập tính năng API không hỗ trợ.
- Giữ lại toàn bộ chức năng đang hoạt động của v1.1.1.
