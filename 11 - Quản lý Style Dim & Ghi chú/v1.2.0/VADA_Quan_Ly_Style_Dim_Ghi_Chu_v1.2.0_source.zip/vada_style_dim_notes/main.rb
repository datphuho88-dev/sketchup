# frozen_string_literal: true

require 'sketchup.rb'
require 'json'

module VADA
  module StyleDimNotes
    extend self

    VERSION = '1.2.0'.freeze unless const_defined?(:VERSION)
    PREF_KEY = 'VADA_Style_Dim_Notes'.freeze
    DEFAULT_PRESET_NAME = 'VADA Mặc định'.freeze

    ARROW_TYPES = {
      'none' => Sketchup::Dimension::ARROW_NONE,
      'slash' => Sketchup::Dimension::ARROW_SLASH,
      'dot' => Sketchup::Dimension::ARROW_DOT,
      'closed' => Sketchup::Dimension::ARROW_CLOSED,
      'open' => Sketchup::Dimension::ARROW_OPEN
    }.freeze

    UNIT_TYPES = {
      'mm' => Length::Millimeter,
      'cm' => Length::Centimeter,
      'm' => Length::Meter,
      'in' => Length::Inches,
      'ft' => Length::Feet
    }.freeze

    LEADER_TYPES = {
      'view' => ALeaderView,
      'model' => ALeaderModel
    }.freeze

    def default_settings
      {
        'name' => DEFAULT_PRESET_NAME,
        'unit' => 'cm',
        'show_unit' => true,
        'precision' => 1,
        'dim_color' => '#ff2d2d',
        'dim_arrow' => 'closed',
        'dim_text_mode' => 'screen',
        'dim_text_position' => 'center',
        'dim_aligned_position' => 'above',
        'dim_font_name' => 'Arial',
        'dim_font_size' => 14,
        'dim_font_bold' => true,
        'note_color' => '#ffd400',
        'note_display_leader' => true,
        'note_leader_type' => 'view',
        'note_arrow' => 'closed',
        'note_line_weight' => 1,
        'note_font_name' => 'Arial',
        'note_font_size' => 14,
        'note_font_bold' => true,
        'note_font_italic' => false,
        'auto_apply_new_dim' => true,
        'auto_apply_new_note' => true
      }
    end

    def presets
      raw = Sketchup.read_default(PREF_KEY, 'presets_json', '')
      data = raw.to_s.empty? ? [] : JSON.parse(raw)
      unless data.is_a?(Array) && !data.empty?
        data = [default_settings]
        save_presets(data)
      end
      data
    rescue
      [default_settings]
    end

    def save_presets(list)
      Sketchup.write_default(PREF_KEY, 'presets_json', JSON.generate(list))
    end

    def active_preset_name
      Sketchup.read_default(PREF_KEY, 'active_preset', DEFAULT_PRESET_NAME).to_s
    end

    def save_preset(settings)
      settings = normalize_settings(settings)
      list = presets
      idx = list.index { |p| p['name'].to_s.casecmp(settings['name'].to_s).zero? }
      idx ? list[idx] = settings : list << settings
      save_presets(list)
      save_live_style(settings)
      settings
    end

    def preset_name_taken?(name, except_name = nil)
      target = name.to_s.strip
      presets.any? do |preset|
        pname = preset['name'].to_s
        next false if except_name && pname.casecmp(except_name.to_s).zero?
        pname.casecmp(target).zero?
      end
    end

    def next_preset_name(base = 'Style mới')
      base = base.to_s.strip
      base = 'Style mới' if base.empty?
      return base unless preset_name_taken?(base)
      index = 2
      loop do
        name = "#{base} #{index}"
        return name unless preset_name_taken?(name)
        index += 1
      end
    end

    def create_preset(name, settings = nil)
      clean = name.to_s.strip
      return { ok: false, message: 'Tên Style không được để trống.' } if clean.empty?
      return { ok: false, message: 'Tên Style đã tồn tại.' } if preset_name_taken?(clean)

      preset = normalize_settings(settings || live_style)
      preset['name'] = clean
      list = presets
      list << preset
      save_presets(list)
      save_live_style(preset)
      { ok: true, preset: preset, presets: list, active_preset: clean }
    rescue => e
      { ok: false, message: "#{e.class}: #{e.message}" }
    end

    def update_preset(name, settings)
      clean = name.to_s.strip
      return { ok: false, message: 'Chưa chọn Style cần lưu.' } if clean.empty?
      list = presets
      index = list.index { |preset| preset['name'].to_s.casecmp(clean).zero? }
      return { ok: false, message: 'Không tìm thấy Style cần cập nhật.' } unless index

      preset = normalize_settings(settings || {})
      preset['name'] = list[index]['name'].to_s
      list[index] = preset
      save_presets(list)
      save_live_style(preset)
      { ok: true, preset: preset, presets: list, active_preset: preset['name'] }
    rescue => e
      { ok: false, message: "#{e.class}: #{e.message}" }
    end

    def rename_preset(old_name, new_name)
      old_clean = old_name.to_s.strip
      new_clean = new_name.to_s.strip
      return { ok: false, message: 'Tên mới không được để trống.' } if new_clean.empty?
      return { ok: false, message: 'Tên Style đã tồn tại.' } if preset_name_taken?(new_clean, old_clean)

      list = presets
      index = list.index { |preset| preset['name'].to_s.casecmp(old_clean).zero? }
      return { ok: false, message: 'Không tìm thấy Style cần đổi tên.' } unless index
      list[index] = normalize_settings(list[index].merge('name' => new_clean))
      save_presets(list)

      if active_preset_name.casecmp(old_clean).zero?
        Sketchup.write_default(PREF_KEY, 'active_preset', new_clean)
        save_live_style(list[index])
      end
      { ok: true, preset: list[index], presets: list, active_preset: active_preset_name }
    rescue => e
      { ok: false, message: "#{e.class}: #{e.message}" }
    end

    def duplicate_preset(source_name, new_name = nil)
      list = presets
      source = list.find { |preset| preset['name'].to_s.casecmp(source_name.to_s).zero? }
      return { ok: false, message: 'Không tìm thấy Style gốc.' } unless source

      clean = new_name.to_s.strip
      clean = next_preset_name("#{source['name']} - Bản sao") if clean.empty?
      return { ok: false, message: 'Tên Style đã tồn tại.' } if preset_name_taken?(clean)
      preset = normalize_settings(source.merge('name' => clean))
      list << preset
      save_presets(list)
      save_live_style(preset)
      { ok: true, preset: preset, presets: list, active_preset: clean }
    rescue => e
      { ok: false, message: "#{e.class}: #{e.message}" }
    end

    def delete_preset(name)
      target = name.to_s.strip
      list = presets.reject { |p| p['name'].to_s.casecmp(target).zero? }
      list = [default_settings] if list.empty?
      save_presets(list)
      active = active_preset_name
      if active.casecmp(target).zero? || !list.any? { |p| p['name'].to_s.casecmp(active).zero? }
        active = list.first['name'].to_s
        Sketchup.write_default(PREF_KEY, 'active_preset', active)
        save_live_style(list.first)
      end
      list
    end

    def normalize_settings(input)
      d = default_settings
      s = d.merge(input || {})
      s['name'] = s['name'].to_s.strip
      s['name'] = DEFAULT_PRESET_NAME if s['name'].empty?
      s['unit'] = UNIT_TYPES.key?(s['unit'].to_s) ? s['unit'].to_s : d['unit']
      s['show_unit'] = !!s['show_unit']
      s['precision'] = [[s['precision'].to_i, 0].max, 6].min
      s['dim_color'] = normalize_hex(s['dim_color'], d['dim_color'])
      s['note_color'] = normalize_hex(s['note_color'], d['note_color'])
      s['dim_arrow'] = ARROW_TYPES.key?(s['dim_arrow'].to_s) ? s['dim_arrow'].to_s : d['dim_arrow']
      s['note_arrow'] = ARROW_TYPES.key?(s['note_arrow'].to_s) ? s['note_arrow'].to_s : d['note_arrow']
      s['dim_text_mode'] = %w[screen aligned].include?(s['dim_text_mode'].to_s) ? s['dim_text_mode'].to_s : d['dim_text_mode']
      s['dim_text_position'] = %w[start center end].include?(s['dim_text_position'].to_s) ? s['dim_text_position'].to_s : d['dim_text_position']
      s['dim_aligned_position'] = %w[above center outside].include?(s['dim_aligned_position'].to_s) ? s['dim_aligned_position'].to_s : d['dim_aligned_position']
      s['note_display_leader'] = !!s['note_display_leader']
      s['note_leader_type'] = LEADER_TYPES.key?(s['note_leader_type'].to_s) ? s['note_leader_type'].to_s : d['note_leader_type']
      s['note_line_weight'] = [[s['note_line_weight'].to_i, 1].max, 10].min
      s['dim_font_name'] = s['dim_font_name'].to_s.strip.empty? ? d['dim_font_name'] : s['dim_font_name'].to_s.strip
      s['note_font_name'] = s['note_font_name'].to_s.strip.empty? ? d['note_font_name'] : s['note_font_name'].to_s.strip
      s['dim_font_size'] = [[s['dim_font_size'].to_i, 1].max, 1000].min
      s['note_font_size'] = [[s['note_font_size'].to_i, 1].max, 1000].min
      s['dim_font_bold'] = !!s['dim_font_bold']
      s['note_font_bold'] = !!s['note_font_bold']
      s['note_font_italic'] = !!s['note_font_italic']
      s['auto_apply_new_dim'] = s.key?('auto_apply_new_dim') ? !!s['auto_apply_new_dim'] : d['auto_apply_new_dim']
      s['auto_apply_new_note'] = s.key?('auto_apply_new_note') ? !!s['auto_apply_new_note'] : d['auto_apply_new_note']
      s
    end

    def save_live_style(settings)
      s = normalize_settings(settings)
      Sketchup.write_default(PREF_KEY, 'live_style_json', JSON.generate(s))
      Sketchup.write_default(PREF_KEY, 'active_preset', s['name'])
      s
    rescue
      normalize_settings(settings)
    end

    def live_style
      raw = Sketchup.read_default(PREF_KEY, 'live_style_json', '').to_s
      return normalize_settings(JSON.parse(raw)) unless raw.empty?
      preset = presets.find { |p| p['name'].to_s == active_preset_name }
      normalize_settings(preset || default_settings)
    rescue
      normalize_settings(default_settings)
    end

    def normalize_hex(value, fallback)
      text = value.to_s.strip
      text = "##{text}" unless text.start_with?('#')
      text.match?(/\A#[0-9a-fA-F]{6}\z/) ? text.downcase : fallback
    end

    def color_from_hex(hex)
      s = normalize_hex(hex, '#ffffff').delete_prefix('#')
      Sketchup::Color.new(s[0, 2].to_i(16), s[2, 2].to_i(16), s[4, 2].to_i(16))
    end

    def shared_material(model, prefix, hex)
      name = "#{prefix}_#{normalize_hex(hex, '#ffffff').delete_prefix('#').upcase}"
      mat = model.materials[name] || model.materials.add(name)
      mat.color = color_from_hex(hex)
      mat
    end

    def collect_targets(scope)
      model = Sketchup.active_model
      dims = []
      texts = []
      visited_defs = {}
      entities = scope == 'selection' ? model.selection.to_a : model.entities.to_a
      collect_recursive(entities, dims, texts, visited_defs)
      [dims.uniq, texts.uniq]
    end

    def collect_recursive(entities, dims, texts, visited_defs)
      entities.each do |entity|
        next unless entity && entity.valid?
        if entity.is_a?(Sketchup::DimensionLinear) || entity.is_a?(Sketchup::DimensionRadial)
          dims << entity
        elsif entity.is_a?(Sketchup::Text)
          texts << entity
        elsif entity.is_a?(Sketchup::Group)
          collect_recursive(entity.entities.to_a, dims, texts, visited_defs)
        elsif entity.is_a?(Sketchup::ComponentInstance)
          definition = entity.definition
          next if visited_defs[definition.object_id]
          visited_defs[definition.object_id] = true
          collect_recursive(definition.entities.to_a, dims, texts, visited_defs)
        end
      end
    end

    def apply_units(model, s)
      opts = model.options['UnitsOptions']
      return unless opts
      opts['LengthFormat'] = Length::Decimal if opts.keys.include?('LengthFormat')
      opts['LengthUnit'] = UNIT_TYPES[s['unit']] if opts.keys.include?('LengthUnit')
      opts['LengthPrecision'] = s['precision'] if opts.keys.include?('LengthPrecision')
      opts['SuppressUnitsDisplay'] = !s['show_unit'] if opts.keys.include?('SuppressUnitsDisplay')
    end

    def apply_dimension_style(dim, s, material)
      dim.material = material
      dim.arrow_type = ARROW_TYPES[s['dim_arrow']]
      return unless dim.is_a?(Sketchup::DimensionLinear)

      aligned = s['dim_text_mode'] == 'aligned'
      dim.has_aligned_text = aligned
      dim.text_position = case s['dim_text_position']
                          when 'start' then Sketchup::DimensionLinear::TEXT_OUTSIDE_START
                          when 'end' then Sketchup::DimensionLinear::TEXT_OUTSIDE_END
                          else Sketchup::DimensionLinear::TEXT_CENTERED
                          end
      if aligned
        dim.aligned_text_position = case s['dim_aligned_position']
                                    when 'center' then Sketchup::DimensionLinear::ALIGNED_TEXT_CENTER
                                    when 'outside' then Sketchup::DimensionLinear::ALIGNED_TEXT_OUTSIDE
                                    else Sketchup::DimensionLinear::ALIGNED_TEXT_ABOVE
                                    end
      end
    end

    def note_font_supported?(text = nil)
      return text.respond_to?(:font=) if text
      Sketchup::Text.instance_methods.include?(:font=)
    rescue
      false
    end

    def apply_note_style(text, s, material)
      text.material = material
      text.display_leader = s['note_display_leader']
      if s['note_display_leader']
        text.leader_type = LEADER_TYPES[s['note_leader_type']]
        text.arrow_type = ARROW_TYPES[s['note_arrow']]
        text.line_weight = s['note_line_weight']
      end
      if text.respond_to?(:font=)
        text.font = {
          name: s['note_font_name'],
          size: s['note_font_size'],
          bold: s['note_font_bold'],
          italic: s['note_font_italic']
        }
      end
    end

    class EntitiesWatcher < Sketchup::EntitiesObserver
      def onElementAdded(_entities, entity)
        VADA::StyleDimNotes.handle_new_entity(entity)
      end

      def onElementModified(_entities, entity)
        VADA::StyleDimNotes.handle_modified_entity(entity)
      end
    end

    class DefinitionsWatcher < Sketchup::DefinitionsObserver
      def onComponentAdded(_definitions, definition)
        VADA::StyleDimNotes.handle_new_definition(definition)
      end
    end

    class ModelWatcher < Sketchup::ModelObserver
      def onActivePathChanged(model)
        VADA::StyleDimNotes.attach_model_observers(model)
      end

      # Nhiều plugin tạo Dimension trong một operation rồi chỉnh lại thuộc tính
      # trước khi commit. Chỉ flush sau commit để style VADA là lớp cuối cùng.
      def onTransactionCommit(model)
        VADA::StyleDimNotes.handle_transaction_commit(model)
      end

      def onTransactionUndo(model)
        VADA::StyleDimNotes.schedule_snapshot_scan(model, 0.05)
      end

      def onTransactionRedo(model)
        VADA::StyleDimNotes.schedule_snapshot_scan(model, 0.05)
      end
    end

    class AppWatcher < Sketchup::AppObserver
      def onNewModel(model)
        VADA::StyleDimNotes.attach_model_observers(model)
      end

      def onOpenModel(model)
        VADA::StyleDimNotes.attach_model_observers(model)
      end

      def onActivateModel(model)
        VADA::StyleDimNotes.attach_model_observers(model)
      end
    end

    def attach_entities_collection(entities)
      return false unless entities
      @watched_entities ||= {}
      key = entities.object_id
      return true if @watched_entities[key]
      @entities_watcher ||= EntitiesWatcher.new
      ok = entities.add_observer(@entities_watcher)
      @watched_entities[key] = entities if ok
      !!ok
    rescue
      false
    end

    def attach_definition_collection(model)
      return false unless model && model.respond_to?(:definitions)
      @watched_definitions ||= {}
      definitions = model.definitions
      key = definitions.object_id
      unless @watched_definitions[key]
        @definitions_watcher ||= DefinitionsWatcher.new
        ok = definitions.add_observer(@definitions_watcher)
        @watched_definitions[key] = definitions if ok
      end

      # Plugin Dimension thường tạo dim trực tiếp trong definition của group/component
      # thay vì active_entities. Theo dõi mọi definition hiện có để không bỏ sót.
      definitions.each do |definition|
        attach_entities_collection(definition.entities) if definition && definition.valid?
      end
      true
    rescue
      false
    end

    def attach_model_observers(model = Sketchup.active_model)
      return false unless model
      @watched_models ||= {}
      key = model.object_id
      unless @watched_models[key]
        @model_watcher ||= ModelWatcher.new
        model.add_observer(@model_watcher)
        @watched_models[key] = model
        seed_annotation_snapshot(model)
      end
      attach_entities_collection(model.entities)
      attach_entities_collection(model.active_entities)
      attach_definition_collection(model)
      true
    rescue
      false
    end

    def install_observers
      attach_model_observers(Sketchup.active_model)
      unless @app_watcher_installed
        @app_watcher ||= AppWatcher.new
        Sketchup.add_observer(@app_watcher)
        @app_watcher_installed = true
      end
      true
    rescue
      false
    end

    def annotation_entity?(entity)
      return false unless entity && entity.valid?
      entity.is_a?(Sketchup::DimensionLinear) ||
        entity.is_a?(Sketchup::DimensionRadial) ||
        entity.is_a?(Sketchup::Text)
    rescue
      false
    end

    def annotation_key(entity)
      return nil unless annotation_entity?(entity)
      id = entity.respond_to?(:persistent_id) ? entity.persistent_id.to_i : entity.object_id
      "#{entity.class.name}:#{id}"
    rescue
      nil
    end

    def each_native_annotation(model = Sketchup.active_model)
      return enum_for(:each_native_annotation, model) unless block_given?
      seen_collections = {}
      collections = [model.entities]
      model.definitions.each do |definition|
        collections << definition.entities if definition && definition.valid?
      end
      collections.each do |entities|
        next unless entities
        oid = entities.object_id
        next if seen_collections[oid]
        seen_collections[oid] = true
        entities.each do |entity|
          yield entity if annotation_entity?(entity)
        end
      end
      nil
    rescue
      nil
    end

    def seed_annotation_snapshot(model = Sketchup.active_model)
      @known_annotations ||= {}
      keys = {}
      each_native_annotation(model) do |entity|
        key = annotation_key(entity)
        keys[key] = true if key
      end
      @known_annotations[model.object_id] = keys
      keys.length
    rescue
      0
    end

    def scan_for_new_annotations(model = Sketchup.active_model)
      return 0 if @auto_style_busy || @internal_style_operation
      @known_annotations ||= {}
      known = @known_annotations[model.object_id] ||= {}
      current = {}
      found = 0
      each_native_annotation(model) do |entity|
        key = annotation_key(entity)
        next unless key
        current[key] = true
        next if known[key]
        known[key] = true
        mark_recent_annotation(entity)
        queue_auto_style(entity)
        found += 1
      end
      @known_annotations[model.object_id] = current
      schedule_auto_style_flush(0.0) if found > 0
      found
    rescue => e
      puts "VADA snapshot scan: #{e.class}: #{e.message}" if $VERBOSE
      0
    end

    def schedule_snapshot_scan(model = Sketchup.active_model, delay = 0.08)
      return false unless model
      @snapshot_scan_tokens ||= {}
      token = (@snapshot_scan_tokens[model.object_id] || 0) + 1
      @snapshot_scan_tokens[model.object_id] = token
      UI.start_timer(delay.to_f, false) do
        next unless @snapshot_scan_tokens[model.object_id] == token
        scan_for_new_annotations(model) if model && model.respond_to?(:entities)
      end
      true
    rescue
      false
    end

    def mark_recent_annotation(entity, seconds = 2.0)
      key = annotation_key(entity)
      return unless key
      @recent_annotations ||= {}
      @recent_annotations[key] = Time.now.to_f + seconds.to_f
      key
    rescue
      nil
    end

    def recent_annotation?(entity)
      key = annotation_key(entity)
      return false unless key
      @recent_annotations ||= {}
      deadline = @recent_annotations[key].to_f
      if deadline > Time.now.to_f
        true
      else
        @recent_annotations.delete(key)
        false
      end
    rescue
      false
    end

    def handle_transaction_commit(model)
      return nil if @auto_style_busy || @internal_style_operation
      # Quét theo snapshot sau mọi transaction để bắt Dimension native được tạo
      # bởi plugin khác kể cả khi onElementAdded bị bỏ lỡ do cách plugin tổ chức entity.
      schedule_snapshot_scan(model, 0.03)
      # Một số plugin hoàn tất bằng callback/timer ngay sau commit. Pass thứ hai rất ngắn
      # giúp bắt tình huống đó mà không chạy polling liên tục.
      UI.start_timer(0.30, false) { scan_for_new_annotations(model) if model && model.respond_to?(:entities) }
      schedule_auto_style_flush(0.05)
      nil
    rescue
      nil
    end

    def handle_modified_entity(entity)
      return nil unless annotation_entity?(entity)
      return nil if @auto_style_busy || @internal_style_operation
      # Chỉ áp lại cho annotation vừa được phát hiện gần đây. Tránh phá các chỉnh sửa
      # thủ công của người dùng trên Dimension cũ.
      queue_auto_style(entity) if recent_annotation?(entity)
      nil
    rescue
      nil
    end

    def handle_new_entity(entity)
      return unless entity && entity.valid?

      # Nếu plugin vừa tạo group/component, theo dõi ngay collection bên trong.
      if entity.is_a?(Sketchup::Group)
        attach_entities_collection(entity.entities)
        UI.start_timer(0.0, false) { queue_annotations_in_entities(entity.entities) if entity.valid? }
      elsif entity.is_a?(Sketchup::ComponentInstance)
        definition = entity.definition
        attach_entities_collection(definition.entities) if definition && definition.valid?
      end

      if annotation_entity?(entity)
        mark_recent_annotation(entity)
        queue_auto_style(entity)
      end
      nil
    rescue
      nil
    end

    def handle_new_definition(definition)
      return unless definition && definition.valid?
      attach_entities_collection(definition.entities)

      # Một số plugin/import tạo xong nội dung definition trước khi callback này chạy.
      # Kiểm tra sau khi call stack hiện tại kết thúc để bắt các Dim đã nằm sẵn bên trong.
      UI.start_timer(0.0, false) do
        queue_annotations_in_entities(definition.entities) if definition.valid?
      end
      nil
    rescue
      nil
    end

    def queue_annotations_in_entities(entities)
      return unless entities
      entities.each do |entity|
        next unless entity && entity.valid?
        queue_auto_style(entity) if annotation_entity?(entity)
        if entity.is_a?(Sketchup::Group)
          attach_entities_collection(entity.entities)
          queue_annotations_in_entities(entity.entities)
        elsif entity.is_a?(Sketchup::ComponentInstance)
          definition = entity.definition
          attach_entities_collection(definition.entities) if definition && definition.valid?
        end
      end
      nil
    rescue
      nil
    end

    def queue_auto_style(entity)
      return unless annotation_entity?(entity)
      s = live_style
      is_dim = entity.is_a?(Sketchup::DimensionLinear) || entity.is_a?(Sketchup::DimensionRadial)
      is_note = entity.is_a?(Sketchup::Text)
      return if is_dim && !s['auto_apply_new_dim']
      return if is_note && !s['auto_apply_new_note']

      @pending_auto_entities ||= {}
      key = if entity.respond_to?(:persistent_id)
              entity.persistent_id
            else
              entity.object_id
            end
      @pending_auto_entities[key] = entity
      schedule_auto_style_flush(0.05)
      nil
    rescue
      nil
    end

    def schedule_auto_style_flush(delay = 0.05)
      return if @auto_style_busy
      return unless @pending_auto_entities && !@pending_auto_entities.empty?
      return if @auto_flush_scheduled

      @auto_flush_scheduled = true
      UI.start_timer(delay.to_f, false) do
        @auto_flush_scheduled = false
        flush_auto_style_queue
      end
      true
    rescue
      @auto_flush_scheduled = false
      false
    end

    def flush_auto_style_queue
      return if @auto_style_busy
      pending = @pending_auto_entities || {}
      return if pending.empty?
      @pending_auto_entities = {}

      s = live_style
      entities = pending.values.select { |entity| annotation_entity?(entity) }
      dims = entities.select { |entity| entity.is_a?(Sketchup::DimensionLinear) || entity.is_a?(Sketchup::DimensionRadial) }
      notes = entities.select { |entity| entity.is_a?(Sketchup::Text) }
      dims = [] unless s['auto_apply_new_dim']
      notes = [] unless s['auto_apply_new_note']
      return if dims.empty? && notes.empty?

      @auto_style_busy = true
      @internal_style_operation = true
      model = Sketchup.active_model
      model.start_operation('VADA - Tự áp Style mới', true, false, true)
      apply_units(model, s)
      unless dims.empty?
        dim_mat = shared_material(model, 'VADA_DIM', s['dim_color'])
        dims.each { |dim| apply_dimension_style(dim, s, dim_mat) if dim.valid? }
      end
      unless notes.empty?
        note_mat = shared_material(model, 'VADA_NOTE', s['note_color'])
        notes.each { |text| apply_note_style(text, s, note_mat) if text.valid? }
      end
      model.commit_operation
      model.active_view.invalidate
      nil
    rescue => e
      model.abort_operation rescue nil
      puts "VADA Style auto-apply batch: #{e.class}: #{e.message}" if $VERBOSE
      nil
    ensure
      @auto_style_busy = false
      @internal_style_operation = false
    end

    def apply_style(settings, scope = 'all')
      model = Sketchup.active_model
      s = normalize_settings(settings)
      save_live_style(s)
      install_observers
      dims, texts = collect_targets(scope)
      @internal_style_operation = true
      model.start_operation('VADA - Áp Style Dim & Ghi chú', true)
      apply_units(model, s)
      dim_mat = shared_material(model, 'VADA_DIM', s['dim_color'])
      note_mat = shared_material(model, 'VADA_NOTE', s['note_color'])
      dims.each { |d| apply_dimension_style(d, s, dim_mat) }
      texts.each { |t| apply_note_style(t, s, note_mat) }
      model.commit_operation
      model.active_view.invalidate
      Sketchup.write_default(PREF_KEY, 'active_preset', s['name'])
      {
        ok: true,
        dimensions: dims.length,
        notes: texts.length,
        note_font_applied: texts.any? { |t| t.respond_to?(:font=) },
        dimension_font_applied: false,
        auto_apply_new_dim: s['auto_apply_new_dim'],
        auto_apply_new_note: s['auto_apply_new_note'],
        message: scope == 'selection' ? 'Đã áp cho vùng đang chọn.' : 'Đã áp cho toàn bộ model.'
      }
    rescue => e
      model.abort_operation rescue nil
      { ok: false, message: "#{e.class}: #{e.message}" }
    ensure
      @internal_style_operation = false
      seed_annotation_snapshot(model) if model
    end

    def analyze_selection
      model = Sketchup.active_model
      selection = model.selection.to_a
      dims = []
      texts = []
      classes = Hash.new(0)
      collect_recursive(selection, dims, texts, {}) unless selection.empty?
      selection.each { |entity| classes[entity.class.name.to_s] += 1 if entity }
      native = dims.length
      message = if selection.empty?
                  'Chưa chọn đối tượng nào. Hãy chọn Dim hoặc nhóm Dim do plugin tạo rồi kiểm tra.'
                elsif native > 0
                  "Tìm thấy #{native} Dimension native. VADA có thể áp Style cho các Dimension này."
                else
                  'Không tìm thấy Dimension native trong vùng chọn. Plugin Dim này có thể đang vẽ bằng Overlay/Line/Text riêng; Style Dimension của SketchUp không thể điều khiển trực tiếp kiểu đối tượng đó.'
                end
      { ok: true, native_dimensions: native, texts: texts.length, classes: classes, message: message }
    rescue => e
      { ok: false, message: "#{e.class}: #{e.message}" }
    end

    def current_model_info
      model = Sketchup.active_model
      opts = model.options['UnitsOptions']
      unit_map = UNIT_TYPES.invert
      unit = unit_map[opts['LengthUnit']] || 'cm'
      {
        version: VERSION,
        sketchup_version: Sketchup.version.to_s,
        unit: unit,
        show_unit: !opts['SuppressUnitsDisplay'],
        precision: opts['LengthPrecision'].to_i,
        presets: presets,
        active_preset: active_preset_name,
        live_style: live_style,
        auto_observer: install_observers,
        note_font_api: note_font_supported?,
        dimension_font_api: false
      }
    rescue
      {
        version: VERSION,
        sketchup_version: Sketchup.version.to_s,
        unit: 'cm', show_unit: true, precision: 1,
        presets: presets, active_preset: active_preset_name, live_style: live_style, auto_observer: install_observers,
        note_font_api: false, dimension_font_api: false
      }
    end

    def show_model_info_page(kind)
      pages = UI.model_info_pages
      candidates = kind == 'dimension' ? ['Dimensions', 'Dimension', 'Kích thước'] : ['Text', 'Văn bản', 'Ghi chú']
      page = pages.find do |p|
        candidates.any? { |c| p.to_s.downcase.include?(c.downcase) }
      end
      page ||= kind == 'dimension' ? 'Dimensions' : 'Text'
      UI.show_model_info(page)
    rescue
      UI.messagebox('Không mở được trang Model Info trên phiên bản SketchUp này.')
    end

    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        return
      end

      @dialog = UI::HtmlDialog.new(
        dialog_title: "Quản lý Style Dim & Ghi chú - v#{VERSION}",
        preferences_key: 'VADAStyleDimNotesDialog',
        scrollable: true,
        resizable: true,
        width: 860,
        height: 720,
        min_width: 720,
        min_height: 580,
        style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dialog.set_file(File.join(__dir__, 'ui.html'))

      @dialog.add_action_callback('ready') do |_ctx|
        push_state
      end

      @dialog.add_action_callback('apply_style') do |_ctx, payload|
        data = JSON.parse(payload.to_s)
        result = apply_style(data['settings'] || {}, data['scope'] || 'all')
        @dialog.execute_script("window.VADA.onApplyResult(#{JSON.generate(result)});") if @dialog
      end

      @dialog.add_action_callback('save_preset') do |_ctx, payload|
        preset = save_preset(JSON.parse(payload.to_s))
        @dialog.execute_script("window.VADA.onPresetSaved(#{JSON.generate({ok: true, preset: preset, presets: presets, active_preset: preset['name']})});") if @dialog
      end

      @dialog.add_action_callback('create_preset') do |_ctx, payload|
        data = JSON.parse(payload.to_s)
        result = create_preset(data['name'], data['settings'])
        @dialog.execute_script("window.VADA.onPresetMutation(#{JSON.generate(result)});") if @dialog
      end

      @dialog.add_action_callback('update_preset') do |_ctx, payload|
        data = JSON.parse(payload.to_s)
        result = update_preset(data['name'], data['settings'])
        @dialog.execute_script("window.VADA.onPresetMutation(#{JSON.generate(result)});") if @dialog
      end

      @dialog.add_action_callback('rename_preset') do |_ctx, payload|
        data = JSON.parse(payload.to_s)
        result = rename_preset(data['old_name'], data['new_name'])
        @dialog.execute_script("window.VADA.onPresetMutation(#{JSON.generate(result)});") if @dialog
      end

      @dialog.add_action_callback('duplicate_preset') do |_ctx, payload|
        data = JSON.parse(payload.to_s)
        result = duplicate_preset(data['source_name'], data['new_name'])
        @dialog.execute_script("window.VADA.onPresetMutation(#{JSON.generate(result)});") if @dialog
      end

      @dialog.add_action_callback('delete_preset') do |_ctx, name|
        list = delete_preset(name.to_s)
        active = active_preset_name
        preset = list.find { |item| item['name'].to_s == active } || list.first
        @dialog.execute_script("window.VADA.onPresetMutation(#{JSON.generate({ok: true, preset: preset, presets: list, active_preset: active})});") if @dialog
      end

      @dialog.add_action_callback('analyze_selection') do |_ctx|
        @dialog.execute_script("window.VADA.onAnalyzeSelection(#{JSON.generate(analyze_selection)});") if @dialog
      end

      @dialog.add_action_callback('activate_style') do |_ctx, payload|
        style = save_live_style(JSON.parse(payload.to_s))
        install_observers
        @dialog.execute_script("window.VADA.onStyleActivated(#{JSON.generate({style: style})});") if @dialog
      end

      @dialog.add_action_callback('open_native') do |_ctx, kind|
        show_model_info_page(kind.to_s)
      end

      @dialog.set_on_closed { @dialog = nil }
      @dialog.show
    end

    def push_state
      return unless @dialog
      @dialog.execute_script("window.VADA.init(#{JSON.generate(current_model_info)});")
    end

    def build_ui
      return if @ui_built
      @ui_built = true

      command = UI::Command.new('Quản lý Style Dim & Ghi chú') { show_dialog }
      command.tooltip = 'Quản lý Style Dim & Ghi chú'
      command.status_bar_text = 'Lưu preset và áp nhanh style Dim/Ghi chú cho mọi file SketchUp.'
      icon_small = File.join(__dir__, 'icon_16.png')
      icon_large = File.join(__dir__, 'icon_24.png')
      command.small_icon = icon_small if File.exist?(icon_small)
      command.large_icon = icon_large if File.exist?(icon_large)

      toolbar = UI::Toolbar.new('VADA - Style Dim & Ghi chú')
      toolbar.add_item(command)
      toolbar.show
      @toolbar = toolbar

      UI.menu('Extensions').add_item(command)
      install_observers
    end

    build_ui
  end
end
