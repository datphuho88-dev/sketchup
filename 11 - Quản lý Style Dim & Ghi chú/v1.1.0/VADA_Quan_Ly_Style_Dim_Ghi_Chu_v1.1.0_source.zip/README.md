# VADA - Quản lý Style Dim & Ghi chú

**Phiên bản:** v1.1.0

Plugin lưu và áp nhanh style kích thước/ghi chú cho mọi file SketchUp, đặc biệt hữu ích khi mở file do người khác gửi.

## Chức năng chính

- Chọn đơn vị `mm`, `cm`, `m`, `inch`, `feet`.
- Bật/tắt hậu tố đơn vị và chỉnh độ chính xác 0–6 số lẻ.
- Đổi nhanh màu Dimension và Text/Label.
- Dimension: kiểu mũi tên, chữ theo màn hình/song song đường Dim, vị trí chữ.
- Ghi chú: màu, Leader theo View/Model, kiểu mũi tên, độ dày Leader.
- Lưu nhiều preset Style ngoài file SKP và gọi lại ở file bất kỳ.
- Áp toàn model hoặc chỉ Group/Component/đối tượng đang chọn.
- Tự áp preset đang hoạt động cho Dimension/Ghi chú được tạo mới.
- Có nút mở trực tiếp Model Info → Dimensions/Text cho các thiết lập native.

## Tự áp cho Dim tạo mới

v1.1.0 bổ sung `EntitiesObserver` nhẹ: plugin chỉ phản ứng khi SketchUp thêm một entity mới. Nếu entity đó là Dimension hoặc Text và tùy chọn tự áp đang bật, plugin áp preset hiện tại ngay cho entity đó. Không có timer quét model liên tục.

- `TỰ ÁP STYLE CHO DIM TẠO MỚI`: mặc định bật.
- `Tự áp Style cho Ghi chú tạo mới`: mặc định bật.
- Hoạt động cả khi đang chỉnh sửa bên trong Group/Component nhờ theo dõi `active_entities`.
- Khi mở file mới/file người khác gửi, observer được gắn lại tự động.

## Chữ đậm / Font trên SketchUp 2023

SketchUp Ruby API 2023 không cho extension thay đổi font, cỡ chữ hoặc Bold của Dimension. API font cho `Sketchup::Text` chỉ xuất hiện từ SketchUp 2026.2. Vì vậy:

- Preset vẫn lưu `Font`, `Cỡ chữ`, `Bold` để đồng bộ cấu hình.
- Dimension trên SketchUp 2023: màu/mũi tên/vị trí được tự áp; Font/Bold cần đặt native một lần trong `Model Info → Dimensions` của file.
- Ghi chú trên phiên bản SketchUp có API font sẽ được áp cả font/cỡ/đậm/nghiêng.

## Cài đặt

1. Tải `VADA_Quan_Ly_Style_Dim_Ghi_Chu_v1.1.0.rbz`.
2. SketchUp → **Extension Manager** → **Install Extension**.
3. Chọn file RBZ.
4. Đây là thay đổi có observer và loader; sau khi cập nhật nên thoát hoàn toàn SketchUp rồi mở lại.

## Thay đổi v1.1.0

- Sửa lỗi: Style chỉ áp cho Dim đã có, Dim tạo mới quay về style cũ.
- Thêm cơ chế tự áp preset cho Dim/Ghi chú mới bằng observer, không polling nền.
- Tự gắn observer lại khi mở model mới, mở file khác hoặc đi vào Group/Component.
- Thêm lựa chọn bật/tắt riêng cho Dim mới và Ghi chú mới.
- Làm nổi bật tùy chọn `CHỮ DIM ĐẬM (Bold)` và giải thích giới hạn API của SketchUp 2023.
- Giữ toàn bộ chức năng v1.0.1.
