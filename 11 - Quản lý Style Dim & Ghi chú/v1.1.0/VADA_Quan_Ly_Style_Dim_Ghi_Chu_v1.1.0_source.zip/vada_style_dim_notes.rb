# frozen_string_literal: true

require 'sketchup.rb'
require 'extensions.rb'

module VADA
  module StyleDimNotes
    EXTENSION_NAME = 'VADA - Quản lý Style Dim & Ghi chú'.freeze unless const_defined?(:EXTENSION_NAME)
    VERSION = '1.1.0'.freeze unless const_defined?(:VERSION)

    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new(EXTENSION_NAME, 'vada_style_dim_notes/main')
      extension.description = 'Lưu và áp nhanh Style cho kích thước, đơn vị và ghi chú trong mọi file SketchUp.'
      extension.version = VERSION
      extension.creator = 'Công ty TNHH VADA'
      extension.copyright = '2026 Công ty TNHH VADA'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
