# frozen_string_literal: true

require 'sketchup.rb'
require 'json'

module VADA
  module StyleDimNotes
    extend self

    VERSION = '1.0.1'.freeze unless const_defined?(:VERSION)
    PREF_KEY = 'VADA_Style_Dim_Notes'.freeze
    DEFAULT_PRESET_NAME = 'VADA Mặc định'.freeze

    ARROW_TYPES = {
      'none' => Sketchup::Dimension::ARROW_NONE,
      'slash' => Sketchup::Dimension::ARROW_SLASH,
      'dot' => Sketchup::Dimension::ARROW_DOT,
      'closed' => Sketchup::Dimension::ARROW_CLOSED,
      'open' => Sketchup::Dimension::ARROW_OPEN
    }.freeze

    UNIT_TYPES = {
      'mm' => Length::Millimeter,
      'cm' => Length::Centimeter,
      'm' => Length::Meter,
      'in' => Length::Inches,
      'ft' => Length::Feet
    }.freeze

    LEADER_TYPES = {
      'view' => ALeaderView,
      'model' => ALeaderModel
    }.freeze

    def default_settings
      {
        'name' => DEFAULT_PRESET_NAME,
        'unit' => 'cm',
        'show_unit' => true,
        'precision' => 1,
        'dim_color' => '#ff2d2d',
        'dim_arrow' => 'closed',
        'dim_text_mode' => 'screen',
        'dim_text_position' => 'center',
        'dim_aligned_position' => 'above',
        'dim_font_name' => 'Arial',
        'dim_font_size' => 14,
        'dim_font_bold' => true,
        'note_color' => '#ffd400',
        'note_display_leader' => true,
        'note_leader_type' => 'view',
        'note_arrow' => 'closed',
        'note_line_weight' => 1,
        'note_font_name' => 'Arial',
        'note_font_size' => 14,
        'note_font_bold' => true,
        'note_font_italic' => false
      }
    end

    def presets
      raw = Sketchup.read_default(PREF_KEY, 'presets_json', '')
      data = raw.to_s.empty? ? [] : JSON.parse(raw)
      unless data.is_a?(Array) && !data.empty?
        data = [default_settings]
        save_presets(data)
      end
      data
    rescue
      [default_settings]
    end

    def save_presets(list)
      Sketchup.write_default(PREF_KEY, 'presets_json', JSON.generate(list))
    end

    def active_preset_name
      Sketchup.read_default(PREF_KEY, 'active_preset', DEFAULT_PRESET_NAME).to_s
    end

    def save_preset(settings)
      settings = normalize_settings(settings)
      list = presets
      idx = list.index { |p| p['name'].to_s.casecmp(settings['name'].to_s).zero? }
      idx ? list[idx] = settings : list << settings
      save_presets(list)
      Sketchup.write_default(PREF_KEY, 'active_preset', settings['name'])
      settings
    end

    def delete_preset(name)
      list = presets.reject { |p| p['name'].to_s == name.to_s }
      list = [default_settings] if list.empty?
      save_presets(list)
      Sketchup.write_default(PREF_KEY, 'active_preset', list.first['name'])
      list
    end

    def normalize_settings(input)
      d = default_settings
      s = d.merge(input || {})
      s['name'] = s['name'].to_s.strip
      s['name'] = DEFAULT_PRESET_NAME if s['name'].empty?
      s['unit'] = UNIT_TYPES.key?(s['unit'].to_s) ? s['unit'].to_s : d['unit']
      s['show_unit'] = !!s['show_unit']
      s['precision'] = [[s['precision'].to_i, 0].max, 6].min
      s['dim_color'] = normalize_hex(s['dim_color'], d['dim_color'])
      s['note_color'] = normalize_hex(s['note_color'], d['note_color'])
      s['dim_arrow'] = ARROW_TYPES.key?(s['dim_arrow'].to_s) ? s['dim_arrow'].to_s : d['dim_arrow']
      s['note_arrow'] = ARROW_TYPES.key?(s['note_arrow'].to_s) ? s['note_arrow'].to_s : d['note_arrow']
      s['dim_text_mode'] = %w[screen aligned].include?(s['dim_text_mode'].to_s) ? s['dim_text_mode'].to_s : d['dim_text_mode']
      s['dim_text_position'] = %w[start center end].include?(s['dim_text_position'].to_s) ? s['dim_text_position'].to_s : d['dim_text_position']
      s['dim_aligned_position'] = %w[above center outside].include?(s['dim_aligned_position'].to_s) ? s['dim_aligned_position'].to_s : d['dim_aligned_position']
      s['note_display_leader'] = !!s['note_display_leader']
      s['note_leader_type'] = LEADER_TYPES.key?(s['note_leader_type'].to_s) ? s['note_leader_type'].to_s : d['note_leader_type']
      s['note_line_weight'] = [[s['note_line_weight'].to_i, 1].max, 10].min
      s['dim_font_name'] = s['dim_font_name'].to_s.strip.empty? ? d['dim_font_name'] : s['dim_font_name'].to_s.strip
      s['note_font_name'] = s['note_font_name'].to_s.strip.empty? ? d['note_font_name'] : s['note_font_name'].to_s.strip
      s['dim_font_size'] = [[s['dim_font_size'].to_i, 1].max, 1000].min
      s['note_font_size'] = [[s['note_font_size'].to_i, 1].max, 1000].min
      s['dim_font_bold'] = !!s['dim_font_bold']
      s['note_font_bold'] = !!s['note_font_bold']
      s['note_font_italic'] = !!s['note_font_italic']
      s
    end

    def normalize_hex(value, fallback)
      text = value.to_s.strip
      text = "##{text}" unless text.start_with?('#')
      text.match?(/\A#[0-9a-fA-F]{6}\z/) ? text.downcase : fallback
    end

    def color_from_hex(hex)
      s = normalize_hex(hex, '#ffffff').delete_prefix('#')
      Sketchup::Color.new(s[0, 2].to_i(16), s[2, 2].to_i(16), s[4, 2].to_i(16))
    end

    def shared_material(model, prefix, hex)
      name = "#{prefix}_#{normalize_hex(hex, '#ffffff').delete_prefix('#').upcase}"
      mat = model.materials[name] || model.materials.add(name)
      mat.color = color_from_hex(hex)
      mat
    end

    def collect_targets(scope)
      model = Sketchup.active_model
      dims = []
      texts = []
      visited_defs = {}
      entities = scope == 'selection' ? model.selection.to_a : model.entities.to_a
      collect_recursive(entities, dims, texts, visited_defs)
      [dims.uniq, texts.uniq]
    end

    def collect_recursive(entities, dims, texts, visited_defs)
      entities.each do |entity|
        next unless entity && entity.valid?
        if entity.is_a?(Sketchup::DimensionLinear) || entity.is_a?(Sketchup::DimensionRadial)
          dims << entity
        elsif entity.is_a?(Sketchup::Text)
          texts << entity
        elsif entity.is_a?(Sketchup::Group)
          collect_recursive(entity.entities.to_a, dims, texts, visited_defs)
        elsif entity.is_a?(Sketchup::ComponentInstance)
          definition = entity.definition
          next if visited_defs[definition.object_id]
          visited_defs[definition.object_id] = true
          collect_recursive(definition.entities.to_a, dims, texts, visited_defs)
        end
      end
    end

    def apply_units(model, s)
      opts = model.options['UnitsOptions']
      return unless opts
      opts['LengthFormat'] = Length::Decimal if opts.keys.include?('LengthFormat')
      opts['LengthUnit'] = UNIT_TYPES[s['unit']] if opts.keys.include?('LengthUnit')
      opts['LengthPrecision'] = s['precision'] if opts.keys.include?('LengthPrecision')
      opts['SuppressUnitsDisplay'] = !s['show_unit'] if opts.keys.include?('SuppressUnitsDisplay')
    end

    def apply_dimension_style(dim, s, material)
      dim.material = material
      dim.arrow_type = ARROW_TYPES[s['dim_arrow']]
      return unless dim.is_a?(Sketchup::DimensionLinear)

      aligned = s['dim_text_mode'] == 'aligned'
      dim.has_aligned_text = aligned
      dim.text_position = case s['dim_text_position']
                          when 'start' then Sketchup::DimensionLinear::TEXT_OUTSIDE_START
                          when 'end' then Sketchup::DimensionLinear::TEXT_OUTSIDE_END
                          else Sketchup::DimensionLinear::TEXT_CENTERED
                          end
      if aligned
        dim.aligned_text_position = case s['dim_aligned_position']
                                    when 'center' then Sketchup::DimensionLinear::ALIGNED_TEXT_CENTER
                                    when 'outside' then Sketchup::DimensionLinear::ALIGNED_TEXT_OUTSIDE
                                    else Sketchup::DimensionLinear::ALIGNED_TEXT_ABOVE
                                    end
      end
    end

    def note_font_supported?(text = nil)
      return text.respond_to?(:font=) if text
      Sketchup::Text.instance_methods.include?(:font=)
    rescue
      false
    end

    def apply_note_style(text, s, material)
      text.material = material
      text.display_leader = s['note_display_leader']
      if s['note_display_leader']
        text.leader_type = LEADER_TYPES[s['note_leader_type']]
        text.arrow_type = ARROW_TYPES[s['note_arrow']]
        text.line_weight = s['note_line_weight']
      end
      if text.respond_to?(:font=)
        text.font = {
          name: s['note_font_name'],
          size: s['note_font_size'],
          bold: s['note_font_bold'],
          italic: s['note_font_italic']
        }
      end
    end

    def apply_style(settings, scope = 'all')
      model = Sketchup.active_model
      s = normalize_settings(settings)
      dims, texts = collect_targets(scope)
      model.start_operation('VADA - Áp Style Dim & Ghi chú', true)
      apply_units(model, s)
      dim_mat = shared_material(model, 'VADA_DIM', s['dim_color'])
      note_mat = shared_material(model, 'VADA_NOTE', s['note_color'])
      dims.each { |d| apply_dimension_style(d, s, dim_mat) }
      texts.each { |t| apply_note_style(t, s, note_mat) }
      model.commit_operation
      model.active_view.invalidate
      Sketchup.write_default(PREF_KEY, 'active_preset', s['name'])
      {
        ok: true,
        dimensions: dims.length,
        notes: texts.length,
        note_font_applied: texts.any? { |t| t.respond_to?(:font=) },
        dimension_font_applied: false,
        message: scope == 'selection' ? 'Đã áp cho vùng đang chọn.' : 'Đã áp cho toàn bộ model.'
      }
    rescue => e
      model.abort_operation rescue nil
      { ok: false, message: "#{e.class}: #{e.message}" }
    end

    def current_model_info
      model = Sketchup.active_model
      opts = model.options['UnitsOptions']
      unit_map = UNIT_TYPES.invert
      unit = unit_map[opts['LengthUnit']] || 'cm'
      {
        version: VERSION,
        sketchup_version: Sketchup.version.to_s,
        unit: unit,
        show_unit: !opts['SuppressUnitsDisplay'],
        precision: opts['LengthPrecision'].to_i,
        presets: presets,
        active_preset: active_preset_name,
        note_font_api: note_font_supported?,
        dimension_font_api: false
      }
    rescue
      {
        version: VERSION,
        sketchup_version: Sketchup.version.to_s,
        unit: 'cm', show_unit: true, precision: 1,
        presets: presets, active_preset: active_preset_name,
        note_font_api: false, dimension_font_api: false
      }
    end

    def show_model_info_page(kind)
      pages = UI.model_info_pages
      candidates = kind == 'dimension' ? ['Dimensions', 'Dimension', 'Kích thước'] : ['Text', 'Văn bản', 'Ghi chú']
      page = pages.find do |p|
        candidates.any? { |c| p.to_s.downcase.include?(c.downcase) }
      end
      page ||= kind == 'dimension' ? 'Dimensions' : 'Text'
      UI.show_model_info(page)
    rescue
      UI.messagebox('Không mở được trang Model Info trên phiên bản SketchUp này.')
    end

    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        return
      end

      @dialog = UI::HtmlDialog.new(
        dialog_title: "Quản lý Style Dim & Ghi chú - v#{VERSION}",
        preferences_key: 'VADAStyleDimNotesDialog',
        scrollable: true,
        resizable: true,
        width: 720,
        height: 760,
        min_width: 620,
        min_height: 620,
        style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dialog.set_file(File.join(__dir__, 'ui.html'))

      @dialog.add_action_callback('ready') do |_ctx|
        push_state
      end

      @dialog.add_action_callback('apply_style') do |_ctx, payload|
        data = JSON.parse(payload.to_s)
        result = apply_style(data['settings'] || {}, data['scope'] || 'all')
        @dialog.execute_script("window.VADA.onApplyResult(#{JSON.generate(result)});") if @dialog
      end

      @dialog.add_action_callback('save_preset') do |_ctx, payload|
        preset = save_preset(JSON.parse(payload.to_s))
        @dialog.execute_script("window.VADA.onPresetSaved(#{JSON.generate({preset: preset, presets: presets})});") if @dialog
      end

      @dialog.add_action_callback('delete_preset') do |_ctx, name|
        list = delete_preset(name.to_s)
        @dialog.execute_script("window.VADA.onPresetDeleted(#{JSON.generate({presets: list, active_preset: active_preset_name})});") if @dialog
      end

      @dialog.add_action_callback('open_native') do |_ctx, kind|
        show_model_info_page(kind.to_s)
      end

      @dialog.set_on_closed { @dialog = nil }
      @dialog.show
    end

    def push_state
      return unless @dialog
      @dialog.execute_script("window.VADA.init(#{JSON.generate(current_model_info)});")
    end

    def build_ui
      return if @ui_built
      @ui_built = true

      command = UI::Command.new('Quản lý Style Dim & Ghi chú') { show_dialog }
      command.tooltip = 'Quản lý Style Dim & Ghi chú'
      command.status_bar_text = 'Lưu preset và áp nhanh style Dim/Ghi chú cho mọi file SketchUp.'
      icon_small = File.join(__dir__, 'icon_16.png')
      icon_large = File.join(__dir__, 'icon_24.png')
      command.small_icon = icon_small if File.exist?(icon_small)
      command.large_icon = icon_large if File.exist?(icon_large)

      toolbar = UI::Toolbar.new('VADA - Style Dim & Ghi chú')
      toolbar.add_item(command)
      toolbar.show
      @toolbar = toolbar

      UI.menu('Extensions').add_item(command)
    end

    build_ui
  end
end
