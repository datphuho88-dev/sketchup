# VADA - Thống kê sắt hộp v1.1.1

Plugin SketchUp giúp thống kê sắt hộp theo **tiết diện** và **chiều dài**, đồng thời **tô màu phân biệt trực tiếp trên model 3D** để nhìn nhanh cây nào thuộc loại hộp nào.

## Tính năng

- Quét trong **vùng chọn** hoặc **toàn bộ ngữ cảnh đang mở**.
- Nhận dạng mỗi thanh sắt khi thanh đó là **1 Group** hoặc **1 Component riêng**.
- Thống kê:
  - tổng số đoạn
  - tổng chiều dài
  - số loại tiết diện
  - số lượng theo từng chiều dài cắt
  - tối thiểu số cây nguyên liệu
- **Tô màu 3D theo từng tiết diện**:
  - mỗi loại hộp có một màu riêng
  - màu hiển thị trong bảng trùng với màu tô trong model
  - có thể **xóa tô màu** để trả model về trạng thái ban đầu
- Xuất CSV.

## Lưu ý

- Nếu có **Edge/Face rời** không nằm trong Group/Component thì plugin sẽ bỏ qua để tránh cộng sai.
- Tô màu chính xác và dễ quản lý nhất khi mô hình được tách thanh rõ ràng.
- Thanh đang **khóa (Locked)** sẽ không bị plugin đổi màu.

## Sửa lỗi v1.1.1

- Tô màu trực tiếp cả các Face bên trong thanh, nên các thanh có vật liệu/texture cũ không còn bị sót màu.
- Lưu và khôi phục vật liệu mặt trước/mặt sau khi bấm **Xóa tô màu**.
- Hiển thị số thanh đã tô và số mặt đã xử lý để dễ kiểm tra.
