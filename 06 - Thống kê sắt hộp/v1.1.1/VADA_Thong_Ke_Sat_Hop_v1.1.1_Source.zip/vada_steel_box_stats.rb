# frozen_string_literal: true

require 'sketchup.rb'
require 'extensions.rb'

module VADA
  module SteelBoxStats
    EXTENSION_NAME = 'VADA - Thống kê sắt hộp'
    VERSION = '1.1.1'

    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new(EXTENSION_NAME, 'vada_steel_box_stats/main')
      extension.description = 'Thống kê số lượng, tiết diện, chiều dài, tổng mét và tô màu phân biệt sắt hộp theo tiết diện.'
      extension.version = VERSION
      extension.creator = 'Công ty TNHH VADA'
      extension.copyright = '2026 Công ty TNHH VADA'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
