# frozen_string_literal: true

require 'sketchup.rb'
require 'json'
require 'csv'

module VADA
  module SteelBoxStats
    extend self

    VERSION = '1.1.1' unless const_defined?(:VERSION)
    TITLE = 'Thống kê sắt hộp'
    PREF_KEY = 'VADA_SteelBoxStats'
    MATERIAL_PREFIX = 'VADA_SAT_HOP__'

    DEFAULTS = {
      'length_round_mm' => 1.0,
      'profile_round_mm' => 1.0,
      'min_ratio' => 2.5,
      'stock_length_mm' => 6000.0
    }.freeze

    HIGHLIGHT_PALETTE = [
      [255, 99, 71],
      [52, 152, 219],
      [46, 204, 113],
      [241, 196, 15],
      [155, 89, 182],
      [26, 188, 156],
      [230, 126, 34],
      [236, 112, 99],
      [127, 140, 141],
      [243, 156, 18],
      [93, 173, 226],
      [88, 214, 141]
    ].freeze

    def show_dialog
      @dialog ||= build_dialog
      @dialog.show
      scan_and_render
    end

    def build_dialog
      dialog = UI::HtmlDialog.new(
        dialog_title: "#{TITLE} • v#{VERSION}",
        preferences_key: PREF_KEY,
        scrollable: true,
        resizable: true,
        width: 900,
        height: 700,
        min_width: 760,
        min_height: 520,
        style: UI::HtmlDialog::STYLE_DIALOG
      )
      dialog.set_html(html)

      dialog.add_action_callback('scan') do |_ctx, payload|
        begin
          settings = payload.to_s.empty? ? DEFAULTS.dup : DEFAULTS.merge(JSON.parse(payload.to_s))
          save_settings(settings)
          scan_and_render(settings)
        rescue => e
          render_error("Lỗi khi thống kê: #{e.message}")
        end
      end

      dialog.add_action_callback('paint_members') do |_ctx|
        apply_highlight
      end

      dialog.add_action_callback('clear_marks') do |_ctx|
        clear_highlight
      end

      dialog.add_action_callback('export_csv') do |_ctx|
        export_csv
      end

      dialog.add_action_callback('close_dialog') do |_ctx|
        dialog.close
      end

      dialog.set_on_closed { @dialog = nil }
      dialog
    end

    def current_settings
      DEFAULTS.each_with_object({}) do |(key, default), out|
        out[key] = Sketchup.read_default(PREF_KEY, key, default).to_f
      end
    end

    def save_settings(settings)
      DEFAULTS.each_key do |key|
        next unless settings.key?(key)
        Sketchup.write_default(PREF_KEY, key, settings[key].to_f)
      end
    end

    def scan_and_render(settings = nil)
      settings ||= current_settings
      report = build_report(settings)
      @last_report = report
      @last_settings = settings
      return unless @dialog

      @dialog.execute_script("setSettings(#{JSON.generate(settings)}); renderReport(#{JSON.generate(report)});")
    rescue => e
      render_error("Lỗi khi thống kê: #{e.message}")
    end

    def build_report(settings)
      model = Sketchup.active_model
      selection = model.selection
      selected = !selection.empty?
      roots = selected ? selection.to_a : model.active_entities.to_a

      rows = []
      raw_geometry_warnings = []
      identity = Geom::Transformation.new
      scan_entities(roots, identity, rows, settings, raw_geometry_warnings)
      @last_rows = rows

      grouped = {}
      rows.each do |row|
        profile_key = [row[:a_mm], row[:b_mm]]
        grouped[profile_key] ||= {
          profile_a_mm: row[:a_mm],
          profile_b_mm: row[:b_mm],
          count: 0,
          total_mm: 0.0,
          lengths: Hash.new(0)
        }
        g = grouped[profile_key]
        g[:count] += 1
        g[:total_mm] += row[:length_mm]
        g[:lengths][row[:length_mm]] += 1
      end

      color_map = {}
      grouped_values = grouped.values.sort_by { |g| [g[:profile_a_mm], g[:profile_b_mm]] }
      profiles = grouped_values.each_with_index.map do |g, index|
        stock = settings['stock_length_mm'].to_f
        minimum_stock = stock > 0 ? (g[:total_mm] / stock).ceil : 0
        key = [g[:profile_a_mm], g[:profile_b_mm]]
        rgb = palette_color(index)
        color_map[key] = rgb
        {
          profile: profile_text(g[:profile_a_mm], g[:profile_b_mm]),
          profile_a_mm: g[:profile_a_mm],
          profile_b_mm: g[:profile_b_mm],
          count: g[:count],
          total_m: (g[:total_mm] / 1000.0).round(3),
          min_stock_6m: minimum_stock,
          color_hex: rgb_to_hex(rgb),
          lengths: g[:lengths].sort_by { |length_mm, _| -length_mm }.map do |length_mm, qty|
            {
              length_mm: length_mm,
              length_text: length_text(length_mm),
              qty: qty,
              subtotal_m: (length_mm * qty / 1000.0).round(3)
            }
          end
        }
      end
      @last_profile_colors = color_map

      total_mm = rows.sum { |r| r[:length_mm] }
      highlighted_count = unique_valid_rows(rows).count { |r| highlighted_entity?(r[:entity]) }
      {
        version: VERSION,
        scope: selected ? 'Vùng đang chọn' : 'Toàn bộ ngữ cảnh đang mở',
        total_members: rows.length,
        total_length_m: (total_mm / 1000.0).round(3),
        profile_count: profiles.length,
        highlighted_count: highlighted_count,
        highlight_status: rows.empty? ? '—' : (highlighted_count > 0 ? "#{highlighted_count} thanh" : 'Chưa tô'),
        profiles: profiles,
        warnings: raw_geometry_warnings.uniq.take(8),
        empty_message: rows.empty? ? empty_help : nil
      }
    end

    def scan_entities(entities, parent_tr, rows, settings, warnings)
      entities.each do |entity|
        next unless entity.valid?

        case entity
        when Sketchup::Group, Sketchup::ComponentInstance
          tr = parent_tr * entity.transformation
          if member_candidate?(entity, tr, settings)
            measured = measure_member(entity, tr, settings)
            rows << measured if measured
          else
            child_entities = child_entities_for(entity)
            if child_entities
              scan_entities(child_entities.to_a, tr, rows, settings, warnings)
            end
          end
        end
      end

      if entities.any? { |e| e.is_a?(Sketchup::Edge) || e.is_a?(Sketchup::Face) }
        warnings << 'Có hình học rời (Edge/Face) không nằm trong Group/Component; phần đó không được tính để tránh cộng sai.'
      end
    end

    def child_entities_for(entity)
      if entity.is_a?(Sketchup::Group)
        entity.entities
      elsif entity.is_a?(Sketchup::ComponentInstance)
        entity.definition.entities
      end
    end

    def direct_geometry?(entity)
      ents = child_entities_for(entity)
      return false unless ents
      ents.any? { |e| e.is_a?(Sketchup::Face) || e.is_a?(Sketchup::Edge) }
    end

    def member_candidate?(entity, tr, settings)
      return false unless direct_geometry?(entity)
      dims = scaled_dimensions_mm(entity, tr)
      return false unless dims && dims.all? { |d| d > 0.01 }

      sorted = dims.sort
      ratio = sorted[2] / [sorted[1], 0.001].max
      ratio >= settings['min_ratio'].to_f
    end

    def measure_member(entity, tr, settings)
      dims = scaled_dimensions_mm(entity, tr)
      return nil unless dims
      sorted = dims.sort

      profile_step = [settings['profile_round_mm'].to_f, 0.1].max
      length_step = [settings['length_round_mm'].to_f, 0.1].max
      a = round_to(sorted[0], profile_step)
      b = round_to(sorted[1], profile_step)
      length = round_to(sorted[2], length_step)
      return nil if length <= 0 || a <= 0 || b <= 0

      {
        a_mm: [a, b].min,
        b_mm: [a, b].max,
        length_mm: length,
        name: entity_name(entity),
        entity: entity
      }
    end

    def scaled_dimensions_mm(entity, tr)
      bb = local_bounds(entity)
      return nil unless bb && bb.valid?

      sx = tr.xaxis.length
      sy = tr.yaxis.length
      sz = tr.zaxis.length
      [bb.width.to_mm * sx, bb.height.to_mm * sy, bb.depth.to_mm * sz]
    end

    def local_bounds(entity)
      if entity.is_a?(Sketchup::ComponentInstance)
        entity.definition.bounds
      elsif entity.is_a?(Sketchup::Group)
        return entity.local_bounds if entity.respond_to?(:local_bounds)
        bounds_from_entities(entity.entities)
      end
    end

    def bounds_from_entities(entities)
      bb = Geom::BoundingBox.new
      entities.each do |e|
        case e
        when Sketchup::Vertex
          bb.add(e.position)
        when Sketchup::Edge
          bb.add(e.start.position)
          bb.add(e.end.position)
        when Sketchup::Face
          e.vertices.each { |v| bb.add(v.position) }
        end
      end
      bb
    end

    def entity_name(entity)
      name = entity.name.to_s.strip if entity.respond_to?(:name)
      if (name.nil? || name.empty?) && entity.is_a?(Sketchup::ComponentInstance)
        name = entity.definition.name.to_s.strip
      end
      name.to_s
    end

    def apply_highlight
      unless @last_rows && !@last_rows.empty?
        UI.messagebox('Chưa có dữ liệu để tô màu. Bấm Quét lại trước.')
        return
      end

      rows = unique_valid_rows(@last_rows)
      model = Sketchup.active_model
      colored = 0
      skipped_locked = 0
      failed = []
      painted_faces = 0
      seen_definitions = {}

      model.start_operation('Tô màu sắt hộp', true)
      begin
        rows.each do |row|
          entity = row[:entity]
          next unless entity&.valid?

          if entity.respond_to?(:locked?) && entity.locked?
            skipped_locked += 1
            next
          end

          rgb = @last_profile_colors[[row[:a_mm], row[:b_mm]]]
          next unless rgb

          material = ensure_highlight_material(row[:a_mm], row[:b_mm], rgb)
          begin
            # Tô cả instance/group lẫn toàn bộ Face thật bên trong.
            # Cách này xử lý được trường hợp Face đã có vật liệu riêng,
            # vốn không bị ghi đè khi chỉ gán material cho Group/Component.
            painted_faces += paint_member_geometry(entity, material, seen_definitions)
            entity.set_attribute(PREF_KEY, 'highlighted', true)
            colored += 1
          rescue => e
            failed << "#{row[:name].to_s.empty? ? entity_identity(entity) : row[:name]}: #{e.message}"
          end
        end
        model.commit_operation
      rescue => e
        model.abort_operation
        UI.messagebox("Không tô màu được:\n#{e.message}")
        return
      end

      scan_and_render(@last_settings || current_settings)
      msg = "Đã tô màu #{colored}/#{rows.length} thanh theo tiết diện.\nĐã tô trực tiếp #{painted_faces} mặt để không bị sót thanh có vật liệu cũ."
      msg += "\nBỏ qua #{skipped_locked} thanh đang khóa." if skipped_locked > 0
      msg += "\nCó #{failed.length} thanh lỗi khi tô." if failed.any?
      UI.messagebox(msg)
    end

    def clear_highlight
      model = Sketchup.active_model
      marked = []
      seen = {}
      collect_marked_entities(model.active_entities.to_a, marked, seen)

      if marked.empty?
        UI.messagebox('Không có thanh nào đang được tô màu bởi plugin.')
        return
      end

      restored = 0
      restored_faces = 0
      seen_definitions = {}
      model.start_operation('Xóa tô màu sắt hộp', true)
      begin
        marked.each do |entity|
          next unless entity&.valid?
          restored_faces += restore_member_geometry(entity, seen_definitions)
          entity.delete_attribute(PREF_KEY, 'highlighted')
          restored += 1
        end
        model.commit_operation
      rescue => e
        model.abort_operation
        UI.messagebox("Không xóa tô màu được:\n#{e.message}")
        return
      end

      scan_and_render(@last_settings || current_settings)
      UI.messagebox("Đã khôi phục màu cho #{restored} thanh và #{restored_faces} mặt.")
    end

    def paint_member_geometry(entity, material, seen_definitions)
      face_count = 0
      remember_original_material(entity)
      entity.material = material if entity.respond_to?(:material=)

      ents = child_entities_for(entity)
      return face_count unless ents

      definition_key = if entity.is_a?(Sketchup::ComponentInstance)
                         entity.definition.object_id
                       else
                         nil
                       end
      skip_definition_faces = definition_key && seen_definitions[definition_key]
      seen_definitions[definition_key] = true if definition_key

      unless skip_definition_faces
        ents.each do |child|
          next unless child.valid?
          case child
          when Sketchup::Face
            remember_original_face_materials(child)
            child.material = material
            child.back_material = material
            face_count += 1
          when Sketchup::Group, Sketchup::ComponentInstance
            face_count += paint_member_geometry(child, material, seen_definitions)
          end
        end
      end
      face_count
    end

    def restore_member_geometry(entity, seen_definitions)
      face_count = 0
      restore_original_material(entity)

      ents = child_entities_for(entity)
      return face_count unless ents

      definition_key = if entity.is_a?(Sketchup::ComponentInstance)
                         entity.definition.object_id
                       else
                         nil
                       end
      skip_definition_faces = definition_key && seen_definitions[definition_key]
      seen_definitions[definition_key] = true if definition_key

      unless skip_definition_faces
        ents.each do |child|
          next unless child.valid?
          case child
          when Sketchup::Face
            if face_material_saved?(child)
              restore_original_face_materials(child)
              face_count += 1
            end
          when Sketchup::Group, Sketchup::ComponentInstance
            face_count += restore_member_geometry(child, seen_definitions)
          end
        end
      end
      face_count
    end

    def remember_original_face_materials(face)
      return if face.get_attribute(PREF_KEY, 'face_material_saved', false)

      face.set_attribute(PREF_KEY, 'face_material_saved', true)
      save_material_snapshot(face, face.material, 'face_front')
      save_material_snapshot(face, face.back_material, 'face_back')
    end

    def face_material_saved?(face)
      face.get_attribute(PREF_KEY, 'face_material_saved', false)
    end

    def restore_original_face_materials(face)
      face.material = material_from_snapshot(face, 'face_front')
      face.back_material = material_from_snapshot(face, 'face_back')
      %w[
        face_material_saved
        face_front_nil face_front_name face_front_color
        face_back_nil face_back_name face_back_color
      ].each { |key| face.delete_attribute(PREF_KEY, key) }
    end

    def save_material_snapshot(owner, material, prefix)
      if material.nil?
        owner.set_attribute(PREF_KEY, "#{prefix}_nil", true)
      else
        owner.set_attribute(PREF_KEY, "#{prefix}_nil", false)
        owner.set_attribute(PREF_KEY, "#{prefix}_name", material.name.to_s)
        color = material.color
        if color
          rgba = [color.red, color.green, color.blue, color.alpha]
          owner.set_attribute(PREF_KEY, "#{prefix}_color", JSON.generate(rgba))
        end
      end
    end

    def material_from_snapshot(owner, prefix)
      return nil if owner.get_attribute(PREF_KEY, "#{prefix}_nil", true)

      material_name = owner.get_attribute(PREF_KEY, "#{prefix}_name", '').to_s
      material = material_name.empty? ? nil : Sketchup.active_model.materials[material_name]
      return material if material

      rgba_json = owner.get_attribute(PREF_KEY, "#{prefix}_color", nil)
      rgba = rgba_json ? (JSON.parse(rgba_json) rescue nil) : nil
      return nil unless rgba && rgba.length >= 3

      generated_name = "VADA_KhoiPhuc_#{prefix}_#{owner.object_id}"
      restored = Sketchup.active_model.materials[generated_name] || Sketchup.active_model.materials.add(generated_name)
      restored.color = Sketchup::Color.new(rgba[0], rgba[1], rgba[2], rgba[3] || 255)
      restored
    end

    def collect_marked_entities(entities, out, seen)
      entities.each do |entity|
        next unless entity.valid?
        case entity
        when Sketchup::Group, Sketchup::ComponentInstance
          id = entity_identity(entity)
          next if seen[id]
          seen[id] = true
          out << entity if highlighted_entity?(entity)
          child_entities = child_entities_for(entity)
          collect_marked_entities(child_entities.to_a, out, seen) if child_entities
        end
      end
    end

    def unique_valid_rows(rows)
      seen = {}
      rows.each_with_object([]) do |row, arr|
        entity = row[:entity]
        next unless entity&.valid?
        id = entity_identity(entity)
        next if seen[id]
        seen[id] = true
        arr << row
      end
    end

    def entity_identity(entity)
      entity.respond_to?(:persistent_id) ? entity.persistent_id : entity.object_id
    rescue
      entity.object_id
    end

    def highlighted_entity?(entity)
      entity && entity.valid? && entity.get_attribute(PREF_KEY, 'highlighted', false)
    end

    def remember_original_material(entity)
      return if entity.get_attribute(PREF_KEY, 'orig_material_saved', false)

      entity.set_attribute(PREF_KEY, 'orig_material_saved', true)
      material = entity.material
      if material.nil?
        entity.set_attribute(PREF_KEY, 'orig_material_nil', true)
      else
        entity.set_attribute(PREF_KEY, 'orig_material_nil', false)
        entity.set_attribute(PREF_KEY, 'orig_material_name', material.name.to_s)
        color = material.color
        if color
          rgba = [color.red, color.green, color.blue, color.alpha]
          entity.set_attribute(PREF_KEY, 'orig_material_color', JSON.generate(rgba))
        end
      end
    end

    def restore_original_material(entity)
      nil_original = entity.get_attribute(PREF_KEY, 'orig_material_nil', true)
      if nil_original
        entity.material = nil
      else
        material_name = entity.get_attribute(PREF_KEY, 'orig_material_name', '').to_s
        material = material_name.empty? ? nil : Sketchup.active_model.materials[material_name]
        if material.nil?
          rgba_json = entity.get_attribute(PREF_KEY, 'orig_material_color', nil)
          rgba = rgba_json ? (JSON.parse(rgba_json) rescue nil) : nil
          if rgba && rgba.length >= 3
            material = Sketchup.active_model.materials.add("VADA_KhoiPhuc_#{entity_identity(entity)}")
            material.color = Sketchup::Color.new(rgba[0], rgba[1], rgba[2], rgba[3] || 255)
          end
        end
        entity.material = material
      end

      %w[
        highlighted
        orig_material_saved
        orig_material_nil
        orig_material_name
        orig_material_color
      ].each do |key|
        entity.delete_attribute(PREF_KEY, key)
      end
    end

    def ensure_highlight_material(a_mm, b_mm, rgb)
      model = Sketchup.active_model
      name = "#{MATERIAL_PREFIX}#{material_token(a_mm)}x#{material_token(b_mm)}"
      material = model.materials[name] || model.materials.add(name)
      material.color = Sketchup::Color.new(rgb[0], rgb[1], rgb[2])
      material
    end

    def material_token(value)
      clean_number(value, 2).gsub('.', '_')
    end

    def palette_color(index)
      HIGHLIGHT_PALETTE[index % HIGHLIGHT_PALETTE.length]
    end

    def rgb_to_hex(rgb)
      format('#%02X%02X%02X', rgb[0], rgb[1], rgb[2])
    end

    def round_to(value, step)
      return value if step <= 0
      (value / step).round * step
    end

    def clean_number(value, digits = 1)
      rounded = value.round(digits)
      ((rounded - rounded.round).abs < 1e-9) ? rounded.round.to_s : rounded.to_s
    end

    def profile_text(a_mm, b_mm)
      "#{clean_number(a_mm / 10.0)} × #{clean_number(b_mm / 10.0)} cm"
    end

    def length_text(mm)
      cm = mm / 10.0
      if cm >= 100.0
        "#{clean_number(cm / 100.0, 3)} m"
      else
        "#{clean_number(cm, 2)} cm"
      end
    end

    def empty_help
      'Không tìm thấy thanh sắt hợp lệ. Mỗi thanh nên là một Group hoặc Component riêng và có dạng dài hơn tiết diện.'
    end

    def render_error(message)
      return unless @dialog
      @dialog.execute_script("renderError(#{JSON.generate(message)});")
    end

    def export_csv
      unless @last_report && @last_report[:profiles] && !@last_report[:profiles].empty?
        UI.messagebox('Chưa có dữ liệu để xuất CSV.')
        return
      end

      model = Sketchup.active_model
      base = model.title.to_s.strip
      base = 'Thong_ke_sat_hop' if base.empty?
      path = UI.savepanel('Xuất thống kê sắt hộp CSV', nil, "#{base}_sat_hop.csv")
      return unless path

      CSV.open(path, 'wb') do |csv|
        csv << ["\uFEFFTiết diện", 'Chiều dài', 'Số lượng đoạn', 'Tổng chiều dài (m)', 'Tối thiểu cây nguyên liệu']
        @last_report[:profiles].each do |profile|
          profile[:lengths].each_with_index do |item, index|
            csv << [
              profile[:profile],
              item[:length_text],
              item[:qty],
              item[:subtotal_m],
              index.zero? ? profile[:min_stock_6m] : ''
            ]
          end
        end
      end
      UI.messagebox("Đã xuất:\n#{path}")
    rescue => e
      UI.messagebox("Không xuất được CSV:\n#{e.message}")
    end

    def html
      <<~HTML
        <!doctype html>
        <html lang="vi">
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width,initial-scale=1">
          <style>
            :root { --bg:#000; --panel:#111; --panel2:#181818; --line:#303030; --text:#f3f3f3; --muted:#a8a8a8; --red:#ff3b30; --green:#4bd37b; }
            * { box-sizing:border-box; }
            body { margin:0; background:var(--bg); color:var(--text); font-family:Segoe UI,Arial,sans-serif; font-size:13px; }
            .top { position:sticky; top:0; z-index:5; background:#050505; border-bottom:1px solid var(--line); padding:14px 16px 10px; }
            .title-row { display:flex; justify-content:space-between; align-items:center; gap:12px; }
            h1 { font-size:18px; margin:0; font-weight:700; }
            .version { color:var(--red); font-weight:700; border:1px solid #5a1613; background:#1b0908; border-radius:7px; padding:4px 8px; }
            .sub { color:var(--muted); margin-top:4px; }
            .controls { display:grid; grid-template-columns:repeat(4,minmax(120px,1fr)); gap:8px; margin-top:12px; }
            label { color:#bbb; font-size:11px; display:block; margin:0 0 4px; }
            input { width:100%; background:#0b0b0b; color:#fff; border:1px solid #444; border-radius:7px; padding:8px 9px; outline:none; }
            input:focus { border-color:var(--red); }
            .actions { display:flex; gap:8px; margin-top:10px; flex-wrap:wrap; }
            button { border:1px solid #444; background:#171717; color:#fff; border-radius:8px; padding:8px 12px; cursor:pointer; font-weight:600; }
            button.primary { background:var(--red); border-color:var(--red); color:#fff; }
            button.secondary { border-color:#2f6a49; background:#0d2116; color:#dff8e8; }
            button.warn { border-color:#6c5010; background:#221805; color:#ffe8a6; }
            button:hover { filter:brightness(1.13); }
            main { padding:14px 16px 24px; }
            .summary { display:grid; grid-template-columns:repeat(4,1fr); gap:8px; margin-bottom:12px; }
            .card { background:var(--panel); border:1px solid var(--line); border-radius:10px; padding:11px; }
            .card .k { color:var(--muted); font-size:11px; }
            .card .v { margin-top:3px; font-size:20px; font-weight:700; }
            .card .v.small { font-size:16px; }
            .card .v.ok { color:var(--green); }
            .scope { margin-bottom:10px; color:#bbb; }
            .profile { border:1px solid var(--line); border-radius:10px; overflow:hidden; margin-bottom:10px; background:var(--panel); }
            .profile-head { display:grid; grid-template-columns:1.5fr .7fr .9fr .9fr; gap:8px; align-items:center; padding:10px 12px; background:var(--panel2); border-bottom:1px solid var(--line); }
            .profile-name { font-size:16px; font-weight:800; color:#fff; display:flex; align-items:center; gap:10px; }
            .swatch { width:18px; height:18px; border-radius:5px; border:1px solid rgba(255,255,255,.3); display:inline-block; flex:0 0 auto; }
            .metric { text-align:right; }
            .metric small { display:block; color:var(--muted); font-size:10px; }
            table { width:100%; border-collapse:collapse; }
            th,td { padding:8px 12px; border-bottom:1px solid #222; text-align:right; }
            th:first-child,td:first-child { text-align:left; }
            th { color:#aaa; font-size:11px; font-weight:600; }
            tr:last-child td { border-bottom:0; }
            .qty { color:var(--red); font-weight:800; }
            .warn { border:1px solid #5b4511; background:#1d1604; color:#ffd66b; border-radius:9px; padding:10px 12px; margin:10px 0; }
            .empty { border:1px dashed #444; color:#bbb; border-radius:10px; padding:20px; text-align:center; }
            .error { border:1px solid #741f1a; background:#240807; color:#ff8e88; border-radius:9px; padding:12px; }
            .footnote { color:#7f7f7f; font-size:11px; margin-top:12px; line-height:1.45; }
            @media(max-width:860px){ .controls{grid-template-columns:repeat(2,1fr)} .summary{grid-template-columns:repeat(2,1fr)} .profile-head{grid-template-columns:1fr 1fr} }
          </style>
        </head>
        <body>
          <div class="top">
            <div class="title-row">
              <div><h1>THỐNG KÊ SẮT HỘP</h1><div class="sub">Chọn khung cần tính rồi bấm Quét. Không chọn gì = quét toàn ngữ cảnh đang mở.</div></div>
              <div class="version">v#{VERSION}</div>
            </div>
            <div class="controls">
              <div><label>Làm tròn chiều dài (mm)</label><input id="lengthRound" type="number" min="0.1" step="0.1" value="1"></div>
              <div><label>Làm tròn tiết diện (mm)</label><input id="profileRound" type="number" min="0.1" step="0.1" value="1"></div>
              <div><label>Tỷ lệ dài / tiết diện tối thiểu</label><input id="minRatio" type="number" min="1" step="0.1" value="2.5"></div>
              <div><label>Chiều dài cây nguyên liệu (mm)</label><input id="stockLength" type="number" min="1" step="100" value="6000"></div>
            </div>
            <div class="actions">
              <button class="primary" onclick="scan()">QUÉT LẠI</button>
              <button class="secondary" onclick="sketchup.paint_members()">Tô màu 3D</button>
              <button class="warn" onclick="sketchup.clear_marks()">Xóa tô màu</button>
              <button onclick="sketchup.export_csv()">Xuất CSV</button>
              <button onclick="sketchup.close_dialog()">Đóng</button>
            </div>
          </div>
          <main id="app"><div class="empty">Đang đọc mô hình…</div></main>
          <script>
            function n(id){ return Number(document.getElementById(id).value || 0); }
            function scan(){
              const s={length_round_mm:n('lengthRound'),profile_round_mm:n('profileRound'),min_ratio:n('minRatio'),stock_length_mm:n('stockLength')};
              sketchup.scan(JSON.stringify(s));
            }
            function setSettings(s){
              document.getElementById('lengthRound').value=s.length_round_mm;
              document.getElementById('profileRound').value=s.profile_round_mm;
              document.getElementById('minRatio').value=s.min_ratio;
              document.getElementById('stockLength').value=s.stock_length_mm;
            }
            function esc(v){ return String(v).replace(/[&<>\"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[m])); }
            function renderReport(r){
              const markClass = r.highlighted_count > 0 ? 'v small ok' : 'v small';
              let h=`<div class="scope">Phạm vi: <b>${esc(r.scope)}</b></div>`;
              h+=`<div class="summary">
                <div class="card"><div class="k">TỔNG SỐ ĐOẠN</div><div class="v">${r.total_members}</div></div>
                <div class="card"><div class="k">TỔNG CHIỀU DÀI</div><div class="v">${r.total_length_m} m</div></div>
                <div class="card"><div class="k">SỐ LOẠI TIẾT DIỆN</div><div class="v">${r.profile_count}</div></div>
                <div class="card"><div class="k">ĐÁNH DẤU 3D</div><div class="${markClass}">${esc(r.highlight_status)}</div></div>
              </div>`;
              if(r.warnings && r.warnings.length){ h+=r.warnings.map(w=>`<div class="warn">⚠ ${esc(w)}</div>`).join(''); }
              if(!r.profiles.length){ h+=`<div class="empty">${esc(r.empty_message||'Không có dữ liệu.')}</div>`; document.getElementById('app').innerHTML=h; return; }
              for(const p of r.profiles){
                h+=`<section class="profile"><div class="profile-head">
                  <div class="profile-name"><span class="swatch" style="background:${esc(p.color_hex)}"></span>Hộp ${esc(p.profile)}</div>
                  <div class="metric"><small>Số đoạn</small><b>${p.count}</b></div>
                  <div class="metric"><small>Tổng dài</small><b>${p.total_m} m</b></div>
                  <div class="metric"><small>Tối thiểu cây nguyên liệu</small><b>${p.min_stock_6m}</b></div>
                </div><table><thead><tr><th>Chiều dài cắt</th><th>Số lượng</th><th>Thành tiền chiều dài</th></tr></thead><tbody>`;
                for(const x of p.lengths){ h+=`<tr><td><b>${esc(x.length_text)}</b></td><td class="qty">${x.qty}</td><td>${x.subtotal_m} m</td></tr>`; }
                h+=`</tbody></table></section>`;
              }
              h+=`<div class="footnote">Màu trên bảng khớp với màu tô trong model. Plugin chỉ tính chính xác khi mỗi thanh sắt là một Group hoặc Component riêng. “Tối thiểu cây nguyên liệu” = tổng chiều dài / chiều dài cây nguyên liệu và làm tròn lên; chưa tối ưu sơ đồ cắt và chưa tính hao hụt.</div>`;
              document.getElementById('app').innerHTML=h;
            }
            function renderError(msg){ document.getElementById('app').innerHTML=`<div class="error">${esc(msg)}</div>`; }
          </script>
        </body>
        </html>
      HTML
    end

    unless file_loaded?(__FILE__)
      root = File.dirname(__FILE__)
      icon24 = File.join(root, 'icon_24.png')
      icon32 = File.join(root, 'icon_32.png')

      cmd = UI::Command.new(TITLE) { show_dialog }
      cmd.tooltip = 'Thống kê sắt hộp theo tiết diện và chiều dài'
      cmd.status_bar_text = 'Chọn khung hoặc các thanh, sau đó thống kê số lượng, tổng chiều dài và tô màu phân biệt theo tiết diện.'
      cmd.small_icon = icon24 if File.exist?(icon24)
      cmd.large_icon = icon32 if File.exist?(icon32)

      UI.menu('Extensions').add_item(cmd)
      toolbar = UI::Toolbar.new('VADA - Sắt hộp')
      toolbar.add_item(cmd)
      toolbar.restore

      file_loaded(__FILE__)
    end
  end
end
