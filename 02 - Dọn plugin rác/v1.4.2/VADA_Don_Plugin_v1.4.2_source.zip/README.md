# Dọn Plugin VADA v1.4.2

Bản sửa lỗi cho chức năng **Thử hiển thị** trên SketchUp 2023.

## Sửa trong v1.4.2

- Extension đã đăng ký: dùng `SketchupExtension#check` để nạp phần code thực tế của extension trong phiên hiện tại.
- Nếu extension vốn đang tắt khi khởi động, sau khi nạp thử sẽ gọi `uncheck` để trả lại trạng thái khởi động cũ; code đã nạp vẫn hoạt động trong phiên hiện tại.
- Plugin không được Extension Manager quản lý: chỉ thử nạp loader an toàn ở mức gốc, không quét và chạy bừa toàn bộ `.rb` trong thư mục.
- Hiển thị lỗi nạp trực tiếp trên giao diện nếu thử không thành công.
- Giữ chức năng Gỡ hẳn và log `removed_log.json`.

## Lưu ý

SketchUp không cung cấp API chung để ép hiện toolbar của một plugin khác nếu plugin đó đã được nạp nhưng toolbar đang bị người dùng ẩn. Trong trường hợp đó, kiểm tra **View > Toolbars**.
