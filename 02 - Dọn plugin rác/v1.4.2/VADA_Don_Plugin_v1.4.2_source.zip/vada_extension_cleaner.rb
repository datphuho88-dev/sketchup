# frozen_string_literal: true

require 'sketchup.rb'
require 'extensions.rb'

module VADA
  module ExtensionCleaner
    EXTENSION_NAME = 'Dọn Plugin VADA'
    EXTENSION_VERSION = '1.4.2'
    EXTENSION_CREATOR = 'Công ty TNHH VADA'

    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new(EXTENSION_NAME, 'vada_extension_cleaner/main')
      extension.description = 'Tìm, thử hiển thị, tắt, cách ly và gỡ plugin SketchUp. Có vùng Cách ly để khôi phục khi cần.'
      extension.version = EXTENSION_VERSION
      extension.creator = EXTENSION_CREATOR
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
