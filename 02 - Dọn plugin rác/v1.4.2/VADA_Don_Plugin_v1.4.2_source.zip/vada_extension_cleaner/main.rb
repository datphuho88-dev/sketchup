# frozen_string_literal: true

require 'sketchup.rb'
require 'json'
require 'fileutils'
require 'time'

module VADA
  module ExtensionCleaner
    extend self

    PLUGIN_ID = 'vada_extension_cleaner'
    TITLE = 'Dọn Plugin VADA'
    VERSION = '1.4.2'
    CORE_PROTECTED = %w[
      sketchup.rb extensions.rb langhandler.rb
      vada_extension_cleaner.rb vada_extension_cleaner
    ].freeze

    def plugins_dir
      @plugins_dir ||= begin
        # main.rb lives in <Plugins>/vada_extension_cleaner/main.rb.
        local = File.expand_path('..', __dir__)
        support = begin
          Sketchup.find_support_file('Plugins')
        rescue StandardError
          nil
        end
        candidates = [support, local].compact.map { |p| File.expand_path(p.to_s) }
        candidates.find { |p| File.directory?(p) } || local
      end
    end

    # Dir.children is not available in some Ruby versions bundled with older SketchUp.
    def dir_entries(path)
      return [] unless path && File.directory?(path)
      Dir.entries(path).reject { |name| name == '.' || name == '..' }
    rescue StandardError
      []
    end

    def quarantine_dir
      @quarantine_dir ||= begin
        # Keep Quarantine beside the Plugins folder so it survives OS temp cleanup.
        base = File.join(File.dirname(plugins_dir), 'VADA_ExtensionCleaner_Quarantine')
        FileUtils.mkdir_p(base)
        base
      end
    end

    def index_path
      File.join(quarantine_dir, 'index.json')
    end

    def removed_log_path
      File.join(quarantine_dir, 'removed_log.json')
    end

    def load_removed_log
      return [] unless File.file?(removed_log_path)
      JSON.parse(File.read(removed_log_path, encoding: 'UTF-8'))
    rescue StandardError
      []
    end

    def save_removed_log(records)
      File.write(removed_log_path, JSON.pretty_generate(records))
    end

    def normalize(path)
      File.expand_path(path.to_s).tr('\\', '/').downcase
    rescue StandardError
      path.to_s.tr('\\', '/').downcase
    end

    def inside_plugins?(path)
      return false if plugins_dir.nil? || path.to_s.empty?
      n_path = normalize(path)
      n_root = normalize(plugins_dir)
      n_path == n_root || n_path.start_with?(n_root + '/')
    end

    def protected_path?(path)
      return true unless inside_plugins?(path)
      rel = File.expand_path(path).sub(/^#{Regexp.escape(plugins_dir)}[\\\/]?/, '')
      top = rel.split(/[\\\/]/).first.to_s
      CORE_PROTECTED.include?(top.downcase)
    end

    def safe_ext_value(ext, method, fallback = nil)
      ext.respond_to?(method) ? ext.public_send(method) : fallback
    rescue StandardError
      fallback
    end

    def load_error_text(ext)
      err = safe_ext_value(ext, :load_error)
      return nil unless err
      "#{err.class}: #{err.message}"
    rescue StandardError
      nil
    end

    def dependency_like?(name, creator = '', paths = [])
      text = ([name, creator] + Array(paths).map { |p| File.basename(p.to_s) }).join(' ').downcase
      patterns = [
        'libfredo', 'fredo6', 'tt_lib', 'ttlib', 'ams_lib', 'amslib',
        'shared library', 'support library', 'thư viện'
      ]
      patterns.any? { |token| text.include?(token) }
    rescue StandardError
      false
    end

    def candidate_paths_for_extension(ext)
      raw = safe_ext_value(ext, :extension_path, '').to_s
      return [] if raw.empty?

      path = File.expand_path(raw)
      return [] unless inside_plugins?(path)

      rel = path.sub(/^#{Regexp.escape(plugins_dir)}[\\\/]?/, '')
      parts = rel.split(/[\\\/]/)
      paths = []

      if parts.length <= 1
        paths << path if File.exist?(path)
        stem = path.sub(/\.(rb|rbe|rbs)$/i, '')
        paths << stem if File.directory?(stem)
      else
        top_name = parts.first
        top_dir = File.join(plugins_dir, top_name)
        paths << top_dir if File.exist?(top_dir)
        %w[.rb .rbe .rbs].each do |extname|
          loader = File.join(plugins_dir, "#{top_name}#{extname}")
          paths << loader if File.exist?(loader)
        end
      end

      paths.uniq.reject { |p| protected_path?(p) }
    rescue StandardError
      []
    end

    def root_key_for_path(path)
      rel = File.expand_path(path).sub(/^#{Regexp.escape(plugins_dir)}[\\\/]?/, '')
      first = rel.split(/[\\\/]/).first.to_s
      first.sub(/\.(rb|rbe|rbs)$/i, '').downcase
    rescue StandardError
      ''
    end

    def max_mtime(paths)
      # Avoid Array#filter_map so the cleaner also works with older Ruby
      # versions bundled with older SketchUp releases.
      times = []
      Array(paths).each do |path|
        begin
          times << File.mtime(path) if File.exist?(path)
        rescue StandardError
          nil
        end
      end
      latest = times.max
      latest ? latest.iso8601 : nil
    end

    def extension_item(ext, index)
      paths = candidate_paths_for_extension(ext)
      error = load_error_text(ext)
      loaded = !!safe_ext_value(ext, :loaded?, false)
      load_on_start = !!safe_ext_value(ext, :load_on_start?, false)
      ew_id = safe_ext_value(ext, :id, '').to_s
      name = safe_ext_value(ext, :name, '(Không tên)').to_s
      creator = safe_ext_value(ext, :creator, '').to_s
      dependency = dependency_like?(name, creator, paths)

      reasons = []
      score = 0
      if error
        reasons << 'Lỗi khi nạp'
        score += 85
      end
      unless load_on_start
        reasons << 'Đang tắt khi khởi động'
        score += 30
      end
      if ew_id.empty?
        reasons << 'Không có Extension Warehouse ID'
        score += 5
      end
      reasons << 'Không xác định được file để cách ly' if paths.empty?
      if dependency
        reasons << 'Có vẻ là thư viện phụ thuộc – kiểm tra trước khi gỡ'
        score = [score - 25, 0].max
      end

      suggestion = if error
                     'Ưu tiên kiểm tra'
                   elsif dependency
                     'Có thể là thư viện phụ thuộc'
                   elsif !load_on_start
                     'Có thể dọn nếu bạn không còn dùng'
                   elsif loaded
                     'Đang hoạt động'
                   else
                     'Chưa nạp trong phiên hiện tại'
                   end

      {
        uid: "ext:#{index}",
        kind: 'registered',
        name: name,
        creator: creator,
        version: safe_ext_value(ext, :version, '').to_s,
        ew_id: ew_id,
        loaded: loaded,
        load_on_start: load_on_start,
        registered: !!safe_ext_value(ext, :registered?, true),
        error: error,
        reasons: reasons,
        suggestion: suggestion,
        dependency: dependency,
        risk: [score, 100].min,
        paths: paths,
        path_text: paths.join(' | '),
        mtime: max_mtime(paths),
        protected: paths.any? { |p| protected_path?(p) } || name == TITLE
      }
    end

    def registered_extensions
      list = []
      manager = Sketchup.extensions
      count = manager.respond_to?(:length) ? manager.length.to_i : 0

      # Index-based access is deliberately used here. Some SketchUp/Ruby
      # combinations have behaved inconsistently with Enumerable helpers.
      count.times do |index|
        begin
          ext = manager[index]
          next unless ext
          list << extension_item(ext, index)
        rescue StandardError => e
          list << {
            uid: "ext:#{index}", kind: 'registered', name: "Extension ##{index}", creator: '', version: '', ew_id: '',
            loaded: false, load_on_start: false, registered: true, error: e.message,
            reasons: ['Không đọc được thông tin extension'], suggestion: 'Ưu tiên kiểm tra', dependency: false, risk: 70, paths: [], path_text: '', mtime: nil, protected: false
          }
        end
      end
      list
    rescue StandardError => e
      [{
        uid: 'registered:scan_error', kind: 'system', name: 'Lỗi đọc Extension Manager', creator: '', version: '', ew_id: '',
        loaded: nil, load_on_start: nil, registered: false, error: e.message,
        reasons: ['Không thể đọc danh sách Extension Manager'], suggestion: 'Kiểm tra Ruby Console', dependency: false, risk: 0, paths: [], path_text: '', mtime: nil, protected: true
      }]
    end

    def unmanaged_items(managed_keys)
      return [] unless plugins_dir && Dir.exist?(plugins_dir)

      entries = dir_entries(plugins_dir).reject { |name| name.start_with?('.') }
      groups = {}

      entries.each do |name|
        next if CORE_PROTECTED.include?(name.downcase)
        full = File.join(plugins_dir, name)
        next unless File.file?(full) || File.directory?(full)

        if File.file?(full)
          next unless name =~ /\.(rb|rbe|rbs)$/i
          key = name.sub(/\.(rb|rbe|rbs)$/i, '').downcase
        else
          key = name.downcase
        end

        next if managed_keys.include?(key)
        (groups[key] ||= []) << full
      end

      groups.map.with_index do |(key, paths), i|
        display = File.basename(paths.find { |p| File.directory?(p) } || paths.first).sub(/\.(rb|rbe|rbs)$/i, '')
        dependency = dependency_like?(display, '', paths)
        reasons = ['Không được Extension Manager đăng ký/quản lý']
        reasons << 'Có vẻ là thư viện phụ thuộc – kiểm tra trước khi gỡ' if dependency
        risk = dependency ? 15 : 45
        {
          uid: "loose:#{i}:#{key}",
          kind: 'unmanaged',
          name: display,
          creator: '',
          version: '',
          ew_id: '',
          loaded: nil,
          load_on_start: nil,
          registered: false,
          error: nil,
          reasons: reasons,
          suggestion: dependency ? 'Có thể là thư viện phụ thuộc' : 'Kiểm tra thủ công trước khi dọn',
          dependency: dependency,
          risk: risk,
          paths: paths.reject { |p| protected_path?(p) },
          path_text: paths.join(' | '),
          mtime: max_mtime(paths),
          protected: paths.any? { |p| protected_path?(p) }
        }
      end
    rescue StandardError => e
      [{
        uid: 'scan:error', kind: 'system', name: 'Lỗi quét thư mục Plugins', creator: '', version: '', ew_id: '',
        loaded: nil, load_on_start: nil, registered: false, error: e.message,
        reasons: ['Không thể đọc đầy đủ thư mục Plugins'], suggestion: 'Kiểm tra Ruby Console', dependency: false,
        risk: 0, paths: [], path_text: '', mtime: nil, protected: true
      }]
    end

    def scan
      registered = registered_extensions
      registered_real = registered.reject { |i| i[:kind] == 'system' }
      managed_keys = registered_real.flat_map { |item| item[:paths].map { |p| root_key_for_path(p) } }.reject { |k| k.to_s.empty? }.uniq
      loose = unmanaged_items(managed_keys)
      items = registered + loose

      root_entries = begin
        plugins_dir && File.directory?(plugins_dir) ? dir_entries(plugins_dir).count { |n| !n.start_with?('.') } : 0
      rescue StandardError
        0
      end

      {
        version: VERSION,
        plugins_dir: plugins_dir,
        quarantine_dir: quarantine_dir,
        items: items.sort_by { |i| [-i[:risk].to_i, i[:name].to_s.downcase] },
        stats: {
          total: items.length,
          registered: registered_real.length,
          unmanaged: items.count { |i| i[:kind] == 'unmanaged' },
          errors: items.count { |i| i[:error] },
          disabled: items.count { |i| i[:kind] == 'registered' && i[:load_on_start] == false },
          enabled: items.count { |i| i[:kind] == 'registered' && i[:load_on_start] == true },
          dependencies: items.count { |i| i[:dependency] },
          root_entries: root_entries
        }
      }
    rescue StandardError => e
      {
        version: VERSION,
        plugins_dir: plugins_dir,
        quarantine_dir: quarantine_dir,
        items: [{ uid: 'scan:fatal', kind: 'system', name: 'Lỗi quét plugin', creator: '', version: '', ew_id: '', loaded: nil, load_on_start: nil, registered: false, error: e.message, reasons: ['Scanner gặp lỗi'], suggestion: 'Kiểm tra Ruby Console', dependency: false, risk: 0, paths: [], path_text: '', mtime: nil, protected: true }],
        stats: { total: 1, registered: 0, unmanaged: 0, errors: 1, disabled: 0, enabled: 0, dependencies: 0, root_entries: 0 }
      }
    end

    def find_registered(uid)
      index = uid.to_s.split(':')[1].to_i
      Sketchup.extensions[index]
    rescue StandardError
      nil
    end

    def disable_uids(uids)
      results = []
      Array(uids).each do |uid|
        ext = find_registered(uid)
        if ext
          ok = ext.uncheck
          results << { uid: uid, ok: !!ok, message: ok ? 'Đã tắt cho lần khởi động sau' : 'Không thể tắt' }
        else
          results << { uid: uid, ok: false, message: 'Không tìm thấy extension đã đăng ký' }
        end
      rescue StandardError => e
        results << { uid: uid, ok: false, message: e.message }
      end
      results
    end

    def load_index
      return [] unless File.file?(index_path)
      JSON.parse(File.read(index_path, encoding: 'UTF-8'))
    rescue StandardError
      []
    end

    def save_index(records)
      File.write(index_path, JSON.pretty_generate(records))
    end

    def unique_destination(batch_dir, source)
      base = File.basename(source)
      dest = File.join(batch_dir, base)
      return dest unless File.exist?(dest)

      n = 2
      loop do
        candidate = File.join(batch_dir, "#{base}.#{n}")
        return candidate unless File.exist?(candidate)
        n += 1
      end
    end

    def quarantine_uids(uids)
      current = scan[:items].each_with_object({}) { |item, memo| memo[item[:uid]] = item }
      batch = Time.now.strftime('%Y%m%d-%H%M%S')
      batch_dir = File.join(quarantine_dir, batch)
      FileUtils.mkdir_p(batch_dir)
      index = load_index
      results = []

      Array(uids).each do |uid|
        item = current[uid]
        unless item
          results << { uid: uid, ok: false, message: 'Không còn tìm thấy mục này' }
          next
        end
        if item[:protected]
          results << { uid: uid, ok: false, message: 'Mục được bảo vệ, không cho cách ly' }
          next
        end
        if item[:paths].empty?
          results << { uid: uid, ok: false, message: 'Không xác định được file/thư mục để cách ly' }
          next
        end

        if item[:kind] == 'registered'
          registered_ext = find_registered(uid)
          registered_ext.uncheck if registered_ext
        end

        moved = []
        begin
          item[:paths].uniq.each do |source|
            next unless File.exist?(source)
            raise 'Đường dẫn nằm ngoài thư mục Plugins' unless inside_plugins?(source)
            raise 'Mục được bảo vệ' if protected_path?(source)

            dest = unique_destination(batch_dir, source)
            FileUtils.mv(source, dest)
            moved << { 'source' => source, 'quarantine' => dest }
          end

          if moved.empty?
            results << { uid: uid, ok: false, message: 'Không có file nào được di chuyển' }
            next
          end

          record = {
            'record_id' => "#{batch}:#{uid}",
            'uid' => uid,
            'name' => item[:name],
            'kind' => item[:kind],
            'time' => Time.now.iso8601,
            'files' => moved
          }
          index << record
          results << { uid: uid, ok: true, message: 'Đã chuyển vào vùng Cách ly. Khởi động lại SketchUp để áp dụng hoàn toàn.' }
        rescue StandardError => e
          moved.reverse_each do |pair|
            begin
              FileUtils.mv(pair['quarantine'], pair['source']) if File.exist?(pair['quarantine']) && !File.exist?(pair['source'])
            rescue StandardError
              nil
            end
          end
          results << { uid: uid, ok: false, message: e.message }
        end
      end

      save_index(index)
      results
    end

    def quarantine_records
      load_index.reverse.map do |r|
        {
          record_id: r['record_id'],
          name: r['name'],
          kind: r['kind'],
          time: r['time'],
          files: r['files']
        }
      end
    end

    def restore_record(record_id)
      index = load_index
      record = index.find { |r| r['record_id'] == record_id }
      return { ok: false, message: 'Không tìm thấy bản sao lưu' } unless record

      restored = []
      begin
        Array(record['files']).each do |pair|
          source = pair['source']
          quarantined = pair['quarantine']
          next unless File.exist?(quarantined)
          raise "Đích đã tồn tại: #{source}" if File.exist?(source)
          FileUtils.mkdir_p(File.dirname(source))
          FileUtils.mv(quarantined, source)
          restored << pair
        end
        index.delete(record)
        save_index(index)
        { ok: true, message: 'Đã khôi phục. Khởi động lại SketchUp để nạp plugin.' }
      rescue StandardError => e
        { ok: false, message: e.message }
      end
    end

    def preview_loader_for(item)
      paths = Array(item[:paths]).select { |path| File.exist?(path) }

      # Prefer a top-level loader file in Plugins. This covers the common
      # <name>.rb + <name>/ folder layout without executing arbitrary files.
      file = paths.find { |path| File.file?(path) && path =~ /\.(rb|rbe|rbs)$/i }
      return file if file

      dir = paths.find { |path| File.directory?(path) }
      return nil unless dir

      base = File.basename(dir)
      candidates = []
      %w[.rb .rbe .rbs].each { |ext| candidates << File.join(dir, "#{base}#{ext}") }
      %w[main loader core].each do |stem|
        %w[.rb .rbe .rbs].each { |ext| candidates << File.join(dir, "#{stem}#{ext}") }
      end
      candidates.find { |path| File.file?(path) }
    rescue StandardError
      nil
    end

    def preview_uid(uid)
      item = scan[:items].find { |entry| entry[:uid] == uid.to_s }
      return { uid: uid, ok: false, message: 'Không còn tìm thấy plugin này' } unless item
      return { uid: uid, ok: false, message: 'Không thử hiển thị mục được bảo vệ' } if item[:protected]

      if item[:kind] == 'registered'
        ext = find_registered(uid)
        return { uid: uid, ok: false, message: 'Không tìm thấy extension đã đăng ký' } unless ext

        already_loaded = !!safe_ext_value(ext, :loaded?, false)
        if already_loaded
          return {
            uid: uid,
            ok: true,
            message: 'Plugin đã được nạp trong phiên hiện tại. Nếu toolbar đang ẩn, hãy kiểm tra View > Toolbars; SketchUp không có API chung để ép hiện toolbar của plugin khác.'
          }
        end

        was_load_on_start = !!safe_ext_value(ext, :load_on_start?, false)
        ok = ext.check

        # ext.check is the supported way to interpret an installed extension
        # immediately. If it was disabled before preview, restore that saved
        # startup state straight away. uncheck does not unload code already
        # interpreted in the current session.
        ext.uncheck if ok && !was_load_on_start

        loaded_now = !!safe_ext_value(ext, :loaded?, false)
        if ok || loaded_now
          {
            uid: uid,
            ok: true,
            message: was_load_on_start ?
              'Đã nạp plugin trong phiên hiện tại.' :
              'Đã nạp tạm plugin trong phiên hiện tại; trạng thái tắt khi khởi động đã được giữ nguyên.'
          }
        else
          { uid: uid, ok: false, message: 'SketchUp không nạp được plugin này. Mở Ruby Console để xem lỗi nạp.' }
        end
      elsif item[:kind] == 'unmanaged'
        loader = preview_loader_for(item)
        return { uid: uid, ok: false, message: 'Không xác định được file loader an toàn để thử hiển thị' } unless loader

        ok = Sketchup.load(loader)
        {
          uid: uid,
          ok: !!ok,
          message: ok ? "Đã nạp tạm: #{File.basename(loader)}" : 'SketchUp không nạp được file plugin này. Mở Ruby Console để xem lỗi.'
        }
      else
        { uid: uid, ok: false, message: 'Loại mục này không hỗ trợ Thử hiển thị' }
      end
    rescue Exception => e # SketchUp 2023 may surface loader errors inconsistently.
      { uid: uid, ok: false, message: "#{e.class}: #{e.message}" }
    end

    def remove_uids(uids)
      current = scan[:items].each_with_object({}) { |item, memo| memo[item[:uid]] = item }
      log = load_removed_log
      results = []

      Array(uids).each do |uid|
        item = current[uid]
        unless item
          results << { uid: uid, ok: false, message: 'Không còn tìm thấy mục này' }
          next
        end
        if item[:protected]
          results << { uid: uid, ok: false, message: 'Mục được bảo vệ, không cho gỡ hẳn' }
          next
        end
        if item[:paths].empty?
          results << { uid: uid, ok: false, message: 'Không xác định được file/thư mục để gỡ' }
          next
        end

        ext = find_registered(uid) if item[:kind] == 'registered'
        ext.uncheck if ext

        removed = []
        begin
          item[:paths].uniq.each do |source|
            next unless File.exist?(source)
            raise 'Đường dẫn nằm ngoài thư mục Plugins' unless inside_plugins?(source)
            raise 'Mục được bảo vệ' if protected_path?(source)

            if File.directory?(source)
              FileUtils.rm_rf(source)
            else
              FileUtils.rm_f(source)
            end
            removed << source unless File.exist?(source)
          end

          if removed.empty?
            results << { uid: uid, ok: false, message: 'Không xóa được file/thư mục nào' }
            next
          end

          log << {
            'time' => Time.now.iso8601,
            'uid' => uid,
            'name' => item[:name],
            'kind' => item[:kind],
            'paths' => removed
          }
          results << { uid: uid, ok: true, message: 'Đã gỡ hẳn. Không thể khôi phục từ vùng Cách ly.' }
        rescue StandardError => e
          results << { uid: uid, ok: false, message: e.message }
        end
      end

      save_removed_log(log)
      results
    end

    def open_path(path)
      target = path.to_s
      target = File.dirname(target) if File.file?(target)
      target = plugins_dir if target.empty? || !File.exist?(target)
      url = 'file:///' + target.tr('\\', '/').gsub(' ', '%20')
      UI.openURL(url)
      { ok: true }
    rescue StandardError => e
      { ok: false, message: e.message }
    end

    def html_path
      File.join(__dir__, 'ui.html')
    end

    def show_dialog
      @dialog ||= begin
        dlg = UI::HtmlDialog.new(
          dialog_title: TITLE,
          preferences_key: 'vada.extension_cleaner.dialog',
          scrollable: true,
          resizable: true,
          width: 1050,
          height: 720,
          min_width: 760,
          min_height: 500,
          style: UI::HtmlDialog::STYLE_DIALOG
        )
        dlg.set_file(html_path)
        dlg.add_action_callback('scan') { |_context, _| dlg.execute_script("window.receiveScan(#{JSON.generate(scan)})") }
        dlg.add_action_callback('disable') do |_context, payload|
          uids = JSON.parse(payload.to_s) rescue []
          dlg.execute_script("window.receiveAction(#{JSON.generate(disable_uids(uids))})")
        end
        dlg.add_action_callback('quarantine') do |_context, payload|
          uids = JSON.parse(payload.to_s) rescue []
          dlg.execute_script("window.receiveAction(#{JSON.generate(quarantine_uids(uids))})")
        end
        dlg.add_action_callback('preview') do |_context, uid|
          result = preview_uid(uid.to_s)
          dlg.execute_script("window.receivePreview(#{JSON.generate(result)})")
        end
        dlg.add_action_callback('remove') do |_context, payload|
          uids = JSON.parse(payload.to_s) rescue []
          dlg.execute_script("window.receiveAction(#{JSON.generate(remove_uids(uids))})")
        end
        dlg.add_action_callback('list_quarantine') { |_context, _| dlg.execute_script("window.receiveQuarantine(#{JSON.generate(quarantine_records)})") }
        dlg.add_action_callback('restore') do |_context, record_id|
          result = restore_record(record_id.to_s)
          dlg.execute_script("window.receiveRestore(#{JSON.generate(result)})")
        end
        dlg.add_action_callback('open_path') do |_context, path|
          dlg.execute_script("window.receiveOpenPath(#{JSON.generate(open_path(path.to_s))})")
        end
        dlg.set_on_closed { @dialog = nil }
        dlg
      end
      @dialog.show
      @dialog.bring_to_front
    end

    unless file_loaded?(__FILE__)
      command = UI::Command.new('Dọn Plugin VADA') { show_dialog }
      command.tooltip = 'Tìm, tắt và cách ly nhanh plugin SketchUp không cần thiết'
      command.status_bar_text = 'Quét, tắt và cách ly plugin SketchUp'

      icon_small = File.join(__dir__, 'icon_16.png')
      icon_large = File.join(__dir__, 'icon_24.png')
      command.small_icon = icon_small if File.file?(icon_small)
      command.large_icon = icon_large if File.file?(icon_large)

      UI.menu('Extensions').add_item(command)
      toolbar = UI::Toolbar.new('Dọn Plugin VADA')
      toolbar.add_item(command)
      toolbar.restore

      file_loaded(__FILE__)
    end
  end
end
