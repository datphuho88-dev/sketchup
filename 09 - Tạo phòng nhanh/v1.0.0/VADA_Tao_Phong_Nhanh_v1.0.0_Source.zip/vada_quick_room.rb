# frozen_string_literal: true

require 'sketchup.rb'
require 'extensions.rb'

module VADA
  module QuickRoom
    PLUGIN_ID = 'vada_quick_room'.freeze
    PLUGIN_NAME = 'VADA Tạo Phòng Nhanh'.freeze
    VERSION = '1.0.0'.freeze

    unless defined?(EXTENSION)
      EXTENSION = SketchupExtension.new(PLUGIN_NAME, 'vada_quick_room/main')
      EXTENSION.description = 'Tạo nhanh phòng chữ nhật theo kích thước lòng nhà, chiều cao, độ dày tường, sàn và mái.'
      EXTENSION.version = VERSION
      EXTENSION.creator = 'Công ty TNHH VADA'
      EXTENSION.copyright = '© 2026 Công ty TNHH VADA'
      Sketchup.register_extension(EXTENSION, true)
    end
  end
end
