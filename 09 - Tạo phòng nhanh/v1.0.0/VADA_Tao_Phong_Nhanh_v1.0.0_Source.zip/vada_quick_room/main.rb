# frozen_string_literal: true

require 'sketchup.rb'
require 'json'

module VADA
  module QuickRoom
    extend self

    VERSION = '1.0.0' unless const_defined?(:VERSION)
    PREF_KEY = 'VADA_QuickRoom'.freeze
    DEFAULTS = {
      'width' => 400.0,
      'length' => 500.0,
      'height' => 300.0,
      'wall' => 20.0,
      'floor' => 30.0,
      'roof' => 30.0
    }.freeze

    def show_dialog
      @dialog&.close if @dialog&.visible?

      @dialog = UI::HtmlDialog.new(
        dialog_title: "Tạo phòng nhanh - v#{VERSION}",
        preferences_key: 'VADA_QuickRoom_Dialog',
        scrollable: false,
        resizable: false,
        width: 410,
        height: 430,
        left: 120,
        top: 120,
        style: UI::HtmlDialog::STYLE_DIALOG
      )

      @dialog.set_html(dialog_html)

      @dialog.add_action_callback('create_room') do |_context, json|
        begin
          raw = JSON.parse(json.to_s)
          params = normalize_params(raw)
          validate_params!(params)
          save_defaults(params)
          @dialog.close
          Sketchup.active_model.select_tool(PlacementTool.new(params))
        rescue StandardError => e
          @dialog.execute_script("showError(#{e.message.to_json})") if @dialog
        end
      end

      @dialog.add_action_callback('cancel') do |_context|
        @dialog.close
      end

      @dialog.show
    end

    def normalize_params(raw)
      result = {}
      DEFAULTS.each_key do |key|
        value = raw[key]
        result[key] = Float(value.to_s.tr(',', '.'))
      rescue ArgumentError, TypeError
        raise "Giá trị '#{label_for(key)}' không hợp lệ."
      end
      result
    end

    def validate_params!(params)
      params.each do |key, value|
        raise "#{label_for(key)} phải lớn hơn 0 cm." unless value.finite? && value.positive?
      end

      if params['wall'] * 2.0 >= [params['width'], params['length']].min * 2.0
        # Không chặn trường hợp tường dày; chỉ cảnh báo các giá trị phi thực tế quá lớn.
        raise 'Độ dày tường đang quá lớn so với kích thước lòng nhà.' if params['wall'] > [params['width'], params['length']].min
      end
    end

    def label_for(key)
      {
        'width' => 'Chiều rộng lòng nhà',
        'length' => 'Chiều dài lòng nhà',
        'height' => 'Chiều cao lòng nhà',
        'wall' => 'Độ dày tường',
        'floor' => 'Độ dày sàn',
        'roof' => 'Độ dày mái'
      }[key] || key
    end

    def saved_value(key)
      Sketchup.read_default(PREF_KEY, key, DEFAULTS[key]).to_f
    end

    def save_defaults(params)
      params.each { |key, value| Sketchup.write_default(PREF_KEY, key, value) }
    end

    def dialog_html
      values = DEFAULTS.keys.to_h { |key| [key, saved_value(key)] }
      <<~HTML
        <!doctype html>
        <html lang="vi">
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <style>
            * { box-sizing: border-box; }
            html, body { margin: 0; background: #000000; color: #f3f3f3; font-family: Arial, sans-serif; }
            body { padding: 18px; user-select: none; }
            .head { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
            .icon { width: 34px; height: 34px; border: 1px solid #3b3b3b; border-radius: 8px; display: grid; place-items: center; background: #101010; }
            .icon svg { width: 24px; height: 24px; }
            .title { font-size: 16px; font-weight: 700; line-height: 1.2; }
            .version { color: #8f8f8f; font-size: 11px; margin-top: 3px; }
            .grid { display: grid; grid-template-columns: 1fr 126px; gap: 10px 12px; align-items: center; }
            label { font-size: 13px; color: #dddddd; }
            .unit { color: #8c8c8c; font-size: 11px; margin-left: 3px; }
            input { width: 100%; height: 30px; border: 1px solid #3d3d3d; border-radius: 5px; background: #141414; color: white; padding: 0 9px; font-size: 13px; outline: none; }
            input:focus { border-color: #00a8ff; box-shadow: 0 0 0 1px #00a8ff inset; }
            .error { min-height: 18px; color: #ff5757; font-size: 12px; margin-top: 10px; }
            .buttons { display: flex; justify-content: flex-end; gap: 8px; margin-top: 8px; }
            button { min-width: 92px; height: 32px; border-radius: 5px; border: 1px solid #444; background: #171717; color: #efefef; cursor: pointer; font-size: 13px; }
            button:hover { background: #242424; }
            button.primary { background: #087bb8; border-color: #1599dc; color: white; font-weight: 700; }
            button.primary:hover { background: #0a8bce; }
            .hint { margin-top: 12px; padding-top: 10px; border-top: 1px solid #252525; color: #858585; font-size: 11px; line-height: 1.45; }
          </style>
        </head>
        <body>
          <div class="head">
            <div class="icon">
              <svg viewBox="0 0 64 64" fill="none" aria-hidden="true">
                <path d="M10 28 32 12l22 16v25H10V28Z" stroke="#ffffff" stroke-width="4" stroke-linejoin="round"/>
                <path d="M21 53V33h22v20" stroke="#00a8ff" stroke-width="4" stroke-linejoin="round"/>
                <path d="M32 12v21" stroke="#666666" stroke-width="3"/>
              </svg>
            </div>
            <div>
              <div class="title">Nhập thông số phòng</div>
              <div class="version">VADA Tạo Phòng Nhanh · v#{VERSION}</div>
            </div>
          </div>

          <div class="grid">
            <label for="width">Chiều rộng lòng nhà <span class="unit">(cm)</span></label>
            <input id="width" type="number" min="0.1" step="1" value="#{values['width']}">

            <label for="length">Chiều dài lòng nhà <span class="unit">(cm)</span></label>
            <input id="length" type="number" min="0.1" step="1" value="#{values['length']}">

            <label for="height">Chiều cao lòng nhà <span class="unit">(cm)</span></label>
            <input id="height" type="number" min="0.1" step="1" value="#{values['height']}">

            <label for="wall">Độ dày tường <span class="unit">(cm)</span></label>
            <input id="wall" type="number" min="0.1" step="1" value="#{values['wall']}">

            <label for="floor">Độ dày sàn <span class="unit">(cm)</span></label>
            <input id="floor" type="number" min="0.1" step="1" value="#{values['floor']}">

            <label for="roof">Độ dày mái <span class="unit">(cm)</span></label>
            <input id="roof" type="number" min="0.1" step="1" value="#{values['roof']}">
          </div>

          <div id="error" class="error"></div>
          <div class="buttons">
            <button onclick="sketchup.cancel()">Hủy</button>
            <button class="primary" onclick="submitForm()">Tạo phòng</button>
          </div>
          <div class="hint">Sau khi bấm <b>Tạo phòng</b>, click một điểm trong model để đặt góc trong phía dưới của phòng.</div>

          <script>
            function submitForm() {
              const keys = ['width','length','height','wall','floor','roof'];
              const data = {};
              keys.forEach(k => data[k] = document.getElementById(k).value);
              document.getElementById('error').textContent = '';
              sketchup.create_room(JSON.stringify(data));
            }
            function showError(message) {
              document.getElementById('error').textContent = message || 'Có lỗi xảy ra.';
            }
            document.addEventListener('keydown', function(e) {
              if (e.key === 'Enter') submitForm();
              if (e.key === 'Escape') sketchup.cancel();
            });
          </script>
        </body>
        </html>
      HTML
    end

    def build_room(model, origin, params)
      model.start_operation('VADA - Tạo phòng nhanh', true)

      begin
        ents = model.active_entities
        room = ents.add_group
        room.name = format('VADA Phòng %.0fx%.0fx%.0f cm', params['width'], params['length'], params['height'])
        room.transform!(Geom::Transformation.translation(origin))

        w = params['width'].cm
        l = params['length'].cm
        h = params['height'].cm
        t = params['wall'].cm
        floor_t = params['floor'].cm
        roof_t = params['roof'].cm

        # Sàn hoàn thiện ở Z=0. Chiều cao lòng nhà tính tới mặt dưới mái.
        floor_group = room.entities.add_group
        floor_group.name = 'Sàn'
        add_box(floor_group.entities, -t, -t, -floor_t, w + t, l + t, 0)

        walls_group = room.entities.add_group
        walls_group.name = 'Tường'
        add_box(walls_group.entities, -t, -t, 0, 0, l + t, h)       # trái
        add_box(walls_group.entities, w, -t, 0, w + t, l + t, h)     # phải
        add_box(walls_group.entities, 0, -t, 0, w, 0, h)             # trước
        add_box(walls_group.entities, 0, l, 0, w, l + t, h)          # sau

        roof_group = room.entities.add_group
        roof_group.name = 'Mái'
        add_box(roof_group.entities, -t, -t, h, w + t, l + t, h + roof_t)

        room.set_attribute(PREF_KEY, 'version', VERSION)
        params.each { |key, value| room.set_attribute(PREF_KEY, key, value) }

        model.selection.clear
        model.selection.add(room)
        model.commit_operation
        room
      rescue StandardError
        model.abort_operation
        raise
      end
    end

    def add_box(entities, x1, y1, z1, x2, y2, z2)
      return if x2 <= x1 || y2 <= y1 || z2 <= z1

      points = [
        Geom::Point3d.new(x1, y1, z1),
        Geom::Point3d.new(x2, y1, z1),
        Geom::Point3d.new(x2, y2, z1),
        Geom::Point3d.new(x1, y2, z1)
      ]
      face = entities.add_face(points)
      raise 'Không thể tạo hình học phòng.' unless face&.valid?

      face.reverse! if face.normal.z < 0
      face.pushpull(z2 - z1)
    end

    class PlacementTool
      def initialize(params)
        @params = params
        @ip = Sketchup::InputPoint.new
      end

      def activate
        Sketchup.set_status_text('Click điểm đặt góc trong phía dưới của phòng. ESC để hủy.', SB_PROMPT)
      end

      def deactivate(view)
        Sketchup.set_status_text('', SB_PROMPT)
        view.invalidate if view
      end

      def onMouseMove(_flags, x, y, view)
        @ip.pick(view, x, y)
        view.tooltip = @ip.tooltip if @ip.valid?
        view.invalidate
      end

      def onLButtonDown(_flags, _x, _y, view)
        return unless @ip.valid?

        room = VADA::QuickRoom.build_room(Sketchup.active_model, @ip.position, @params)
        view.invalidate
        Sketchup.set_status_text('Đã tạo phòng. Chọn công cụ để tiếp tục.', SB_PROMPT)
        Sketchup.active_model.select_tool(nil)
        room
      rescue StandardError => e
        UI.messagebox("Không thể tạo phòng:\n#{e.message}")
      end

      def onCancel(_reason, view)
        Sketchup.active_model.select_tool(nil)
        view.invalidate
      end

      def draw(view)
        return unless @ip.valid?

        w = @params['width'].cm
        l = @params['length'].cm
        h = @params['height'].cm
        t = @params['wall'].cm
        o = @ip.position

        local = [
          [-t, -t, 0], [w + t, -t, 0], [w + t, l + t, 0], [-t, l + t, 0],
          [-t, -t, h], [w + t, -t, h], [w + t, l + t, h], [-t, l + t, h]
        ].map { |x, y, z| Geom::Point3d.new(o.x + x, o.y + y, o.z + z) }

        edges = [
          [0,1],[1,2],[2,3],[3,0],
          [4,5],[5,6],[6,7],[7,4],
          [0,4],[1,5],[2,6],[3,7]
        ]
        points = edges.flat_map { |a, b| [local[a], local[b]] }

        view.drawing_color = Sketchup::Color.new(0, 168, 255)
        view.line_width = 2
        view.draw(GL_LINES, points)
        @ip.draw(view)
      end
    end

    unless file_loaded?(__FILE__)
      command = UI::Command.new('Tạo phòng nhanh') { VADA::QuickRoom.show_dialog }
      command.tooltip = 'Tạo phòng nhanh theo kích thước lòng nhà'
      command.status_bar_text = 'Nhập kích thước và tạo nhanh một phòng chữ nhật.'

      icon_dir = File.join(__dir__, 'icons')
      small_icon = File.join(icon_dir, 'room_24.png')
      large_icon = File.join(icon_dir, 'room_32.png')
      command.small_icon = small_icon if File.exist?(small_icon)
      command.large_icon = large_icon if File.exist?(large_icon)

      toolbar = UI::Toolbar.new('VADA - Tạo Phòng Nhanh')
      toolbar.add_item(command)
      toolbar.restore

      begin
        UI.menu('Extensions').add_item(command)
      rescue StandardError
        UI.menu('Plugins').add_item(command)
      end

      file_loaded(__FILE__)
    end
  end
end
