# frozen_string_literal: true

require 'sketchup.rb'
require 'json'

module VADA
  module BoolDeDung
    extend self

    VERSION = '1.0.2'.freeze
    PLUGIN_NAME = 'VADA Bool Dễ Dùng'.freeze
    ROOT = File.dirname(__FILE__).freeze
    ICON_DIR = File.join(ROOT, 'icons').freeze

    OPS = {
      'union' => {
        title: 'Gộp khối',
        a: 'Chọn khối A',
        b: 'Chọn khối B để gộp với A',
        hint: 'Kết quả: A + B thành một Solid.'
      },
      'subtract' => {
        title: 'Trừ khối',
        a: 'Chọn A = khối cần giữ lại',
        b: 'Chọn B = khối dùng để cắt A',
        hint: 'Kết quả: A − B. B sẽ bị dùng trong phép trừ.'
      },
      'trim' => {
        title: 'Cắt giữ dao',
        a: 'Chọn A = khối cần cắt',
        b: 'Chọn B = dao cắt, B sẽ được giữ lại',
        hint: 'Kết quả: A bị cắt, B vẫn còn.'
      },
      'intersect' => {
        title: 'Lấy phần giao',
        a: 'Chọn khối A',
        b: 'Chọn khối B',
        hint: 'Kết quả: chỉ giữ phần thể tích A và B giao nhau.'
      },
      'split' => {
        title: 'Chia khối',
        a: 'Chọn khối A',
        b: 'Chọn khối B để chia',
        hint: 'Kết quả: tách thành các phần A−B, phần giao và B−A.'
      }
    }.freeze

    @dialog = nil
    @active_tool = nil

    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        push_state
        return
      end

      @dialog = UI::HtmlDialog.new(
        dialog_title: "#{PLUGIN_NAME} v#{VERSION}",
        preferences_key: 'vada_bool_de_dung_dialog',
        scrollable: false,
        resizable: true,
        width: 420,
        height: 560,
        left: 120,
        top: 120,
        style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dialog.set_file(File.join(ROOT, 'ui.html'))
      @dialog.add_action_callback('start_operation') { |_ctx, op| start_tool(op.to_s) }
      @dialog.add_action_callback('cancel_tool') { |_ctx| cancel_tool }
      @dialog.add_action_callback('undo') { |_ctx| Sketchup.undo }
      @dialog.add_action_callback('ready') { |_ctx| push_state }
      @dialog.set_on_closed { @dialog = nil }
      @dialog.show
    end

    def start_tool(op)
      return unless OPS.key?(op)

      model = Sketchup.active_model
      unless model
        UI.messagebox('Không có model SketchUp đang mở.')
        return
      end

      @active_tool = BooleanPickTool.new(op)
      model.select_tool(@active_tool)
      push_state
    end

    def cancel_tool
      Sketchup.active_model.select_tool(nil)
      @active_tool = nil
      set_state('idle', 'Chọn một phép Boolean để bắt đầu.', nil, nil, nil)
    end

    def solid?(entity)
      return false unless boolean_entity?(entity)
      return false if entity.deleted? || entity.locked?

      volume = entity.volume
      volume && volume > 0.0
    rescue StandardError
      false
    end

    def boolean_entity?(entity)
      entity.is_a?(Sketchup::Group) || entity.is_a?(Sketchup::ComponentInstance)
    end

    def entity_label(entity)
      return nil unless entity && entity.valid?
      kind = entity.is_a?(Sketchup::Group) ? 'Group' : 'Component'
      name = entity.name.to_s.strip
      name = entity.definition.name.to_s.strip if name.empty? && entity.respond_to?(:definition)
      name = '(chưa đặt tên)' if name.empty?
      "#{kind}: #{name}"
    rescue StandardError
      'Vật thể'
    end

    def set_state(status, instruction, op = nil, a = nil, b = nil, error = nil)
      return unless @dialog && @dialog.visible?

      payload = {
        version: VERSION,
        status: status,
        instruction: instruction,
        operation: op,
        a: entity_label(a),
        b: entity_label(b),
        a_solid: a ? solid?(a) : nil,
        b_solid: b ? solid?(b) : nil,
        error: error
      }
      @dialog.execute_script("window.VADA && VADA.update(#{JSON.generate(payload)})")
    rescue StandardError
      nil
    end

    def push_state
      if @active_tool && @active_tool.respond_to?(:push_state)
        @active_tool.push_state
      else
        set_state('idle', 'Chọn một phép Boolean để bắt đầu.')
      end
    end

    def perform_boolean(op, a, b)
      unless solid?(a) && solid?(b)
        return [false, nil, 'Cả A và B phải là Solid Group/Component kín.']
      end

      model = Sketchup.active_model
      meta = remember_metadata(a)
      model.start_operation("VADA Bool: #{OPS[op][:title]}", true)

      result = case op
               when 'union'
                 a.union(b)
               when 'subtract'
                 a.subtract(b)
               when 'trim'
                 # SketchUp API: cutter.trim(target) keeps the cutter and trims target.
                 b.trim(a)
               when 'intersect'
                 a.intersect(b)
               when 'split'
                 a.split(b)
               end

      if result.nil? || (result.respond_to?(:empty?) && result.empty?)
        model.abort_operation
        return [false, nil, 'SketchUp không tạo được kết quả. Kiểm tra hai khối có giao nhau và đều là Solid.']
      end

      if op == 'split'
        result.compact.each_with_index do |g, idx|
          next unless g && g.valid?
          apply_metadata(g, meta)
          g.name = ["#{meta[:name]} - B\\A", "#{meta[:name]} - A\\B", "#{meta[:name]} - Giao"][idx] rescue nil
        end
      else
        apply_metadata(result, meta) if result.respond_to?(:valid?) && result.valid?
      end

      model.commit_operation
      [true, result, nil]
    rescue StandardError => e
      model.abort_operation rescue nil
      [false, nil, "Lỗi Boolean: #{e.message}"]
    end

    def remember_metadata(entity)
      {
        name: entity_label_name(entity),
        layer: entity.layer,
        material: entity.material
      }
    end

    def entity_label_name(entity)
      name = entity.name.to_s.strip
      name = entity.definition.name.to_s.strip if name.empty? && entity.respond_to?(:definition)
      name.empty? ? 'Bool' : name
    rescue StandardError
      'Bool'
    end

    def apply_metadata(entity, meta)
      entity.name = meta[:name] if entity.respond_to?(:name=)
      entity.layer = meta[:layer] if meta[:layer] && entity.respond_to?(:layer=)
      entity.material = meta[:material] if meta[:material] && entity.respond_to?(:material=)
    rescue StandardError
      nil
    end

    class BooleanPickTool
      def initialize(op)
        @op = op
        @a = nil
        @b = nil
        @hover = nil
        @last_error = nil
      end

      def activate
        update_status
        Sketchup.active_model.active_view.invalidate
      end

      def deactivate(view)
        view.invalidate
        VADA::BoolDeDung.instance_variable_set(:@active_tool, nil)
        VADA::BoolDeDung.set_state('idle', 'Chọn một phép Boolean để bắt đầu.')
      end

      def onCancel(_reason, view)
        reset
        view.invalidate
      end

      def onMouseMove(_flags, x, y, view)
        @hover = pick_boolean_entity(view, x, y)
        view.tooltip = tooltip_for(@hover)
        view.invalidate
      end

      def onLButtonDown(_flags, x, y, view)
        entity = pick_boolean_entity(view, x, y)
        unless entity
          @last_error = 'Hãy click trực tiếp vào một Group hoặc Component.'
          update_status
          view.invalidate
          return
        end

        unless VADA::BoolDeDung.solid?(entity)
          @last_error = 'Vật thể này chưa phải Solid kín. Mở Entity Info: phải hiện “Solid Group” hoặc “Solid Component”.'
          update_status
          UI.beep
          view.invalidate
          return
        end

        if @a.nil?
          @a = entity
          @last_error = nil
          update_status
        elsif entity == @a
          @last_error = 'B phải là vật thể khác A.'
          update_status
          UI.beep
        else
          @b = entity
          @last_error = nil
          update_status
          execute(view)
        end
        view.invalidate
      end

      def draw(view)
        draw_entity_box(view, @hover, [255, 215, 0, 255], 2) if @hover && @hover != @a && @hover != @b
        draw_entity_box(view, @a, [0, 220, 255, 255], 4) if @a && @a.valid?
        draw_entity_box(view, @b, [255, 80, 80, 255], 4) if @b && @b.valid?

        draw_label(view, @a, 'A', [0, 220, 255, 255]) if @a && @a.valid?
        draw_label(view, @b, 'B', [255, 80, 80, 255]) if @b && @b.valid?
      rescue StandardError
        nil
      end

      def push_state
        update_status
      end

      private

      def execute(view)
        ok, result, error = VADA::BoolDeDung.perform_boolean(@op, @a, @b)
        if ok
          @last_error = nil
          @a = nil
          @b = nil
          VADA::BoolDeDung.set_state('success', 'Đã xử lý xong. Có thể tiếp tục chọn A mới hoặc Ctrl+Z để hoàn tác.', @op)
        else
          @last_error = error
          @b = nil if @b && @b.deleted?
          @a = nil if @a && @a.deleted?
          update_status
          UI.beep
        end
        view.invalidate
      end

      def reset
        @a = nil
        @b = nil
        @hover = nil
        @last_error = nil
        update_status
      end

      def update_status
        info = OPS[@op]
        instruction = if @a.nil?
                        "Bước 1/2 — #{info[:a]}. #{info[:hint]}"
                      else
                        "Bước 2/2 — #{info[:b]}. #{info[:hint]}"
                      end
        Sketchup.status_text = instruction
        VADA::BoolDeDung.set_state(@a ? 'pick_b' : 'pick_a', instruction, @op, @a, @b, @last_error)
      end

      def tooltip_for(entity)
        return 'Click vào Group/Component Solid' unless entity
        state = VADA::BoolDeDung.solid?(entity) ? 'Solid ✓' : 'Không phải Solid ✕'
        "#{VADA::BoolDeDung.entity_label(entity)} — #{state}"
      end

      def pick_boolean_entity(view, x, y)
        ph = view.pick_helper
        ph.do_pick(x, y)
        count = ph.count
        return nil if count <= 0

        count.times do |i|
          path = ph.path_at(i)
          next unless path
          # Ưu tiên đối tượng Group/Component sâu nhất mà người dùng đang trỏ tới.
          candidate = path.reverse.find { |e| VADA::BoolDeDung.boolean_entity?(e) }
          return candidate if candidate && candidate.valid?
        end
        nil
      rescue StandardError
        nil
      end

      def draw_entity_box(view, entity, color, width)
        bb = entity.bounds
        pts = (0..7).map { |i| bb.corner(i) }
        edges = [
          0, 1, 1, 3, 3, 2, 2, 0,
          4, 5, 5, 7, 7, 6, 6, 4,
          0, 4, 1, 5, 2, 6, 3, 7
        ]
        view.drawing_color = color
        view.line_width = width
        edge_pts = edges.map { |i| pts[i] }
        view.draw(GL_LINES, edge_pts)
      end

      def draw_label(view, entity, label, color)
        p3d = entity.bounds.center
        p2d = view.screen_coords(p3d)
        view.draw_text([p2d.x + 10, p2d.y - 10], label,
                       color: color, size: 18, bold: true)
      end
    end

    unless file_loaded?(__FILE__)
      cmd = UI::Command.new("#{PLUGIN_NAME} v#{VERSION}") { show_dialog }
      cmd.tooltip = 'Boolean Solid dễ dùng: Gộp, Trừ, Cắt, Giao, Chia'
      cmd.status_bar_text = 'Mở VADA Bool Dễ Dùng và chọn phép Boolean theo từng bước.'
      icon24 = File.join(ICON_DIR, 'bool_24.png')
      icon32 = File.join(ICON_DIR, 'bool_32.png')
      cmd.small_icon = icon24 if File.exist?(icon24)
      cmd.large_icon = icon32 if File.exist?(icon32)

      toolbar = UI::Toolbar.new('VADA Bool Dễ Dùng')
      toolbar.add_item(cmd)
      toolbar.restore

      menu = UI.menu('Extensions').add_submenu('VADA')
      menu.add_item(cmd)

      file_loaded(__FILE__)
    end
  end
end
