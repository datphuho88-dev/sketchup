# encoding: UTF-8
require 'sketchup.rb'
require 'extensions.rb'

module VADA
  module BoolDeDung
    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new('VADA Bool Dễ Dùng', 'vada_bool_de_dung/main')
      extension.creator = 'Công ty TNHH VADA'
      extension.description = 'Boolean Solid dễ dùng, hướng dẫn chọn khối A và B trực tiếp trên màn hình.'
      extension.version = '1.0.2'
      extension.copyright = '2026 Công ty TNHH VADA'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
