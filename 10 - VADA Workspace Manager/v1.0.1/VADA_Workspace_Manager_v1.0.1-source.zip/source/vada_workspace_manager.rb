# frozen_string_literal: true

require 'sketchup.rb'
require 'extensions.rb'

module VADA
  module WorkspaceManager
    EXTENSION_NAME = 'VADA Workspace Manager'
    VERSION = '1.0.1'
  end
end

unless file_loaded?(__FILE__)
  loader = File.join('vada_workspace_manager', 'main.rb')
  extension = SketchupExtension.new(VADA::WorkspaceManager::EXTENSION_NAME, loader)
  extension.description = 'Quản lý, lưu và tự dọn toolbar SketchUp/VADA/extension bên ngoài theo workspace.'
  extension.version = VADA::WorkspaceManager::VERSION
  extension.creator = 'Công ty TNHH VADA'
  extension.copyright = '2026 Công ty TNHH VADA'
  Sketchup.register_extension(extension, true)
  file_loaded(__FILE__)
end
