# frozen_string_literal: true

require 'sketchup.rb'
require 'json'
require 'fileutils'

module VADA
  module WorkspaceManager
    extend self

    VERSION = '1.0.0' unless const_defined?(:VERSION)
    EXTENSION_NAME = 'VADA Workspace Manager' unless const_defined?(:EXTENSION_NAME)
    TOOLBAR_NAME = 'VADA Workspace'
    MENU_NAME = 'VADA Workspace Manager'
    CONFIG_SCHEMA = 1
    STARTUP_PASSES = [0.3, 2.0, 6.0].freeze
    FALLBACK_STARTUP_PASSES = [2.5, 6.0, 12.0].freeze

    ROOT = File.dirname(__FILE__)
    UI_FILE = File.join(ROOT, 'ui', 'index.html')
    ICON_24 = File.join(ROOT, 'icons', 'workspace_24.png')
    ICON_32 = File.join(ROOT, 'icons', 'workspace_32.png')

    @dialog = nil
    @toolbar = nil
    @undo_snapshot = nil
    @startup_timers = []
    @app_observer = nil

    # ---------- Persistent data ----------

    def data_dir
      base = if Sketchup.platform == :platform_win
               ENV['APPDATA']
             else
               ENV['HOME']
             end
      base = Sketchup.find_support_file('Plugins') if base.nil? || base.empty?
      File.join(base, 'VADA', 'SketchUp')
    end

    def config_path
      File.join(data_dir, 'workspace_manager.json')
    end

    def default_config
      {
        'schema' => CONFIG_SCHEMA,
        'active_profile' => 'Mặc định',
        'auto_startup' => true,
        'manage_native' => false,
        'profiles' => {
          'Mặc định' => {
            'initialized' => false,
            'ruby_visible' => [],
            'native_visible' => [],
            'known_ruby' => [],
            'known_native' => [],
            'saved_at' => nil
          }
        }
      }
    end

    def load_config
      FileUtils.mkdir_p(data_dir)
      return default_config unless File.file?(config_path)

      parsed = JSON.parse(File.read(config_path, encoding: 'UTF-8'))
      normalize_config(parsed)
    rescue StandardError => e
      puts "[VADA Workspace] Không đọc được cấu hình: #{e.class}: #{e.message}"
      default_config
    end

    def save_config(config)
      FileUtils.mkdir_p(data_dir)
      File.write(config_path, JSON.pretty_generate(normalize_config(config)), mode: 'w:UTF-8')
      true
    rescue StandardError => e
      UI.messagebox("Không thể lưu cấu hình VADA Workspace:\n#{e.message}")
      false
    end

    def normalize_config(config)
      base = default_config
      cfg = config.is_a?(Hash) ? config : {}
      base['active_profile'] = cfg['active_profile'].to_s.empty? ? 'Mặc định' : cfg['active_profile'].to_s
      base['auto_startup'] = cfg.key?('auto_startup') ? !!cfg['auto_startup'] : true
      base['manage_native'] = cfg.key?('manage_native') ? !!cfg['manage_native'] : false

      profiles = cfg['profiles'].is_a?(Hash) ? cfg['profiles'] : {}
      base['profiles'] = {}
      profiles.each do |name, profile|
        next if name.to_s.strip.empty?
        p = profile.is_a?(Hash) ? profile : {}
        base['profiles'][name.to_s] = {
          'initialized' => !!p['initialized'],
          'ruby_visible' => array_strings(p['ruby_visible']),
          'native_visible' => array_strings(p['native_visible']),
          'known_ruby' => array_strings(p['known_ruby']),
          'known_native' => array_strings(p['known_native']),
          'saved_at' => p['saved_at']
        }
      end
      base['profiles']['Mặc định'] ||= default_config['profiles']['Mặc định']
      unless base['profiles'].key?(base['active_profile'])
        base['active_profile'] = base['profiles'].keys.first
      end
      base
    end

    def array_strings(value)
      Array(value).map(&:to_s).reject(&:empty?).uniq.sort
    end

    def active_profile(config = nil)
      cfg = config || load_config
      cfg['profiles'][cfg['active_profile']] || cfg['profiles'].values.first
    end

    # ---------- Toolbar discovery ----------

    def ruby_toolbars
      rows = Hash.new { |h, k| h[k] = [] }
      ObjectSpace.each_object(UI::Toolbar) do |toolbar|
        begin
          name = toolbar.name.to_s
          next if name.empty?
          rows[name] << toolbar
        rescue StandardError
          next
        end
      end
      rows
    end

    def native_toolbar_names
      Array(UI.toolbar_names).map(&:to_s).reject(&:empty?).uniq.sort
    rescue StandardError
      []
    end

    def toolbar_state
      cfg = load_config
      profile = active_profile(cfg)
      ruby = ruby_toolbars
      known_ruby = profile['known_ruby']
      known_native = profile['known_native']

      ruby_rows = ruby.map do |name, toolbars|
        visible = Array(toolbars).any? { |toolbar| safe_visible_ruby?(toolbar) }
        {
          'name' => name,
          'kind' => 'extension',
          'visible' => visible,
          'saved_visible' => profile['ruby_visible'].include?(name),
          'new' => !known_ruby.include?(name),
          'manager' => (name == TOOLBAR_NAME)
        }
      end.sort_by { |r| [r['manager'] ? 0 : 1, r['name'].downcase] }

      native_rows = native_toolbar_names.map do |name|
        {
          'name' => name,
          'kind' => 'native',
          'visible' => safe_native_visible?(name),
          'saved_visible' => profile['native_visible'].include?(name),
          'new' => !known_native.include?(name),
          'manager' => false
        }
      end

      {
        'version' => VERSION,
        'config_path' => config_path,
        'active_profile' => cfg['active_profile'],
        'profiles' => cfg['profiles'].keys.sort,
        'auto_startup' => cfg['auto_startup'],
        'manage_native' => cfg['manage_native'],
        'profile_initialized' => !!profile['initialized'],
        'profile_saved_at' => profile['saved_at'],
        'ruby_toolbars' => ruby_rows,
        'native_toolbars' => native_rows,
        'stats' => {
          'extension_total' => ruby_rows.length,
          'extension_visible' => ruby_rows.count { |r| r['visible'] },
          'native_total' => native_rows.length,
          'native_visible' => native_rows.count { |r| r['visible'] },
          'new_total' => (ruby_rows + native_rows).count { |r| r['new'] }
        }
      }
    end

    def safe_visible_ruby?(toolbar)
      !!toolbar.visible?
    rescue StandardError
      false
    end

    def safe_native_visible?(name)
      !!UI.toolbar_visible?(name)
    rescue StandardError
      false
    end

    # ---------- Snapshot / apply ----------

    def current_snapshot(include_native = true)
      ruby = ruby_toolbars
      snapshot = {
        'ruby' => {},
        'native' => {}
      }
      ruby.each { |name, toolbars| snapshot['ruby'][name] = Array(toolbars).any? { |tb| safe_visible_ruby?(tb) } }
      if include_native
        native_toolbar_names.each { |name| snapshot['native'][name] = safe_native_visible?(name) }
      end
      snapshot
    end

    def save_current_layout
      cfg = load_config
      profile = active_profile(cfg)
      snapshot = current_snapshot(true)
      profile['initialized'] = true
      profile['ruby_visible'] = snapshot['ruby'].select { |_name, visible| visible }.keys.sort
      profile['native_visible'] = snapshot['native'].select { |_name, visible| visible }.keys.sort
      profile['known_ruby'] = snapshot['ruby'].keys.sort
      profile['known_native'] = snapshot['native'].keys.sort
      profile['saved_at'] = Time.now.strftime('%Y-%m-%d %H:%M:%S')
      save_config(cfg)
      push_state
    end

    def save_selected_layout(payload)
      cfg = load_config
      profile = active_profile(cfg)
      data = parse_payload(payload)
      profile['initialized'] = true
      profile['ruby_visible'] = array_strings(data['ruby_visible'])
      profile['native_visible'] = array_strings(data['native_visible'])
      now = current_snapshot(true)
      profile['known_ruby'] = (profile['known_ruby'] + now['ruby'].keys).uniq.sort
      profile['known_native'] = (profile['known_native'] + now['native'].keys).uniq.sort
      profile['saved_at'] = Time.now.strftime('%Y-%m-%d %H:%M:%S')
      save_config(cfg)
      push_state
    end

    def apply_active_profile(store_undo: true, startup: false)
      cfg = load_config
      profile = active_profile(cfg)
      return false unless profile['initialized']

      @undo_snapshot = current_snapshot(cfg['manage_native']) if store_undo
      desired_ruby = profile['ruby_visible']
      desired_native = profile['native_visible']

      ruby_toolbars.each do |name, toolbars|
        set_ruby_toolbars(toolbars, desired_ruby.include?(name))
      end

      if cfg['manage_native']
        native_toolbar_names.each do |name|
          set_native_toolbar(name, desired_native.include?(name))
        end
      end

      UI.refresh_toolbars if UI.respond_to?(:refresh_toolbars)
      push_state unless startup
      true
    end

    def clean_extensions
      cfg = load_config
      profile = active_profile(cfg)
      @undo_snapshot = current_snapshot(cfg['manage_native'])
      keep = profile['initialized'] ? profile['ruby_visible'] : []
      ruby_toolbars.each do |name, toolbars|
        next if keep.include?(name)
        set_ruby_toolbars(toolbars, false)
      end
      UI.refresh_toolbars if UI.respond_to?(:refresh_toolbars)
      push_state
      true
    end

    def undo_last
      snapshot = @undo_snapshot
      return push_notice('Chưa có thao tác nào để hoàn tác.', 'warning') unless snapshot

      ruby = ruby_toolbars
      snapshot['ruby'].each do |name, visible|
        toolbars = ruby[name]
        set_ruby_toolbars(toolbars, visible) if toolbars
      end
      snapshot['native'].each { |name, visible| set_native_toolbar(name, visible) }
      UI.refresh_toolbars if UI.respond_to?(:refresh_toolbars)
      @undo_snapshot = nil
      push_state
      push_notice('Đã khôi phục trạng thái trước lần dọn gần nhất.', 'success')
    end

    def set_ruby_toolbars(toolbars, visible)
      Array(toolbars).each do |toolbar|
        begin
          visible ? toolbar.show : toolbar.hide
        rescue StandardError => e
          puts "[VADA Workspace] Toolbar lỗi: #{e.message}"
        end
      end
    end

    def set_native_toolbar(name, visible)
      UI.set_toolbar_visible(name, visible)
    rescue StandardError => e
      puts "[VADA Workspace] Native toolbar #{name}: #{e.message}"
    end

    # ---------- Profiles / settings ----------

    def create_profile(name)
      name = name.to_s.strip
      return push_notice('Tên profile không được để trống.', 'error') if name.empty?
      cfg = load_config
      return push_notice('Profile này đã tồn tại.', 'warning') if cfg['profiles'].key?(name)

      cfg['profiles'][name] = {
        'initialized' => false,
        'ruby_visible' => [],
        'native_visible' => [],
        'known_ruby' => [],
        'known_native' => [],
        'saved_at' => nil
      }
      cfg['active_profile'] = name
      save_config(cfg)
      push_state
    end

    def rename_profile(new_name)
      new_name = new_name.to_s.strip
      return push_notice('Tên profile không được để trống.', 'error') if new_name.empty?
      cfg = load_config
      old_name = cfg['active_profile']
      return if old_name == new_name
      return push_notice('Profile này đã tồn tại.', 'warning') if cfg['profiles'].key?(new_name)

      cfg['profiles'][new_name] = cfg['profiles'].delete(old_name)
      cfg['active_profile'] = new_name
      save_config(cfg)
      push_state
    end

    def delete_active_profile
      cfg = load_config
      return push_notice('Phải giữ ít nhất một profile.', 'warning') if cfg['profiles'].length <= 1
      cfg['profiles'].delete(cfg['active_profile'])
      cfg['active_profile'] = cfg['profiles'].keys.first
      save_config(cfg)
      push_state
    end

    def select_profile(name)
      cfg = load_config
      return unless cfg['profiles'].key?(name.to_s)
      cfg['active_profile'] = name.to_s
      save_config(cfg)
      push_state
    end

    def set_settings(payload)
      data = parse_payload(payload)
      cfg = load_config
      cfg['auto_startup'] = !!data['auto_startup'] if data.key?('auto_startup')
      cfg['manage_native'] = !!data['manage_native'] if data.key?('manage_native')
      save_config(cfg)
      schedule_startup_cleanup if cfg['auto_startup']
      push_state
    end

    def mark_all_known
      cfg = load_config
      profile = active_profile(cfg)
      snapshot = current_snapshot(true)
      profile['known_ruby'] = snapshot['ruby'].keys.sort
      profile['known_native'] = snapshot['native'].keys.sort
      save_config(cfg)
      push_state
    end

    # ---------- Startup ----------

    def schedule_startup_cleanup(delays = FALLBACK_STARTUP_PASSES)
      stop_startup_timers
      cfg = load_config
      profile = active_profile(cfg)
      return unless cfg['auto_startup'] && profile['initialized']

      Array(delays).each do |delay|
        timer = UI.start_timer(delay, false) do
          begin
            apply_active_profile(store_undo: false, startup: true)
          rescue StandardError => e
            puts "[VADA Workspace] Startup pass lỗi: #{e.class}: #{e.message}"
          end
        end
        @startup_timers << timer
      end
    end

    def on_extensions_loaded
      schedule_startup_cleanup(STARTUP_PASSES)
    end

    class WorkspaceAppObserver < Sketchup::AppObserver
      def onExtensionsLoaded
        VADA::WorkspaceManager.on_extensions_loaded
      rescue StandardError => e
        puts "[VADA Workspace] onExtensionsLoaded lỗi: #{e.class}: #{e.message}"
      end
    end

    def install_observer
      return if @app_observer
      @app_observer = WorkspaceAppObserver.new
      Sketchup.add_observer(@app_observer)
    rescue StandardError => e
      puts "[VADA Workspace] Không gắn được AppObserver: #{e.class}: #{e.message}"
    end

    def stop_startup_timers
      Array(@startup_timers).each do |timer|
        UI.stop_timer(timer) rescue nil
      end
      @startup_timers = []
    end

    # ---------- Dialog ----------

    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        push_state
        return
      end

      @dialog = UI::HtmlDialog.new(
        dialog_title: "VADA Workspace Manager v#{VERSION}",
        preferences_key: 'vada_workspace_manager',
        scrollable: true,
        resizable: true,
        width: 920,
        height: 680,
        min_width: 760,
        min_height: 520,
        style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dialog.set_file(UI_FILE)
      bind_callbacks(@dialog)
      @dialog.set_on_closed { @dialog = nil }
      @dialog.show
    end

    def bind_callbacks(dialog)
      dialog.add_action_callback('ready') { |_ctx, *_args| push_state }
      dialog.add_action_callback('refresh') { |_ctx, *_args| push_state }
      dialog.add_action_callback('save_current') { |_ctx, *_args| save_current_layout }
      dialog.add_action_callback('save_selected') { |_ctx, payload = nil| save_selected_layout(payload) }
      dialog.add_action_callback('apply_profile') { |_ctx, *_args| apply_active_profile }
      dialog.add_action_callback('clean_extensions') { |_ctx, *_args| clean_extensions }
      dialog.add_action_callback('undo') { |_ctx, *_args| undo_last }
      dialog.add_action_callback('create_profile') { |_ctx, name = nil| create_profile(name) }
      dialog.add_action_callback('rename_profile') { |_ctx, name = nil| rename_profile(name) }
      dialog.add_action_callback('delete_profile') { |_ctx, *_args| delete_active_profile }
      dialog.add_action_callback('select_profile') { |_ctx, name = nil| select_profile(name) }
      dialog.add_action_callback('settings') { |_ctx, payload = nil| set_settings(payload) }
      dialog.add_action_callback('mark_known') { |_ctx, *_args| mark_all_known }
    end

    def parse_payload(payload)
      return payload if payload.is_a?(Hash)
      JSON.parse(payload.to_s)
    rescue StandardError
      {}
    end

    def push_state
      return unless @dialog && @dialog.visible?
      json = JSON.generate(toolbar_state)
      @dialog.execute_script("window.VADA && window.VADA.receiveState(#{json});")
    rescue StandardError => e
      puts "[VADA Workspace] push_state lỗi: #{e.class}: #{e.message}"
    end

    def push_notice(message, level = 'info')
      return unless @dialog && @dialog.visible?
      payload = JSON.generate({ 'message' => message.to_s, 'level' => level.to_s })
      @dialog.execute_script("window.VADA && window.VADA.notice(#{payload});")
    rescue StandardError
      nil
    end

    # ---------- Menu / toolbar ----------

    def install_ui
      cmd_open = UI::Command.new('VADA Workspace Manager') { show_dialog }
      cmd_open.tooltip = 'VADA Workspace Manager'
      cmd_open.status_bar_text = 'Quản lý, lưu và tự dọn toolbar SketchUp.'
      cmd_open.small_icon = ICON_24 if File.file?(ICON_24)
      cmd_open.large_icon = ICON_32 if File.file?(ICON_32)

      cmd_clean = UI::Command.new('Dọn workspace theo profile') { apply_active_profile }
      cmd_clean.tooltip = 'Dọn workspace theo profile đã lưu'
      cmd_clean.status_bar_text = 'Ẩn toolbar ngoài profile và giữ các toolbar đã lưu.'

      menu = UI.menu('Extensions').add_submenu(MENU_NAME)
      menu.add_item(cmd_open)
      menu.add_item(cmd_clean)
      menu.add_item('Lưu bố cục hiện tại') { save_current_layout }
      menu.add_item('Hoàn tác lần dọn gần nhất') { undo_last }

      @toolbar = UI::Toolbar.new(TOOLBAR_NAME)
      @toolbar.add_item(cmd_open)
      # Chỉ hiện lần đầu để người dùng thấy nút quản lý; các lần sau tôn trọng trạng thái đã lưu.
      if @toolbar.get_last_state == -1
        @toolbar.show
      else
        @toolbar.restore
      end
    end

    unless file_loaded?(__FILE__)
      install_ui
      install_observer
      schedule_startup_cleanup
      file_loaded(__FILE__)
    end
  end
end
