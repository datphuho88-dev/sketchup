# Changelog

## v1.0.0 — 2026-09-18
- Phát hành đầu tiên.
- Quét và quản lý toolbar của extension bên ngoài.
- Hỗ trợ toolbar gốc SketchUp.
- Profile workspace, lưu/áp dụng/hoàn tác.
- Tự dọn theo `onExtensionsLoaded` + vài lượt kiểm tra ngắn; không polling liên tục.
- Có nút dọn nhanh plugin và hoàn tác.
- Phát hiện toolbar mới.
- Giao diện tiếng Việt, nền #000000.
