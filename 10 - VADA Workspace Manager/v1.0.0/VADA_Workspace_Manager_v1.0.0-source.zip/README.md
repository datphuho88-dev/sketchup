# VADA Workspace Manager v1.0.0

Plugin SketchUp dùng để dọn và lưu trạng thái toolbar của cả plugin VADA, extension bên ngoài và (tùy chọn) toolbar gốc SketchUp.

## Chức năng
- Quét toolbar extension bằng `ObjectSpace.each_object(UI::Toolbar)`.
- Quét toolbar gốc bằng `UI.toolbar_names`.
- Lưu profile các toolbar đang hiển thị.
- Dọn theo profile bằng `show/hide` hoặc `UI.set_toolbar_visible`.
- Dùng `Sketchup::AppObserver#onExtensionsLoaded` trên SketchUp 2022+ rồi kiểm tra thêm vài lượt ngắn; có fallback timer cho bản cũ.
- Phát hiện toolbar mới chưa có trong profile.
- Nút `DỌN NHANH PLUGIN` để ẩn ngay các toolbar plugin thừa, kể cả trước khi tạo profile.
- Hỗ trợ nhiều profile.
- Hoàn tác lần dọn gần nhất.
- Không chạy vòng lặp nền liên tục.

## Cách dùng
1. Cài `VADA_Workspace_Manager_v1.0.0.rbz` bằng Extension Manager.
2. Sắp xếp màn hình và đóng/mở toolbar đúng ý.
3. Mở `Extensions > VADA Workspace Manager`.
4. Bấm `LƯU MÀN HÌNH HIỆN TẠI`.
5. Giữ bật `Tự dọn khi mở SketchUp`.

Từ lần mở SketchUp sau, toolbar ngoài profile sẽ tự ẩn sau khi các extension tải xong.

## Lưu ý
- Vị trí dock/floating của toolbar vẫn do SketchUp tự lưu. Plugin tập trung quản lý trạng thái hiện/ẩn.
- Mặc định không quản lý toolbar gốc SketchUp để tránh thay đổi giao diện chuẩn. Có thể bật tùy chọn này trong cửa sổ plugin.
- Plugin không monkey-patch `UI::Toolbar#show`, nên giảm nguy cơ xung đột với extension bên ngoài.
