# frozen_string_literal: true

require 'sketchup.rb'
require 'json'
require 'fileutils'

module VADA
  module WorkspaceManager
    extend self

    VERSION = '1.0.2' unless const_defined?(:VERSION)
    EXTENSION_NAME = 'VADA Workspace Manager' unless const_defined?(:EXTENSION_NAME)
    TOOLBAR_NAME = 'VADA Workspace'
    MENU_NAME = 'VADA Workspace Manager'
    CONFIG_SCHEMA = 2

    # Nhiều lượt ngắn sau khi extension đã load để bắt các plugin tự show toolbar bằng timer.
    STARTUP_PASSES = [0.6, 1.8, 4.0, 8.0, 12.0].freeze
    FALLBACK_STARTUP_PASSES = [0.8, 2.5, 6.0, 12.0].freeze

    ROOT = File.dirname(__FILE__)
    UI_FILE = File.join(ROOT, 'ui', 'index.html')
    ICON_24 = File.join(ROOT, 'icons', 'workspace_24.png')
    ICON_32 = File.join(ROOT, 'icons', 'workspace_32.png')

    @dialog = nil
    @toolbar = nil
    @undo_snapshot = nil
    @startup_timers = []
    @app_observer = nil

    # Registry giữ strong-reference tới đúng đối tượng UI::Toolbar.
    # Đây là phần quan trọng: sau khi đã quét thấy toolbar, ta không phụ thuộc
    # vào việc extension bên ngoài có giữ biến Ruby tham chiếu tới toolbar hay không.
    @toolbar_registry = {}

    # ---------- Persistent data ----------

    def data_dir
      base = if Sketchup.platform == :platform_win
               ENV['APPDATA']
             else
               ENV['HOME']
             end
      base = Sketchup.find_support_file('Plugins') if base.nil? || base.empty?
      File.join(base, 'VADA', 'SketchUp')
    end

    def config_path
      File.join(data_dir, 'workspace_manager.json')
    end

    def default_profile
      {
        'initialized' => false,
        'ruby_visible' => [],
        'native_visible' => [],
        'known_ruby' => [],
        'known_native' => [],
        'saved_at' => nil
      }
    end

    def default_config
      {
        'schema' => CONFIG_SCHEMA,
        'active_profile' => 'Mặc định',
        'auto_startup' => true,
        'manage_native' => false,
        'profiles' => {
          'Mặc định' => default_profile
        }
      }
    end

    def load_config
      FileUtils.mkdir_p(data_dir)
      return default_config unless File.file?(config_path)

      parsed = JSON.parse(File.read(config_path, encoding: 'UTF-8'))
      normalize_config(parsed)
    rescue StandardError => e
      puts "[VADA Workspace] Không đọc được cấu hình: #{e.class}: #{e.message}"
      default_config
    end

    def save_config(config)
      FileUtils.mkdir_p(data_dir)
      File.write(config_path, JSON.pretty_generate(normalize_config(config)), mode: 'w:UTF-8')
      true
    rescue StandardError => e
      UI.messagebox("Không thể lưu cấu hình VADA Workspace:\n#{e.message}")
      false
    end

    def normalize_config(config)
      base = default_config
      cfg = config.is_a?(Hash) ? config : {}
      base['schema'] = CONFIG_SCHEMA
      base['active_profile'] = cfg['active_profile'].to_s.empty? ? 'Mặc định' : cfg['active_profile'].to_s
      base['auto_startup'] = cfg.key?('auto_startup') ? !!cfg['auto_startup'] : true
      base['manage_native'] = cfg.key?('manage_native') ? !!cfg['manage_native'] : false

      profiles = cfg['profiles'].is_a?(Hash) ? cfg['profiles'] : {}
      base['profiles'] = {}
      profiles.each do |name, profile|
        next if name.to_s.strip.empty?
        p = profile.is_a?(Hash) ? profile : {}
        base['profiles'][name.to_s] = {
          'initialized' => !!p['initialized'],
          'ruby_visible' => array_strings(p['ruby_visible']),
          'native_visible' => array_strings(p['native_visible']),
          'known_ruby' => array_strings(p['known_ruby']),
          'known_native' => array_strings(p['known_native']),
          'saved_at' => p['saved_at']
        }
      end
      base['profiles']['Mặc định'] ||= default_profile
      base['active_profile'] = base['profiles'].keys.first unless base['profiles'].key?(base['active_profile'])
      base
    end

    def array_strings(value)
      Array(value).map(&:to_s).reject(&:empty?).uniq.sort
    end

    def active_profile(config = nil)
      cfg = config || load_config
      cfg['profiles'][cfg['active_profile']] || cfg['profiles'].values.first
    end

    # ---------- Toolbar discovery / live registry ----------

    def register_toolbar(toolbar)
      return nil unless toolbar.is_a?(UI::Toolbar)
      name = toolbar.name.to_s
      return nil if name.empty?
      @toolbar_registry[toolbar.object_id] = toolbar
      toolbar
    rescue StandardError
      nil
    end

    def scan_ruby_toolbars
      # Quét đúng các object UI::Toolbar đang sống trong Ruby VM.
      ObjectSpace.each_object(UI::Toolbar) { |toolbar| register_toolbar(toolbar) }

      # Dọn ref lỗi nếu extension bị unload trong cùng session.
      @toolbar_registry.delete_if do |_id, toolbar|
        begin
          toolbar.name.to_s.empty?
        rescue StandardError
          true
        end
      end

      @toolbar_registry
    rescue StandardError => e
      puts "[VADA Workspace] Quét UI::Toolbar lỗi: #{e.class}: #{e.message}"
      @toolbar_registry
    end

    def ruby_toolbars
      scan_ruby_toolbars
      rows = Hash.new { |h, k| h[k] = [] }
      @toolbar_registry.each_value do |toolbar|
        begin
          name = toolbar.name.to_s
          next if name.empty?
          rows[name] << toolbar unless rows[name].include?(toolbar)
        rescue StandardError
          next
        end
      end
      rows
    end

    def native_toolbar_names
      Array(UI.toolbar_names).map(&:to_s).reject(&:empty?).uniq.sort
    rescue StandardError
      []
    end

    def safe_visible_ruby?(toolbar)
      toolbar.visible? == true
    rescue StandardError
      false
    end

    def safe_native_visible?(name)
      UI.toolbar_visible?(name) == true
    rescue StandardError
      false
    end

    def toolbar_state
      cfg = load_config
      profile = active_profile(cfg)
      ruby = ruby_toolbars
      known_ruby = profile['known_ruby']
      known_native = profile['known_native']

      ruby_rows = ruby.map do |name, toolbars|
        visible = Array(toolbars).any? { |toolbar| safe_visible_ruby?(toolbar) }
        {
          'name' => name,
          'kind' => 'extension',
          'visible' => visible,
          'saved_visible' => profile['ruby_visible'].include?(name),
          'new' => !known_ruby.include?(name),
          'manager' => (name == TOOLBAR_NAME),
          'objects' => toolbars.length
        }
      end.sort_by { |r| [r['visible'] ? 0 : 1, r['manager'] ? 0 : 1, r['name'].downcase] }

      native_rows = native_toolbar_names.map do |name|
        {
          'name' => name,
          'kind' => 'native',
          'visible' => safe_native_visible?(name),
          'saved_visible' => profile['native_visible'].include?(name),
          'new' => !known_native.include?(name),
          'manager' => false,
          'objects' => 0
        }
      end.sort_by { |r| [r['visible'] ? 0 : 1, r['name'].downcase] }

      {
        'version' => VERSION,
        'config_path' => config_path,
        'active_profile' => cfg['active_profile'],
        'profiles' => cfg['profiles'].keys.sort,
        'auto_startup' => cfg['auto_startup'],
        'manage_native' => cfg['manage_native'],
        'profile_initialized' => !!profile['initialized'],
        'profile_saved_at' => profile['saved_at'],
        'ruby_toolbars' => ruby_rows,
        'native_toolbars' => native_rows,
        'stats' => {
          'extension_total' => ruby_rows.length,
          'extension_objects' => ruby_rows.inject(0) { |sum, r| sum + r['objects'].to_i },
          'extension_visible' => ruby_rows.count { |r| r['visible'] },
          'native_total' => native_rows.length,
          'native_visible' => native_rows.count { |r| r['visible'] },
          'new_total' => (ruby_rows + native_rows).count { |r| r['new'] }
        }
      }
    end

    # ---------- Snapshot / apply ----------

    # Snapshot dùng cho lưu profile: theo tên để persist qua lần mở SketchUp sau.
    def current_named_snapshot(include_native = true)
      ruby = ruby_toolbars
      snapshot = { 'ruby' => {}, 'native' => {} }
      ruby.each do |name, toolbars|
        snapshot['ruby'][name] = Array(toolbars).any? { |tb| safe_visible_ruby?(tb) }
      end
      if include_native
        native_toolbar_names.each { |name| snapshot['native'][name] = safe_native_visible?(name) }
      end
      snapshot
    end

    # Snapshot dùng cho Hoàn tác trong cùng session: giữ trực tiếp object UI::Toolbar.
    def current_runtime_snapshot(include_native = true)
      scan_ruby_toolbars
      ruby_refs = []
      @toolbar_registry.each_value do |toolbar|
        begin
          ruby_refs << [toolbar, safe_visible_ruby?(toolbar)]
        rescue StandardError
          next
        end
      end
      native = {}
      native_toolbar_names.each { |name| native[name] = safe_native_visible?(name) } if include_native
      { 'ruby_refs' => ruby_refs, 'native' => native }
    end

    def save_current_layout
      cfg = load_config
      profile = active_profile(cfg)
      snapshot = current_named_snapshot(true)
      profile['initialized'] = true
      profile['ruby_visible'] = snapshot['ruby'].select { |_name, visible| visible }.keys.sort
      profile['native_visible'] = snapshot['native'].select { |_name, visible| visible }.keys.sort
      profile['known_ruby'] = snapshot['ruby'].keys.sort
      profile['known_native'] = snapshot['native'].keys.sort
      profile['saved_at'] = Time.now.strftime('%Y-%m-%d %H:%M:%S')
      if save_config(cfg)
        push_notice("Đã lưu #{profile['ruby_visible'].length} toolbar plugin vào profile.", 'success')
      end
      schedule_state_refresh
    end

    def save_selected_layout(payload)
      cfg = load_config
      profile = active_profile(cfg)
      data = parse_payload(payload)
      profile['initialized'] = true
      profile['ruby_visible'] = array_strings(data['ruby_visible'])
      profile['native_visible'] = array_strings(data['native_visible'])
      now = current_named_snapshot(true)
      profile['known_ruby'] = (profile['known_ruby'] + now['ruby'].keys).uniq.sort
      profile['known_native'] = (profile['known_native'] + now['native'].keys).uniq.sort
      profile['saved_at'] = Time.now.strftime('%Y-%m-%d %H:%M:%S')
      if save_config(cfg)
        push_notice('Đã lưu các toolbar được đánh dấu GIỮ vào profile.', 'success')
      end
      schedule_state_refresh
    end

    def apply_active_profile(store_undo: true, startup: false)
      cfg = load_config
      profile = active_profile(cfg)
      unless profile['initialized']
        push_notice('Profile chưa được lưu. Hãy lưu bố cục hiện tại trước.', 'warning') unless startup
        return false
      end

      @undo_snapshot = current_runtime_snapshot(cfg['manage_native']) if store_undo
      desired_ruby = profile['ruby_visible']
      desired_native = profile['native_visible']
      groups = ruby_toolbars

      changed = 0
      failed = 0
      groups.each do |name, toolbars|
        result = set_ruby_toolbars(toolbars, desired_ruby.include?(name))
        changed += result[:changed]
        failed += result[:failed]
      end

      if cfg['manage_native']
        native_toolbar_names.each do |name|
          result = set_native_toolbar(name, desired_native.include?(name))
          changed += 1 if result == :changed
          failed += 1 if result == :failed
        end
      end

      refresh_toolbar_ui
      unless startup
        push_notice("Đã áp profile: #{changed} toolbar thay đổi#{failed > 0 ? ", #{failed} lỗi" : ''}.", failed > 0 ? 'warning' : 'success')
        schedule_state_refresh
      end
      true
    end

    # Dọn nhanh dựa vào các ô GIỮ đang chọn trên giao diện.
    # Nếu callback không truyền payload thì fallback về profile đã lưu.
    def clean_extensions(payload = nil)
      cfg = load_config
      profile = active_profile(cfg)
      data = parse_payload(payload)
      keep = if data['keep'].is_a?(Array)
               array_strings(data['keep'])
             elsif profile['initialized']
               profile['ruby_visible']
             else
               []
             end

      @undo_snapshot = current_runtime_snapshot(cfg['manage_native'])
      groups = ruby_toolbars
      changed = 0
      failed = 0

      groups.each do |name, toolbars|
        next if keep.include?(name)
        # Chỉ hide, không show gì trong Dọn nhanh.
        result = set_ruby_toolbars(toolbars, false)
        changed += result[:changed]
        failed += result[:failed]
      end

      refresh_toolbar_ui
      push_notice("Đã ẩn #{changed} toolbar plugin#{failed > 0 ? ", #{failed} toolbar lỗi" : ''}.", failed > 0 ? 'warning' : 'success')
      schedule_state_refresh
      true
    end

    def undo_last
      snapshot = @undo_snapshot
      return push_notice('Chưa có thao tác nào để hoàn tác.', 'warning') unless snapshot

      changed = 0
      failed = 0
      Array(snapshot['ruby_refs']).each do |pair|
        toolbar, visible = pair
        result = set_ruby_toolbars([toolbar], visible)
        changed += result[:changed]
        failed += result[:failed]
      end
      snapshot['native'].each do |name, visible|
        result = set_native_toolbar(name, visible)
        changed += 1 if result == :changed
        failed += 1 if result == :failed
      end

      refresh_toolbar_ui
      @undo_snapshot = nil
      push_notice("Đã hoàn tác #{changed} toolbar#{failed > 0 ? ", #{failed} lỗi" : ''}.", failed > 0 ? 'warning' : 'success')
      schedule_state_refresh
      true
    end

    def set_toolbar_now(payload)
      data = parse_payload(payload)
      name = data['name'].to_s
      kind = data['kind'].to_s
      visible = !!data['visible']
      return push_notice('Không xác định được toolbar.', 'error') if name.empty?

      @undo_snapshot = current_runtime_snapshot(kind == 'native')

      if kind == 'native'
        result = set_native_toolbar(name, visible)
        if result == :failed
          push_notice("Không điều khiển được toolbar #{name}.", 'error')
        else
          push_notice("#{visible ? 'Đã hiện' : 'Đã ẩn'} #{name}.", 'success')
        end
      else
        toolbars = ruby_toolbars[name]
        if toolbars.nil? || toolbars.empty?
          push_notice("Không còn giữ được đối tượng UI::Toolbar của #{name}. Hãy bấm Quét lại.", 'error')
          return false
        end
        result = set_ruby_toolbars(toolbars, visible)
        level = result[:failed] > 0 ? 'warning' : 'success'
        push_notice("#{visible ? 'Đã hiện' : 'Đã ẩn'} #{name}#{result[:failed] > 0 ? " (#{result[:failed]} lỗi)" : ''}.", level)
      end

      refresh_toolbar_ui
      schedule_state_refresh
      true
    end

    def set_ruby_toolbars(toolbars, visible)
      changed = 0
      failed = 0
      Array(toolbars).each do |toolbar|
        begin
          register_toolbar(toolbar)
          before = safe_visible_ruby?(toolbar)
          next if before == visible
          visible ? toolbar.show : toolbar.hide
          changed += 1
        rescue StandardError => e
          failed += 1
          puts "[VADA Workspace] Toolbar #{safe_toolbar_name(toolbar)} lỗi: #{e.class}: #{e.message}"
        end
      end
      { changed: changed, failed: failed }
    end

    def safe_toolbar_name(toolbar)
      toolbar.name.to_s
    rescue StandardError
      '(không rõ)'
    end

    def set_native_toolbar(name, visible)
      before = safe_native_visible?(name)
      return :unchanged if before == visible
      ok = UI.set_toolbar_visible(name, visible)
      ok == false ? :failed : :changed
    rescue StandardError => e
      puts "[VADA Workspace] Native toolbar #{name}: #{e.class}: #{e.message}"
      :failed
    end

    def refresh_toolbar_ui
      UI.refresh_toolbars if UI.respond_to?(:refresh_toolbars)
    rescue StandardError
      nil
    end

    def schedule_state_refresh
      # Đợi SketchUp xử lý hide/show rồi mới đọc visible? để giao diện phản ánh đúng.
      UI.start_timer(0.08, false) { push_state }
    rescue StandardError
      push_state
    end

    # ---------- Profiles / settings ----------

    def create_profile(name)
      name = name.to_s.strip
      return push_notice('Tên profile không được để trống.', 'error') if name.empty?
      cfg = load_config
      return push_notice('Profile này đã tồn tại.', 'warning') if cfg['profiles'].key?(name)

      cfg['profiles'][name] = default_profile
      cfg['active_profile'] = name
      save_config(cfg)
      push_state
    end

    def rename_profile(new_name)
      new_name = new_name.to_s.strip
      return push_notice('Tên profile không được để trống.', 'error') if new_name.empty?
      cfg = load_config
      old_name = cfg['active_profile']
      return if old_name == new_name
      return push_notice('Profile này đã tồn tại.', 'warning') if cfg['profiles'].key?(new_name)

      cfg['profiles'][new_name] = cfg['profiles'].delete(old_name)
      cfg['active_profile'] = new_name
      save_config(cfg)
      push_state
    end

    def delete_active_profile
      cfg = load_config
      return push_notice('Phải giữ ít nhất một profile.', 'warning') if cfg['profiles'].length <= 1
      cfg['profiles'].delete(cfg['active_profile'])
      cfg['active_profile'] = cfg['profiles'].keys.first
      save_config(cfg)
      push_state
    end

    def select_profile(name)
      cfg = load_config
      return unless cfg['profiles'].key?(name.to_s)
      cfg['active_profile'] = name.to_s
      save_config(cfg)
      push_state
    end

    def set_settings(payload)
      data = parse_payload(payload)
      cfg = load_config
      cfg['auto_startup'] = !!data['auto_startup'] if data.key?('auto_startup')
      cfg['manage_native'] = !!data['manage_native'] if data.key?('manage_native')
      save_config(cfg)
      schedule_startup_cleanup if cfg['auto_startup']
      push_state
    end

    def mark_all_known
      cfg = load_config
      profile = active_profile(cfg)
      snapshot = current_named_snapshot(true)
      profile['known_ruby'] = snapshot['ruby'].keys.sort
      profile['known_native'] = snapshot['native'].keys.sort
      save_config(cfg)
      push_state
    end

    # ---------- Startup ----------

    def schedule_startup_cleanup(delays = FALLBACK_STARTUP_PASSES)
      stop_startup_timers
      cfg = load_config
      profile = active_profile(cfg)
      return unless cfg['auto_startup'] && profile['initialized']

      Array(delays).each do |delay|
        timer = UI.start_timer(delay, false) do
          begin
            # Quét trước mỗi lượt để giữ strong-reference các toolbar plugin mới tạo.
            scan_ruby_toolbars
            apply_active_profile(store_undo: false, startup: true)
          rescue StandardError => e
            puts "[VADA Workspace] Startup pass lỗi: #{e.class}: #{e.message}"
          end
        end
        @startup_timers << timer
      end
    end

    def on_extensions_loaded
      # Event này xảy ra sau khi extensions load; các timer tiếp theo bắt plugin tự show trễ.
      scan_ruby_toolbars
      schedule_startup_cleanup(STARTUP_PASSES)
    end

    class WorkspaceAppObserver < Sketchup::AppObserver
      def onExtensionsLoaded
        VADA::WorkspaceManager.on_extensions_loaded
      rescue StandardError => e
        puts "[VADA Workspace] onExtensionsLoaded lỗi: #{e.class}: #{e.message}"
      end
    end

    def install_observer
      return if @app_observer
      @app_observer = WorkspaceAppObserver.new
      Sketchup.add_observer(@app_observer)
    rescue StandardError => e
      puts "[VADA Workspace] Không gắn được AppObserver: #{e.class}: #{e.message}"
    end

    def stop_startup_timers
      Array(@startup_timers).each do |timer|
        begin
          UI.stop_timer(timer)
        rescue StandardError
          nil
        end
      end
      @startup_timers = []
    end

    # ---------- Dialog ----------

    def show_dialog
      scan_ruby_toolbars
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        push_state
        return
      end

      @dialog = UI::HtmlDialog.new(
        dialog_title: "VADA Workspace Manager v#{VERSION}",
        preferences_key: 'vada_workspace_manager',
        scrollable: true,
        resizable: true,
        width: 980,
        height: 700,
        min_width: 800,
        min_height: 540,
        style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dialog.set_file(UI_FILE)
      bind_callbacks(@dialog)
      @dialog.set_on_closed { @dialog = nil }
      @dialog.show
    end

    def bind_callbacks(dialog)
      dialog.add_action_callback('ready') { |_ctx, *_args| push_state }
      dialog.add_action_callback('refresh') { |_ctx, *_args| scan_ruby_toolbars; push_state }
      dialog.add_action_callback('save_current') { |_ctx, *_args| save_current_layout }
      dialog.add_action_callback('save_selected') { |_ctx, payload = nil| save_selected_layout(payload) }
      dialog.add_action_callback('apply_profile') { |_ctx, *_args| apply_active_profile }
      dialog.add_action_callback('clean_extensions') { |_ctx, payload = nil| clean_extensions(payload) }
      dialog.add_action_callback('toggle_toolbar') { |_ctx, payload = nil| set_toolbar_now(payload) }
      dialog.add_action_callback('undo') { |_ctx, *_args| undo_last }
      dialog.add_action_callback('create_profile') { |_ctx, name = nil| create_profile(name) }
      dialog.add_action_callback('rename_profile') { |_ctx, name = nil| rename_profile(name) }
      dialog.add_action_callback('delete_profile') { |_ctx, *_args| delete_active_profile }
      dialog.add_action_callback('select_profile') { |_ctx, name = nil| select_profile(name) }
      dialog.add_action_callback('settings') { |_ctx, payload = nil| set_settings(payload) }
      dialog.add_action_callback('mark_known') { |_ctx, *_args| mark_all_known }
    end

    def parse_payload(payload)
      return payload if payload.is_a?(Hash)
      return {} if payload.nil? || payload.to_s.empty?
      JSON.parse(payload.to_s)
    rescue StandardError
      {}
    end

    def push_state
      return unless @dialog && @dialog.visible?
      json = JSON.generate(toolbar_state)
      @dialog.execute_script("window.VADA && window.VADA.receiveState(#{json});")
    rescue StandardError => e
      puts "[VADA Workspace] push_state lỗi: #{e.class}: #{e.message}"
    end

    def push_notice(message, level = 'info')
      return false unless @dialog && @dialog.visible?
      payload = JSON.generate({ 'message' => message.to_s, 'level' => level.to_s })
      @dialog.execute_script("window.VADA && window.VADA.notice(#{payload});")
      true
    rescue StandardError
      false
    end

    # ---------- Menu / toolbar ----------

    def install_ui
      cmd_open = UI::Command.new('VADA Workspace Manager') { show_dialog }
      cmd_open.tooltip = 'VADA Workspace Manager'
      cmd_open.status_bar_text = 'Quản lý, lưu và tự dọn toolbar SketchUp.'
      cmd_open.small_icon = ICON_24 if File.file?(ICON_24)
      cmd_open.large_icon = ICON_32 if File.file?(ICON_32)

      cmd_clean = UI::Command.new('Dọn workspace theo profile') { apply_active_profile }
      cmd_clean.tooltip = 'Dọn workspace theo profile đã lưu'
      cmd_clean.status_bar_text = 'Đưa toolbar về đúng trạng thái profile đã lưu.'

      menu = UI.menu('Extensions').add_submenu(MENU_NAME)
      menu.add_item(cmd_open)
      menu.add_item(cmd_clean)
      menu.add_item('Dọn nhanh toolbar plugin') { clean_extensions }
      menu.add_item('Lưu bố cục hiện tại') { save_current_layout }
      menu.add_item('Hoàn tác lần dọn gần nhất') { undo_last }

      @toolbar = UI::Toolbar.new(TOOLBAR_NAME)
      @toolbar.add_item(cmd_open)
      register_toolbar(@toolbar)

      # Lần đầu cho thấy nút quản lý; các lần sau tôn trọng trạng thái SketchUp đã lưu.
      if @toolbar.get_last_state == -1
        @toolbar.show
      else
        @toolbar.restore
      end
    end

    unless file_loaded?(__FILE__)
      install_ui
      scan_ruby_toolbars
      install_observer
      schedule_startup_cleanup
      file_loaded(__FILE__)
    end
  end
end
